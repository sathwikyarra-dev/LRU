# Custom LRU File Cache Simulator (DSA Laboratory Suite)

A comprehensive Data Structures and Algorithms (DSA) simulation suite implementing an **LRU (Least Recently Used) File Cache** from scratch using low-level foundational primitives:
1. **Polynomial Rolling Hash Map** with Separate Chaining for collision resolution ($O(1)$ amortized access).
2. **Doubly Linked List** (`prev` / `next` pointers) maintaining Most Recently Used (MRU) at `HEAD` and Least Recently Used (LRU) at `TAIL` ($O(1)$ constant time promotions and evictions).
3. **Multi-Policy Comparative Engine**: Real-time side-by-side benchmarking against **FIFO** (First-In, First-Out), **LFU** (Least Frequently Used with min-heap), and **Random Replacement**.
4. **Interactive Algorithmic Step Debugger**: Granular execution stepping through pointer decoupling and rewiring with C++ / TypeScript code snippets.
5. **Physical RAM Allocation Map & Hex Pointers**: 64-bit hexadecimal memory grid and byte-level payload inspections.
6. **Academic Laboratory Report Generator**: Automatic formal university-grade lab report compiler with LaTeX / Markdown export.
7. **Python Desktop App**: Standalone Python Tkinter GUI application in `/lru_file_cache`.

---

## Quick Start (Web Application)

### Prerequisites
- Node.js (v18+)
- npm or bun

### Installation & Development
```bash
# 1. Install dependencies
npm install

# 2. Start the development server
npm run dev
```
Open your browser at `http://localhost:3000`.

### Production Build
```bash
npm run build
npm run preview
```

---

## Quick Start (Python Desktop GUI)

The project includes an academic standalone Python Tkinter desktop implementation under `/lru_file_cache`.

### Prerequisites
- Python 3.8+
- Tkinter (standard on Windows/macOS; on Ubuntu/Debian: `sudo apt-get install python3-tk`)

### Running the Python Desktop Application
```bash
cd lru_file_cache
python3 main.py
```

### Running the Python Unit Tests
```bash
cd lru_file_cache
python3 -m unittest discover tests
```

---

## Architectural Principles & Time Complexity

| Operation | Implementation Details | Time Complexity | Space Complexity |
| :--- | :--- | :--- | :--- |
| **Hash Computation** | Polynomial rolling hash $(H \cdot 31 + c) \pmod{16}$ | $O(K)$ where $K = \text{key length}$ | $O(1)$ |
| **Cache Lookup (GET)** | Bucket chain search + DLL node detachment + re-insertion at `HEAD` | **$O(1)$** amortized | $O(1)$ |
| **Cache Insertion (PUT)** | New DLLNode creation + HashMap bucket link + capacity check | **$O(1)$** | $O(1)$ |
| **LRU Eviction** | Detach node at `TAIL` ($node \to tail \to prev$) + remove from HashMap | **$O(1)$** | $O(1)$ |

---

## Project Structure
```text
├── index.html                 # Web application entry point
├── package.json               # Dependencies and scripts
├── tsconfig.json              # TypeScript configuration
├── vite.config.ts             # Vite bundler configuration
├── src/                       # React 19 + TypeScript source
│   ├── App.tsx                # Main controller & state manager
│   ├── lruCore.ts             # Custom HashMap & Doubly Linked List engine
│   ├── audioSynth.ts          # Web Audio API micro-synthesizer for cache events
│   ├── seedData.ts            # Seed files and workloads
│   ├── policyEngines.ts       # LRU, FIFO, LFU, Random comparison engines
│   ├── types.ts               # Core interfaces and types
│   ├── components/            # UI components and tabs
│   │   ├── ArchitecturePipelineHUD.tsx # Live hardware memory bus
│   │   ├── PhysicalRAMMap.tsx          # 64-bit Hexadecimal memory visualizer
│   │   ├── StepDebuggerModal.tsx       # Step-by-step algorithm trace
│   │   ├── DashboardTab.tsx            # Main telemetry and metrics
│   │   ├── CacheMemoryTab.tsx          # DLL pointer inspector
│   │   ├── PolicyComparisonTab.tsx     # LRU vs FIFO vs LFU vs Random
│   │   ├── HashMapTab.tsx              # Polynomial rolling hash visualizer
│   │   ├── StatisticsTab.tsx           # Latency timeline & hit rate charts
│   │   ├── StorageTab.tsx              # Secondary disk file manager
│   │   ├── LabReportModal.tsx          # Academic lab report generator
│   │   ├── SplashScreen.tsx            # 3-second startup screen
│   │   └── Header.tsx                  # Persistent top navigation bar
└── lru_file_cache/            # Standalone Python Tkinter desktop application
    ├── main.py                # Desktop GUI entry point
    ├── dsa/                   # Python Doubly Linked List & HashMap
    ├── simulator/             # Cache simulator engine
    └── tests/                 # Comprehensive unit test suite
```

---

## License
MIT License. Built for educational and academic computer science study.
