# Fixed LRU Cache Simulator

The browser showed `ERR_CONNECTION_REFUSED` because the Vite server was not running.

## One-click Windows start
Double-click `START_APP.bat`. It installs dependencies if needed, starts Vite on port 3000, and opens the browser.

## Manual
```bash
npm install
npm run dev
```
Then open http://localhost:3000

## Fix included
`src/main.tsx` now correctly imports the named `App` export.
