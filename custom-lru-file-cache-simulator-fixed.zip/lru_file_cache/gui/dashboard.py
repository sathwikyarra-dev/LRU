"""
Dashboard View.
Displays overview telemetry cards:
- Cache Capacity (Used / Max)
- Cache Hits & Misses
- Hit Rate (%)
- Evictions & Total Requests
- Cache Capacity Control (1 to 20 files)
- Memory simulation progress bar
- Quick Access File trigger
"""

import tkinter as tk
from tkinter import ttk, messagebox
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..simulator.simulator import Simulator


class DashboardView(ttk.Frame):
    """Main Dashboard Overview Panel."""

    def __init__(self, parent, simulator: "Simulator", on_state_change=None, **kwargs):
        super().__init__(parent, **kwargs)
        self.simulator = simulator
        self.on_state_change = on_state_change
        self._build_ui()

    def _build_ui(self):
        # Header
        top_bar = ttk.Frame(self)
        top_bar.pack(fill=tk.X, padx=16, pady=(16, 8))

        ttk.Label(
            top_bar,
            text="Cache Telemetry & Control Dashboard",
            font=("Segoe UI", 16, "bold")
        ).pack(side=tk.LEFT)

        # Quick Access file bar
        quick_frame = ttk.Frame(top_bar)
        quick_frame.pack(side=tk.RIGHT)

        ttk.Label(quick_frame, text="Quick Access:").pack(side=tk.LEFT, padx=4)
        self.quick_combo_var = tk.StringVar()
        self.quick_combo = ttk.Combobox(quick_frame, textvariable=self.quick_combo_var, state="readonly", width=18)
        self.quick_combo.pack(side=tk.LEFT, padx=4)
        ttk.Button(quick_frame, text="⚡ Request", command=self._quick_access).pack(side=tk.LEFT, padx=4)

        # Telemetry Cards Grid
        self.cards_grid = ttk.Frame(self)
        self.cards_grid.pack(fill=tk.X, padx=16, pady=10)

        self.card_capacity = self._create_card(self.cards_grid, "Cache Capacity", "0 / 0", 0, 0, fg="#38bdf8")
        self.card_hits = self._create_card(self.cards_grid, "Cache Hits", "0", 0, 1, fg="#34d399")
        self.card_misses = self._create_card(self.cards_grid, "Cache Misses", "0", 0, 2, fg="#f87171")
        self.card_hit_rate = self._create_card(self.cards_grid, "Hit Rate", "0.0%", 0, 3, fg="#38bdf8")
        self.card_evictions = self._create_card(self.cards_grid, "Total Evictions", "0", 0, 4, fg="#fbbf24")
        self.card_requests = self._create_card(self.cards_grid, "Total Requests", "0", 0, 5, fg="#a855f7")

        for col in range(6):
            self.cards_grid.grid_columnconfigure(col, weight=1)

        # Controls & Settings Row
        settings_frame = tk.Frame(self, bg="#1e293b", bd=1, relief=tk.SOLID, padx=16, pady=14)
        settings_frame.pack(fill=tk.X, padx=16, pady=8)

        # Left: Capacity Setting
        cap_box = tk.Frame(settings_frame, bg="#1e293b")
        cap_box.pack(side=tk.LEFT, fill=tk.Y)

        tk.Label(cap_box, text="CACHE CAPACITY CONTROL", font=("Segoe UI", 9, "bold"), fg="#38bdf8", bg="#1e293b").pack(anchor=tk.W)
        cap_ctrl_row = tk.Frame(cap_box, bg="#1e293b", pady=4)
        cap_ctrl_row.pack(anchor=tk.W)

        self.cap_spin_var = tk.IntVar(value=self.simulator.cache.capacity)
        self.cap_spin = ttk.Spinbox(cap_ctrl_row, from_=1, to=20, textvariable=self.cap_spin_var, width=5)
        self.cap_spin.pack(side=tk.LEFT, padx=(0, 6))

        ttk.Button(cap_ctrl_row, text="Apply Capacity", command=self._apply_capacity).pack(side=tk.LEFT)
        tk.Label(cap_box, text="Capacity ranges from 1 to 20 files. Reducing capacity evicts LRU items.", font=("Segoe UI", 8), fg="#94a3b8", bg="#1e293b").pack(anchor=tk.W)

        # Middle: Eviction Policy
        policy_box = tk.Frame(settings_frame, bg="#1e293b")
        policy_box.pack(side=tk.LEFT, fill=tk.Y, padx=32)

        tk.Label(policy_box, text="EVICTION POLICY", font=("Segoe UI", 9, "bold"), fg="#38bdf8", bg="#1e293b").pack(anchor=tk.W)
        self.policy_var = tk.StringVar(value=self.simulator.cache.policy)
        p_row = tk.Frame(policy_box, bg="#1e293b", pady=4)
        p_row.pack(anchor=tk.W)

        rb_files = ttk.Radiobutton(p_row, text="Maximum Files (Count)", variable=self.policy_var, value="max_files", command=self._change_policy)
        rb_files.pack(side=tk.LEFT, padx=(0, 8))
        rb_mem = ttk.Radiobutton(p_row, text="Maximum Memory (MB)", variable=self.policy_var, value="max_memory", command=self._change_policy)
        rb_mem.pack(side=tk.LEFT)

        # Right: Memory Visualization
        mem_box = tk.Frame(settings_frame, bg="#1e293b")
        mem_box.pack(side=tk.RIGHT, fill=tk.Y)

        self.lbl_mem_title = tk.Label(mem_box, text="MEMORY OCCUPANCY", font=("Segoe UI", 9, "bold"), fg="#38bdf8", bg="#1e293b")
        self.lbl_mem_title.pack(anchor=tk.W)

        self.lbl_mem_text = tk.Label(mem_box, text="0.0 MB / 50.0 MB", font=("Segoe UI", 10, "bold"), fg="#f8fafc", bg="#1e293b")
        self.lbl_mem_text.pack(anchor=tk.W, pady=2)

        self.mem_progress = ttk.Progressbar(mem_box, length=180, mode="determinate")
        self.mem_progress.pack(anchor=tk.W)

        # Recent Access / Activity Snapshot
        recent_frame = tk.Frame(self, bg="#1e293b", bd=1, relief=tk.SOLID, padx=16, pady=12)
        recent_frame.pack(fill=tk.BOTH, expand=True, padx=16, pady=8)

        tk.Label(recent_frame, text="RECENT CACHE OPERATIONS", font=("Segoe UI", 10, "bold"), fg="#f8fafc", bg="#1e293b").pack(anchor=tk.W)

        self.recent_list_frame = tk.Frame(recent_frame, bg="#1e293b")
        self.recent_list_frame.pack(fill=tk.BOTH, expand=True, pady=6)

        self.refresh_dashboard()

    def _create_card(self, parent, title: str, val: str, row: int, col: int, fg: str = "#38bdf8"):
        frame = tk.Frame(parent, bg="#1e293b", bd=1, relief=tk.SOLID, padx=14, pady=10)
        frame.grid(row=row, column=col, padx=4, pady=4, sticky="nsew")

        tk.Label(frame, text=title.upper(), font=("Segoe UI", 8, "bold"), fg="#94a3b8", bg="#1e293b").pack(anchor=tk.W)
        lbl = tk.Label(frame, text=val, font=("Segoe UI", 15, "bold"), fg=fg, bg="#1e293b")
        lbl.pack(anchor=tk.W, pady=(4, 0))
        return lbl

    def refresh_dashboard(self):
        """Updates dashboard telemetry and memory meters."""
        stats = self.simulator.cache.get_statistics()

        self.card_capacity.config(text=f"{stats['current_size']} / {stats['capacity']}")
        self.card_hits.config(text=str(stats["cache_hits"]))
        self.card_misses.config(text=str(stats["cache_misses"]))
        self.card_hit_rate.config(text=f"{stats['hit_rate_pct']}%")
        self.card_evictions.config(text=str(stats["evictions"]))
        self.card_requests.config(text=str(stats["total_requests"]))

        # Memory progress
        curr_mem = stats["current_memory_mb"]
        max_mem = stats["max_memory_mb"]
        pct = min(100.0, (curr_mem / max_mem) * 100.0) if max_mem > 0 else 0
        self.lbl_mem_text.config(text=f"{curr_mem:.1f} MB / {max_mem:.1f} MB ({pct:.1f}%)")
        self.mem_progress["value"] = pct

        # Quick access combobox
        file_names = [f.file_name for f in self.simulator.storage.files]
        self.quick_combo["values"] = file_names
        if file_names and not self.quick_combo_var.get():
            self.quick_combo_var.set(file_names[0])

        # Render recent operations
        for widget in self.recent_list_frame.winfo_children():
            widget.destroy()

        recent_logs = self.simulator.activity_logs[-5:]
        if not recent_logs:
            tk.Label(self.recent_list_frame, text="No cache operations recorded yet.", font=("Segoe UI", 9, "italic"), fg="#64748b", bg="#1e293b").pack(anchor=tk.W)
        else:
            for log in reversed(recent_logs):
                row = tk.Frame(self.recent_list_frame, bg="#0f172a", padx=10, pady=4)
                row.pack(fill=tk.X, pady=2)

                st = log["status"]
                st_color = "#34d399" if st == "HIT" else ("#f87171" if st == "MISS" else "#fbbf24")

                tk.Label(row, text=log["timestamp"], font=("Consolas", 8), fg="#64748b", bg="#0f172a", width=10).pack(side=tk.LEFT)
                tk.Label(row, text=f"{log['operation']} : {log['file_name']}", font=("Segoe UI", 9, "bold"), fg="#f8fafc", bg="#0f172a", width=25, anchor=tk.W).pack(side=tk.LEFT)
                tk.Label(row, text=st, font=("Segoe UI", 8, "bold"), fg=st_color, bg="#0f172a", width=12).pack(side=tk.LEFT)
                tk.Label(row, text=f"{log['latency_ms']} ms", font=("Segoe UI", 8), fg="#38bdf8", bg="#0f172a", width=10).pack(side=tk.LEFT)
                tk.Label(row, text=log.get("details", ""), font=("Segoe UI", 8), fg="#94a3b8", bg="#0f172a").pack(side=tk.LEFT, fill=tk.X)

    def _quick_access(self):
        target = self.quick_combo_var.get()
        if not target:
            return
        res = self.simulator.access_file(target)
        self.refresh_dashboard()
        if self.on_state_change:
            self.on_state_change()

    def _apply_capacity(self):
        try:
            new_cap = int(self.cap_spin_var.get())
            if new_cap < 1 or new_cap > 20:
                raise ValueError
            evicted = self.simulator.cache.set_capacity(new_cap)
            for ev in evicted:
                self.simulator.log_activity("EVICT", ev.file_name, "EVICTED", f"Capacity reduced to {new_cap}")
            self.refresh_dashboard()
            if self.on_state_change:
                self.on_state_change()
            if evicted:
                messagebox.showinfo("Capacity Applied", f"Capacity set to {new_cap}.\nEvicted {len(evicted)} item(s) from LRU Tail.")
        except ValueError:
            messagebox.showerror("Error", "Capacity must be an integer between 1 and 20.")

    def _change_policy(self):
        self.simulator.cache.policy = self.policy_var.get()
        self.refresh_dashboard()
        if self.on_state_change:
            self.on_state_change()
