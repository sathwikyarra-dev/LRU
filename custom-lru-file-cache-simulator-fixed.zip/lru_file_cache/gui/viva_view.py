"""
Viva Questions & Answers View.
Contains 20 comprehensive DSA viva exam questions with thorough explanations.
"""

import tkinter as tk
from tkinter import ttk

VIVA_QUESTIONS = [
    {
        "q": "Q1: Why is a HashMap used in an LRU cache?",
        "a": "A HashMap provides average O(1) time complexity for looking up cache entries by key (file ID). Without a HashMap, searching for an item in a cache would require scanning a list sequentially in O(N) time."
    },
    {
        "q": "Q2: Why is a Doubly Linked List used instead of a Singly Linked List?",
        "a": "In a Doubly Linked List, each node maintains pointers to both its predecessor (previous) and successor (next). When the HashMap locates a node, we can detach it and splice it to the front in O(1) time without traversing from the head to find the predecessor."
    },
    {
        "q": "Q3: Why can't a dynamic array or Python list efficiently implement an LRU cache?",
        "a": "Removing an arbitrary element from an array requires shifting all subsequent elements left, which takes O(N) time. Inserting or moving an item to index 0 also shifts all items in O(N) time. A Doubly Linked List achieves O(1) removal and insertion."
    },
    {
        "q": "Q4: What is a cache hit?",
        "a": "A cache hit occurs when a requested item is already stored in the fast-access cache memory. The item is returned immediately without accessing slow secondary storage."
    },
    {
        "q": "Q5: What is a cache miss?",
        "a": "A cache miss occurs when a requested item is not found in the cache. The system must retrieve the data from secondary storage (simulated disk), load it into memory, and insert it into the cache."
    },
    {
        "q": "Q6: What is cache eviction?",
        "a": "Eviction is the process of removing an existing item from the cache to create space for a newly loaded item when the cache reaches its maximum capacity or memory limit."
    },
    {
        "q": "Q7: Why is the tail of the linked list considered LRU (Least Recently Used)?",
        "a": "Every time an item is accessed or newly inserted, it is moved to or added at the head (MRU). Therefore, items that have not been accessed for the longest period naturally drift toward the tail."
    },
    {
        "q": "Q8: Why is the head of the linked list considered MRU (Most Recently Used)?",
        "a": "By definition, the most recent operation (either GET hit or PUT insert) promotes the target node to the head of the list. Thus, the head always holds the most recently accessed node."
    },
    {
        "q": "Q9: What is a hash collision?",
        "a": "A hash collision occurs when two different keys compute to the exact same bucket index: hash(key1) % capacity == hash(key2) % capacity. Because hash tables have finite buckets, collisions are inevitable according to the Pigeonhole Principle."
    },
    {
        "q": "Q10: How does separate chaining resolve hash collisions?",
        "a": "Separate chaining stores multiple entries mapping to the same bucket index as a linked list (or chain) of nodes. During lookup, the algorithm navigates directly to the bucket and iterates through the chain until the matching key is found."
    },
    {
        "q": "Q11: What is the average and worst-case time complexity of LRU GET?",
        "a": "Average time is O(1) because good hash distribution yields constant bucket chain length, and pointer manipulation in the linked list takes O(1). Worst case is O(N) if all keys collide into a single bucket, degrading the hash map to a linear search."
    },
    {
        "q": "Q12: What happens when the cache is full and a new file is accessed (cache miss)?",
        "a": "The cache identifies the tail node (LRU), unlinks it from the Doubly Linked List, removes its key from the Custom HashMap, increments eviction count, and then adds the new file node at the head (MRU) while registering it in the HashMap."
    },
    {
        "q": "Q13: What happens when an existing cached file is accessed (cache hit)?",
        "a": "The HashMap retrieves the node in O(1) time. The node's access count is incremented, its last-accessed timestamp is updated, and the node is unlinked and moved to the head (MRU) position of the Doubly Linked List."
    },
    {
        "q": "Q14: What happens when a nonexistent file (not even in storage) is requested?",
        "a": "The simulator queries the storage repository. When the file ID is not found in secondary storage, it reports a lookup error without altering cache contents or statistics."
    },
    {
        "q": "Q15: Why is Python's functools.lru_cache or dict avoided in this project?",
        "a": "This is an academic DSA project. Using built-in or third-party wrappers hides the underlying mechanics. Writing our own Custom HashMap and Doubly Linked List demonstrates how hash functions, bucket chains, and pointer linking operate at the memory level."
    },
    {
        "q": "Q16: What is the difference between Temporal Locality and Spatial Locality?",
        "a": "Temporal Locality states that memory accessed recently is likely to be accessed again soon (the foundation of LRU). Spatial Locality states that memory near currently accessed locations is likely to be accessed soon (e.g. cache lines, page prefetching)."
    },
    {
        "q": "Q17: What is the time complexity of deleting a node given only its pointer in Singly vs Doubly Linked Lists?",
        "a": "In a Singly Linked List, deleting a node requires finding its predecessor, which takes O(N) traversal. In a Doubly Linked List, node.previous provides immediate O(1) access to the predecessor, enabling O(1) unlinking."
    },
    {
        "q": "Q18: What is load factor and how does it affect hash table performance?",
        "a": "Load factor is the ratio of stored entries to total bucket capacity (n / k). A low load factor minimizes collisions but wastes memory. A high load factor (> 0.75) increases bucket collisions, lengthening chains and degrading lookup time toward O(N)."
    },
    {
        "q": "Q19: What are common alternative cache replacement policies to LRU?",
        "a": "Common policies include LFU (Least Frequently Used, tracks frequency count), FIFO (First-In First-Out, evicts oldest entry regardless of recent use), and Clock/Second-Chance (circular buffer approximation of LRU with lower synchronization overhead)."
    },
    {
        "q": "Q20: Why is the polynomial rolling hash with base 31 effective for string keys?",
        "a": "Base 31 is prime, which reduces common divisors with power-of-two table capacities, dispersing hash values uniformly across buckets. Furthermore, (x * 31) can be optimized by compilers as (x << 5) - x using fast bit shifts."
    }
]


class VivaView(ttk.Frame):
    """Interactive Viva Questions & Answers Panel."""

    def __init__(self, parent, **kwargs):
        super().__init__(parent, **kwargs)
        self._build_ui()

    def _build_ui(self):
        # Header
        header_frame = ttk.Frame(self)
        header_frame.pack(fill=tk.X, padx=16, pady=(16, 8))

        title = ttk.Label(
            header_frame,
            text="DSA Viva Examination Mode",
            font=("Segoe UI", 16, "bold")
        )
        title.pack(anchor=tk.W)

        sub = ttk.Label(
            header_frame,
            text="20 curated technical questions and comprehensive theoretical answers on LRU Caches, HashMaps, and Doubly Linked Lists.",
            font=("Segoe UI", 10),
            foreground="#94a3b8"
        )
        sub.pack(anchor=tk.W, pady=(2, 0))

        # Search bar
        search_frame = ttk.Frame(self)
        search_frame.pack(fill=tk.X, padx=16, pady=8)

        ttk.Label(search_frame, text="Filter Questions: ", font=("Segoe UI", 10)).pack(side=tk.LEFT)
        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", self._on_filter)
        search_entry = ttk.Entry(search_frame, textvariable=self.search_var, width=35)
        search_entry.pack(side=tk.LEFT, padx=4)

        # Scrollable Canvas
        canvas_container = ttk.Frame(self)
        canvas_container.pack(fill=tk.BOTH, expand=True, padx=16, pady=8)

        self.canvas = tk.Canvas(canvas_container, bg="#0f172a", highlightthickness=0)
        self.scrollbar = ttk.Scrollbar(canvas_container, orient=tk.VERTICAL, command=self.canvas.yview)
        self.scrollable_frame = ttk.Frame(self.canvas)

        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        )

        self.canvas_window = self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.canvas.configure(xscrollcommand=self.scrollbar.set, yscrollcommand=self.scrollbar.set)

        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.canvas.bind(
            "<Configure>",
            lambda e: self.canvas.itemconfig(self.canvas_window, width=e.width)
        )

        self._render_cards()

    def _render_cards(self, filter_text: str = ""):
        for widget in self.scrollable_frame.winfo_children():
            widget.destroy()

        text_lower = filter_text.strip().lower()

        for idx, item in enumerate(VIVA_QUESTIONS):
            if text_lower and (text_lower not in item["q"].lower() and text_lower not in item["a"].lower()):
                continue

            card = tk.Frame(self.scrollable_frame, bg="#1e293b", bd=1, relief=tk.SOLID)
            card.pack(fill=tk.X, expand=True, padx=4, pady=6)

            q_lbl = tk.Label(
                card,
                text=item["q"],
                font=("Segoe UI", 11, "bold"),
                fg="#38bdf8",
                bg="#1e293b",
                wraplength=850,
                justify=tk.LEFT
            )
            q_lbl.pack(anchor=tk.W, padx=12, pady=(10, 4))

            a_lbl = tk.Label(
                card,
                text=item["a"],
                font=("Segoe UI", 10),
                fg="#e2e8f0",
                bg="#1e293b",
                wraplength=850,
                justify=tk.LEFT
            )
            a_lbl.pack(anchor=tk.W, padx=12, pady=(0, 10))

    def _on_filter(self, *args):
        self._render_cards(self.search_var.get())
