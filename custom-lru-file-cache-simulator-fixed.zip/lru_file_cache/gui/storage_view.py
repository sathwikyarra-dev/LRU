"""
File Storage Repository View.
Manages simulated secondary storage with Treeview, search & filters,
Add File dialog, file deletion, and file access triggering LRU operations.
"""

import datetime
import tkinter as tk
from tkinter import ttk, messagebox
from typing import TYPE_CHECKING, Optional
from ..models.file_node import FileNode

if TYPE_CHECKING:
    from ..simulator.simulator import Simulator


class StorageView(ttk.Frame):
    """Secondary Storage Manager and Access Launchpad."""

    def __init__(self, parent, simulator: "Simulator", on_state_change=None, **kwargs):
        super().__init__(parent, **kwargs)
        self.simulator = simulator
        self.on_state_change = on_state_change
        self._build_ui()

    def _build_ui(self):
        # Header
        top_bar = ttk.Frame(self)
        top_bar.pack(fill=tk.X, padx=16, pady=(16, 8))

        ttk.Label(
            top_bar,
            text="Simulated File Storage (Disk Repository)",
            font=("Segoe UI", 16, "bold")
        ).pack(side=tk.LEFT)

        action_bar = ttk.Frame(top_bar)
        action_bar.pack(side=tk.RIGHT)

        ttk.Button(action_bar, text="➕ Add File", command=self._open_add_file_dialog).pack(side=tk.LEFT, padx=4)
        ttk.Button(action_bar, text="🗑 Delete File", command=self._delete_selected_file).pack(side=tk.LEFT, padx=4)
        ttk.Button(action_bar, text="🔍 View Details", command=self._view_file_details).pack(side=tk.LEFT, padx=4)
        ttk.Button(action_bar, text="⚡ ACCESS FILE", command=self._access_selected_file).pack(side=tk.LEFT, padx=4)

        # Search & Filter bar
        filter_bar = ttk.Frame(self)
        filter_bar.pack(fill=tk.X, padx=16, pady=6)

        ttk.Label(filter_bar, text="Search: ").pack(side=tk.LEFT)
        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", lambda *args: self.refresh_table())
        search_entry = ttk.Entry(filter_bar, textvariable=self.search_var, width=24)
        search_entry.pack(side=tk.LEFT, padx=4)

        ttk.Label(filter_bar, text="  Filter: ").pack(side=tk.LEFT)
        self.category_var = tk.StringVar(value="All")
        category_options = ["All", "Cached", "Not Cached", "PDF", "Images", "Videos", "Documents", "Other"]
        cat_menu = ttk.Combobox(filter_bar, textvariable=self.category_var, values=category_options, state="readonly", width=14)
        cat_menu.pack(side=tk.LEFT, padx=4)
        cat_menu.bind("<<ComboboxSelected>>", lambda e: self.refresh_table())

        # Treeview
        container = ttk.Frame(self)
        container.pack(fill=tk.BOTH, expand=True, padx=16, pady=8)

        columns = ("file_id", "file_name", "file_type", "file_size", "created_at", "last_accessed", "access_count", "cache_status")
        self.tree = ttk.Treeview(container, columns=columns, show="headings", selectmode="browse")

        self.tree.heading("file_id", text="ID")
        self.tree.heading("file_name", text="File Name")
        self.tree.heading("file_type", text="Type")
        self.tree.heading("file_size", text="Size")
        self.tree.heading("created_at", text="Created")
        self.tree.heading("last_accessed", text="Last Accessed")
        self.tree.heading("access_count", text="Hits/Access")
        self.tree.heading("cache_status", text="Cache Status")

        self.tree.column("file_id", width=60, anchor=tk.CENTER)
        self.tree.column("file_name", width=180, anchor=tk.W)
        self.tree.column("file_type", width=70, anchor=tk.CENTER)
        self.tree.column("file_size", width=80, anchor=tk.E)
        self.tree.column("created_at", width=130, anchor=tk.CENTER)
        self.tree.column("last_accessed", width=110, anchor=tk.CENTER)
        self.tree.column("access_count", width=90, anchor=tk.CENTER)
        self.tree.column("cache_status", width=120, anchor=tk.CENTER)

        scroll_y = ttk.Scrollbar(container, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll_y.set)

        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scroll_y.pack(side=tk.RIGHT, fill=tk.Y)

        self.tree.bind("<Double-1>", lambda e: self._access_selected_file())

        self.refresh_table()

    def refresh_table(self):
        """Populates Treeview based on current files and filter criteria."""
        for item in self.tree.get_children():
            self.tree.delete(item)

        search_text = self.search_var.get().strip().lower()
        cat = self.category_var.get()

        for f in self.simulator.storage.files:
            in_cache = self.simulator.cache.contains(f.file_id)

            # Cached/Not Cached filter
            if cat == "Cached" and not in_cache:
                continue
            if cat == "Not Cached" and in_cache:
                continue

            # General category filter
            cat_map = {
                "PDF": ["PDF"],
                "Images": ["JPG", "JPEG", "PNG", "GIF"],
                "Videos": ["MP4", "MKV", "AVI"],
                "Documents": ["DOCX", "TXT", "PPTX", "PDF"],
            }
            if cat in cat_map and f.file_type not in cat_map[cat]:
                continue
            if cat == "Other":
                known = [ext for exts in cat_map.values() for ext in exts]
                if f.file_type in known:
                    continue

            # Search text filter
            if search_text:
                combined = f"{f.file_id} {f.file_name} {f.file_type}".lower()
                if search_text not in combined:
                    continue

            cache_status_text = "● IN CACHE" if in_cache else "○ Disk Only"
            tag = "cached" if in_cache else "uncached"

            # Get up-to-date access metadata from cache node if cached
            cached_node = self.simulator.cache.hash_map.get(f.file_id)
            last_acc = (cached_node.last_accessed if cached_node and cached_node.last_accessed else (f.last_accessed or "Never"))
            acc_cnt = cached_node.access_count if cached_node else f.access_count

            size_str = f"{f.file_size:.2f} MB" if f.file_size >= 0.1 else f"{int(f.file_size*1024)} KB"

            self.tree.insert(
                "",
                tk.END,
                values=(
                    f.file_id,
                    f.file_name,
                    f.file_type,
                    size_str,
                    f.created_at,
                    last_acc,
                    acc_cnt,
                    cache_status_text
                ),
                tags=(tag,)
            )

        self.tree.tag_configure("cached", foreground="#34d399")
        self.tree.tag_configure("uncached", foreground="#94a3b8")

    def _get_selected_file_id(self) -> Optional[str]:
        selected = self.tree.selection()
        if not selected:
            return None
        values = self.tree.item(selected[0], "values")
        return str(values[0])

    def _access_selected_file(self):
        file_id = self._get_selected_file_id()
        if not file_id:
            messagebox.showwarning("Select File", "Please select a file from the list to access.")
            return

        res = self.simulator.access_file(file_id)
        if not res.get("success"):
            messagebox.showerror("Error", res.get("error", "Failed to access file."))
            return

        # Show access result dialog
        is_hit = res["status"] == "HIT"
        title = "✓ Cache Hit" if is_hit else "⚠ Cache Miss"
        dlg = tk.Toplevel(self)
        dlg.title(title)
        dlg.geometry("440x260")
        dlg.configure(bg="#0f172a")

        banner_bg = "#064e3b" if is_hit else "#451a03"
        banner_fg = "#34d399" if is_hit else "#f87171"
        header = tk.Label(dlg, text=f"{'✓ CACHE HIT' if is_hit else '⚠ CACHE MISS'}", font=("Segoe UI", 16, "bold"), fg=banner_fg, bg=banner_bg, pady=12)
        header.pack(fill=tk.X)

        content = tk.Frame(dlg, bg="#1e293b", padx=16, pady=12)
        content.pack(fill=tk.BOTH, expand=True, padx=12, pady=12)

        file_obj = res["file"]
        tk.Label(content, text=f"File: {file_obj.file_name} ({file_obj.file_type})", font=("Segoe UI", 12, "bold"), fg="#f8fafc", bg="#1e293b").pack(anchor=tk.W)
        tk.Label(content, text=f"Access Latency: {res['latency_ms']} ms", font=("Segoe UI", 10), fg="#38bdf8", bg="#1e293b").pack(anchor=tk.W, pady=2)

        if is_hit:
            desc = f"{file_obj.file_name} was found in memory cache.\nMoved to HEAD (MRU position) in Doubly Linked List."
        else:
            evicted_text = ""
            if res.get("evicted"):
                evicted_names = ", ".join(e.file_name for e in res["evicted"])
                evicted_text = f"\nEvicted from LRU Tail: {evicted_names}"
            desc = f"Loaded from simulated secondary storage.\nInserted at HEAD (MRU).{evicted_text}"

        tk.Label(content, text=desc, font=("Segoe UI", 9), fg="#cbd5e1", bg="#1e293b", justify=tk.LEFT).pack(anchor=tk.W, pady=6)

        ttk.Button(dlg, text="OK", command=dlg.destroy).pack(pady=(0, 10))

        self.refresh_table()
        if self.on_state_change:
            self.on_state_change()

    def _open_add_file_dialog(self):
        """Opens modal popup to create a new simulated file."""
        dlg = tk.Toplevel(self)
        dlg.title("Add New File to Storage")
        dlg.geometry("420x360")
        dlg.configure(bg="#0f172a")

        tk.Label(dlg, text="Create Simulated File", font=("Segoe UI", 14, "bold"), fg="#f8fafc", bg="#0f172a").pack(pady=12)

        form = tk.Frame(dlg, bg="#1e293b", padx=16, pady=16)
        form.pack(fill=tk.BOTH, expand=True, padx=16, pady=4)

        # Fields
        tk.Label(form, text="File ID (e.g. F011):", fg="#94a3b8", bg="#1e293b").grid(row=0, column=0, sticky="w", pady=4)
        id_entry = ttk.Entry(form, width=24)
        id_entry.grid(row=0, column=1, pady=4)
        next_id = f"F{len(self.simulator.storage.files) + 1:03d}"
        id_entry.insert(0, next_id)

        tk.Label(form, text="File Name:", fg="#94a3b8", bg="#1e293b").grid(row=1, column=0, sticky="w", pady=4)
        name_entry = ttk.Entry(form, width=24)
        name_entry.grid(row=1, column=1, pady=4)

        tk.Label(form, text="File Type:", fg="#94a3b8", bg="#1e293b").grid(row=2, column=0, sticky="w", pady=4)
        type_combo = ttk.Combobox(form, values=["PDF", "DOCX", "JPG", "PNG", "MP4", "TXT", "SQL", "CSV", "PPTX", "ZIP"], width=22)
        type_combo.set("PDF")
        type_combo.grid(row=2, column=1, pady=4)

        tk.Label(form, text="File Size (MB):", fg="#94a3b8", bg="#1e293b").grid(row=3, column=0, sticky="w", pady=4)
        size_entry = ttk.Entry(form, width=24)
        size_entry.insert(0, "3.5")
        size_entry.grid(row=3, column=1, pady=4)

        def save():
            fid = id_entry.get().strip()
            fname = name_entry.get().strip()
            ftype = type_combo.get().strip().upper()
            fsize_str = size_entry.get().strip()

            # Validation
            if not fid:
                messagebox.showerror("Validation Error", "File ID cannot be empty.", parent=dlg)
                return
            if not fname:
                messagebox.showerror("Validation Error", "File Name cannot be empty.", parent=dlg)
                return
            if self.simulator.storage.get_file(fid):
                messagebox.showerror("Validation Error", f"Duplicate file ID '{fid}' already exists.", parent=dlg)
                return

            try:
                fsize = float(fsize_str)
                if fsize <= 0:
                    raise ValueError
            except ValueError:
                messagebox.showerror("Validation Error", "File Size must be a positive numeric value.", parent=dlg)
                return

            node = FileNode(fid, fname, ftype, fsize)
            self.simulator.storage.add_file(node)
            self.refresh_table()
            dlg.destroy()
            messagebox.showinfo("Success", f"File '{fname}' added to simulated storage.")

        btn_bar = tk.Frame(dlg, bg="#0f172a", pady=10)
        btn_bar.pack(fill=tk.X, padx=16)
        ttk.Button(btn_bar, text="Cancel", command=dlg.destroy).pack(side=tk.RIGHT, padx=4)
        ttk.Button(btn_bar, text="Save File", command=save).pack(side=tk.RIGHT, padx=4)

    def _delete_selected_file(self):
        file_id = self._get_selected_file_id()
        if not file_id:
            messagebox.showwarning("Select File", "Please select a file to delete.")
            return

        file_obj = self.simulator.storage.get_file(file_id)
        if not file_obj:
            return

        confirm = messagebox.askyesno("Confirm Delete", f"Delete '{file_obj.file_name}' from simulated secondary storage?")
        if confirm:
            # Also remove from cache if present
            self.simulator.cache.remove(file_id)
            self.simulator.storage.delete_file(file_id)
            self.refresh_table()
            if self.on_state_change:
                self.on_state_change()

    def _view_file_details(self):
        file_id = self._get_selected_file_id()
        if not file_id:
            messagebox.showwarning("Select File", "Please select a file to view details.")
            return

        file_obj = self.simulator.storage.get_file(file_id)
        if not file_obj:
            return

        in_cache = self.simulator.cache.contains(file_id)
        cache_pos = "NOT CACHED"

        if in_cache:
            state_nodes = self.simulator.cache.get_state()
            for idx, n in enumerate(state_nodes):
                if n.file_id == file_id:
                    if idx == 0:
                        cache_pos = "HEAD (Most Recently Used - MRU)"
                    elif idx == len(state_nodes) - 1:
                        cache_pos = "TAIL (Least Recently Used - LRU)"
                    else:
                        cache_pos = f"Position #{idx+1} of {len(state_nodes)}"
                    break

        dlg = tk.Toplevel(self)
        dlg.title("File Details")
        dlg.geometry("420x360")
        dlg.configure(bg="#0f172a")

        tk.Label(dlg, text="FILE DETAILS", font=("Segoe UI", 14, "bold"), fg="#f8fafc", bg="#0f172a").pack(pady=10)

        card = tk.Frame(dlg, bg="#1e293b", padx=16, pady=16)
        card.pack(fill=tk.BOTH, expand=True, padx=16, pady=4)

        rows = [
            ("File ID:", file_obj.file_id),
            ("Name:", file_obj.file_name),
            ("Type:", file_obj.file_type),
            ("Size:", f"{file_obj.file_size} MB"),
            ("Created Time:", file_obj.created_at),
            ("Last Accessed:", file_obj.last_accessed or "Never"),
            ("Access Count:", str(file_obj.access_count)),
            ("Cache Status:", "IN CACHE" if in_cache else "DISK ONLY"),
            ("Cache Position:", cache_pos),
        ]

        for r_idx, (label, val) in enumerate(rows):
            tk.Label(card, text=label, font=("Segoe UI", 9, "bold"), fg="#94a3b8", bg="#1e293b").grid(row=r_idx, column=0, sticky="w", pady=3)
            tk.Label(card, text=val, font=("Segoe UI", 9), fg="#f8fafc" if label != "Cache Status:" else ("#34d399" if in_cache else "#94a3b8"), bg="#1e293b").grid(row=r_idx, column=1, sticky="w", padx=10, pady=3)

        ttk.Button(dlg, text="Close", command=dlg.destroy).pack(pady=10)
