"""
Activity Log View.
Displays chronological event logs for all cache operations (GET, INSERT, EVICT, RESIZE).
"""

import tkinter as tk
from tkinter import ttk
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..simulator.simulator import Simulator


class ActivityView(ttk.Frame):
    """Activity Log Table showing live operations, hits, misses, evictions, and latencies."""

    def __init__(self, parent, simulator: "Simulator", **kwargs):
        super().__init__(parent, **kwargs)
        self.simulator = simulator
        self._build_ui()

    def _build_ui(self):
        # Header
        top_bar = ttk.Frame(self)
        top_bar.pack(fill=tk.X, padx=16, pady=(16, 8))

        ttk.Label(
            top_bar,
            text="Live Activity & Audit Log",
            font=("Segoe UI", 16, "bold")
        ).pack(side=tk.LEFT)

        btn_frame = ttk.Frame(top_bar)
        btn_frame.pack(side=tk.RIGHT)

        ttk.Button(btn_frame, text="Refresh", command=self.refresh_log).pack(side=tk.LEFT, padx=4)
        ttk.Button(btn_frame, text="Clear Log", command=self._clear_log).pack(side=tk.LEFT, padx=4)

        # Treeview table
        container = ttk.Frame(self)
        container.pack(fill=tk.BOTH, expand=True, padx=16, pady=8)

        columns = ("id", "timestamp", "operation", "file_name", "status", "latency", "details")
        self.tree = ttk.Treeview(container, columns=columns, show="headings", selectmode="browse")

        self.tree.heading("id", text="#")
        self.tree.heading("timestamp", text="Time")
        self.tree.heading("operation", text="Op")
        self.tree.heading("file_name", text="File Name")
        self.tree.heading("status", text="Result Status")
        self.tree.heading("latency", text="Latency (ms)")
        self.tree.heading("details", text="Operation Details")

        self.tree.column("id", width=40, anchor=tk.CENTER)
        self.tree.column("timestamp", width=90, anchor=tk.CENTER)
        self.tree.column("operation", width=80, anchor=tk.CENTER)
        self.tree.column("file_name", width=160, anchor=tk.W)
        self.tree.column("status", width=110, anchor=tk.CENTER)
        self.tree.column("latency", width=90, anchor=tk.E)
        self.tree.column("details", width=340, anchor=tk.W)

        scroll_y = ttk.Scrollbar(container, orient=tk.VERTICAL, command=self.tree.yview)
        scroll_x = ttk.Scrollbar(container, orient=tk.HORIZONTAL, command=self.tree.xview)
        self.tree.configure(yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)

        self.tree.grid(row=0, column=0, sticky="nsew")
        scroll_y.grid(row=0, column=1, sticky="ns")
        scroll_x.grid(row=1, column=0, sticky="ew")

        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.refresh_log()

    def refresh_log(self):
        """Reloads entries from simulator.activity_logs."""
        for item in self.tree.get_children():
            self.tree.delete(item)

        # Show most recent at top
        for log in reversed(self.simulator.activity_logs):
            status = log.get("status", "")
            tags = ()
            if status == "HIT":
                tags = ("hit",)
            elif status == "MISS":
                tags = ("miss",)
            elif status in ("EVICT", "EVICTED"):
                tags = ("evict",)

            self.tree.insert(
                "",
                tk.END,
                values=(
                    log.get("id"),
                    log.get("timestamp"),
                    log.get("operation"),
                    log.get("file_name"),
                    log.get("status"),
                    f"{log.get('latency_ms', 0):.2f}",
                    log.get("details", "")
                ),
                tags=tags
            )

        self.tree.tag_configure("hit", foreground="#34d399")
        self.tree.tag_configure("miss", foreground="#f87171")
        self.tree.tag_configure("evict", foreground="#fbbf24")

    def _clear_log(self):
        self.simulator.activity_logs.clear()
        self.refresh_log()
