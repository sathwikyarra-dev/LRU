"""
Custom Hash Map Visualization View.
Renders all buckets, separate chaining links, collision alerts, and diagnostic metrics.
"""

import tkinter as tk
from tkinter import ttk
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..simulator.simulator import Simulator


class HashMapView(ttk.Frame):
    """Visual inspection tool for CustomHashMap bucket arrays and collision chains."""

    def __init__(self, parent, simulator: "Simulator", **kwargs):
        super().__init__(parent, **kwargs)
        self.simulator = simulator
        self._build_ui()

    def _build_ui(self):
        # Header
        top_frame = ttk.Frame(self)
        top_frame.pack(fill=tk.X, padx=16, pady=(16, 8))

        ttk.Label(
            top_frame,
            text="Custom Hash Map — Bucket & Chain Visualizer",
            font=("Segoe UI", 16, "bold")
        ).pack(side=tk.LEFT)

        ttk.Button(top_frame, text="Refresh Buckets", command=self.refresh_view).pack(side=tk.RIGHT)

        # Hash Function Banner
        formula_box = tk.Frame(self, bg="#1e293b", bd=1, relief=tk.SOLID)
        formula_box.pack(fill=tk.X, padx=16, pady=6)

        formula_text = (
            "Polynomial Rolling Hash:   hash = 0;   for ch in key:   hash = (hash * 31 + ord(ch)) % capacity\n"
            "Collision Resolution: Separate Chaining (Linked Nodes)  •  Load Factor = Entries / Capacity"
        )
        tk.Label(
            formula_box,
            text=formula_text,
            font=("Consolas", 9),
            fg="#38bdf8",
            bg="#1e293b",
            justify=tk.LEFT,
            padx=12,
            pady=8
        ).pack(anchor=tk.W)

        # Telemetry metrics row
        self.metrics_frame = ttk.Frame(self)
        self.metrics_frame.pack(fill=tk.X, padx=16, pady=6)

        self.lbl_capacity = self._create_metric_card(self.metrics_frame, "Bucket Count", "0", 0)
        self.lbl_entries = self._create_metric_card(self.metrics_frame, "Entries in Map", "0", 1)
        self.lbl_collisions = self._create_metric_card(self.metrics_frame, "Total Collisions", "0", 2, fg="#f59e0b")
        self.lbl_load = self._create_metric_card(self.metrics_frame, "Load Factor", "0.00", 3)
        self.lbl_util = self._create_metric_card(self.metrics_frame, "Bucket Utilization", "0.0%", 4)

        # Scrollable Bucket Canvas
        container = ttk.Frame(self)
        container.pack(fill=tk.BOTH, expand=True, padx=16, pady=8)

        self.canvas = tk.Canvas(container, bg="#0f172a", highlightthickness=0)
        self.scrollbar = ttk.Scrollbar(container, orient=tk.VERTICAL, command=self.canvas.yview)
        self.bucket_list_frame = tk.Frame(self.canvas, bg="#0f172a")

        self.bucket_list_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        )
        self.canvas_window = self.canvas.create_window((0, 0), window=self.bucket_list_frame, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)

        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.canvas.bind(
            "<Configure>",
            lambda e: self.canvas.itemconfig(self.canvas_window, width=e.width)
        )

        self.refresh_view()

    def _create_metric_card(self, parent, title: str, val: str, col: int, fg: str = "#38bdf8"):
        frame = tk.Frame(parent, bg="#1e293b", bd=1, relief=tk.SOLID, padx=12, pady=6)
        frame.grid(row=0, column=col, padx=4, sticky="nsew")
        parent.grid_columnconfigure(col, weight=1)

        tk.Label(frame, text=title, font=("Segoe UI", 8), fg="#94a3b8", bg="#1e293b").pack(anchor=tk.W)
        lbl = tk.Label(frame, text=val, font=("Segoe UI", 13, "bold"), fg=fg, bg="#1e293b")
        lbl.pack(anchor=tk.W)
        return lbl

    def refresh_view(self):
        """Re-reads diagnostics from CustomHashMap and draws bucket cards."""
        diag = self.simulator.cache.hash_map.get_diagnostics()

        self.lbl_capacity.config(text=str(diag["capacity"]))
        self.lbl_entries.config(text=str(diag["entries"]))
        self.lbl_collisions.config(text=str(diag["collisions"]))
        self.lbl_load.config(text=f"{diag['load_factor']:.2f}")
        self.lbl_util.config(text=f"{diag['bucket_utilization_pct']}%")

        # Clear existing bucket items
        for widget in self.bucket_list_frame.winfo_children():
            widget.destroy()

        buckets = diag["buckets"]

        for b in buckets:
            idx = b["index"]
            keys = b["keys"]
            is_collision = b["is_collision"]

            card_border = "#f59e0b" if is_collision else "#334155"
            bg_color = "#1e293b"

            card = tk.Frame(self.bucket_list_frame, bg=bg_color, bd=1, relief=tk.SOLID, highlightbackground=card_border, highlightthickness=1)
            card.pack(fill=tk.X, expand=True, padx=4, pady=4)

            # Bucket Header
            hdr = tk.Frame(card, bg="#131d2e", padx=10, pady=4)
            hdr.pack(fill=tk.X)

            tk.Label(
                hdr,
                text=f"Bucket [{idx}]",
                font=("Segoe UI", 10, "bold"),
                fg="#f8fafc",
                bg="#131d2e"
            ).pack(side=tk.LEFT)

            if is_collision:
                badge = tk.Label(
                    hdr,
                    text=f"COLLISION ({len(keys)} chained entries)",
                    font=("Segoe UI", 8, "bold"),
                    fg="#f59e0b",
                    bg="#451a03",
                    padx=6,
                    pady=2
                )
                badge.pack(side=tk.RIGHT)
            elif len(keys) == 1:
                badge = tk.Label(
                    hdr,
                    text="1 Entry (Direct)",
                    font=("Segoe UI", 8),
                    fg="#34d399",
                    bg="#064e3b",
                    padx=6,
                    pady=2
                )
                badge.pack(side=tk.RIGHT)
            else:
                badge = tk.Label(
                    hdr,
                    text="EMPTY",
                    font=("Segoe UI", 8),
                    fg="#64748b",
                    bg="#1e293b",
                    padx=6,
                    pady=2
                )
                badge.pack(side=tk.RIGHT)

            # Bucket Chain Nodes
            body = tk.Frame(card, bg=bg_color, padx=12, pady=6)
            body.pack(fill=tk.X)

            if not keys:
                tk.Label(
                    body,
                    text="(null)  No entries mapped to this bucket index",
                    font=("Consolas", 9, "italic"),
                    fg="#64748b",
                    bg=bg_color
                ).pack(anchor=tk.W)
            else:
                row_f = tk.Frame(body, bg=bg_color)
                row_f.pack(anchor=tk.W, fill=tk.X)

                for k_idx, k in enumerate(keys):
                    # Arrow
                    if k_idx > 0:
                        tk.Label(row_f, text=" → ", font=("Segoe UI", 12, "bold"), fg="#f59e0b", bg=bg_color).pack(side=tk.LEFT)

                    node_box = tk.Frame(row_f, bg="#0f172a", bd=1, relief=tk.SOLID, padx=8, pady=4)
                    node_box.pack(side=tk.LEFT)

                    # Lookup actual file for name if available
                    file_node = self.simulator.cache.hash_map.get(k)
                    display_name = file_node.file_name if file_node else k
                    file_type = file_node.file_type if file_node else "FILE"

                    tk.Label(
                        node_box,
                        text=f"Key: {k}",
                        font=("Consolas", 8, "bold"),
                        fg="#38bdf8",
                        bg="#0f172a"
                    ).pack(anchor=tk.W)

                    tk.Label(
                        node_box,
                        text=f"→ {display_name} [{file_type}]",
                        font=("Segoe UI", 9),
                        fg="#f8fafc",
                        bg="#0f172a"
                    ).pack(anchor=tk.W)
