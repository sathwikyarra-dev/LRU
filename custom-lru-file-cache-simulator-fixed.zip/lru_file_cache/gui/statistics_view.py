"""
Statistics & Performance Comparison View.
Visualizes cache telemetry with embedded Matplotlib figures:
- Hit vs Miss Bar Chart
- Evictions & Request Timeline
- Cache Occupancy Meter
- Performance Lab (Benchmark: Custom LRU O(1) vs Linear Search O(n))
"""

import tkinter as tk
from tkinter import ttk
from typing import TYPE_CHECKING

import matplotlib
matplotlib.use("TkAgg")
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure

if TYPE_CHECKING:
    from ..simulator.simulator import Simulator


class StatisticsView(ttk.Frame):
    """Analytics dashboard and real-time execution benchmark comparisons."""

    def __init__(self, parent, simulator: "Simulator", **kwargs):
        super().__init__(parent, **kwargs)
        self.simulator = simulator
        self._build_ui()

    def _build_ui(self):
        # Header
        top_bar = ttk.Frame(self)
        top_bar.pack(fill=tk.X, padx=16, pady=(16, 6))

        ttk.Label(
            top_bar,
            text="Cache Analytics & Performance Lab",
            font=("Segoe UI", 16, "bold")
        ).pack(side=tk.LEFT)

        ttk.Button(top_bar, text="🔄 Refresh Charts", command=self.refresh_charts).pack(side=tk.RIGHT)

        # Performance Lab Box (Section 28)
        lab_box = tk.Frame(self, bg="#1e293b", bd=1, relief=tk.SOLID, padx=14, pady=10)
        lab_box.pack(fill=tk.X, padx=16, pady=6)

        tk.Label(
            lab_box,
            text="PERFORMANCE LAB: CUSTOM LRU [O(1)] vs LINEAR SEARCH [O(N)]",
            font=("Segoe UI", 9, "bold"),
            fg="#38bdf8",
            bg="#1e293b"
        ).pack(anchor=tk.W)

        bench_row = tk.Frame(lab_box, bg="#1e293b", pady=4)
        bench_row.pack(fill=tk.X)

        tk.Label(bench_row, text="Operations:", fg="#94a3b8", bg="#1e293b").pack(side=tk.LEFT, padx=(0, 4))
        self.bench_ops_var = tk.StringVar(value="10000")
        ops_combo = ttk.Combobox(bench_row, textvariable=self.bench_ops_var, values=["1000", "5000", "10000", "25000"], width=8, state="readonly")
        ops_combo.pack(side=tk.LEFT, padx=4)

        ttk.Button(bench_row, text="Run Benchmark", command=self._run_benchmark).pack(side=tk.LEFT, padx=6)

        self.lbl_bench_result = tk.Label(
            bench_row,
            text="Ready. Select operation count and click 'Run Benchmark' to measure actual wall-clock execution.",
            font=("Segoe UI", 9),
            fg="#cbd5e1",
            bg="#1e293b"
        )
        self.lbl_bench_result.pack(side=tk.LEFT, padx=10)

        # Embedded Matplotlib Charts Container
        chart_container = ttk.Frame(self)
        chart_container.pack(fill=tk.BOTH, expand=True, padx=16, pady=6)

        # Matplotlib Figure with dark theme
        self.fig = Figure(figsize=(9, 4.5), dpi=100, facecolor="#0f172a")
        self.ax1 = self.fig.add_subplot(121)  # Hit vs Miss bar
        self.ax2 = self.fig.add_subplot(122)  # Request Timeline / Occupancy

        self.canvas_chart = FigureCanvasTkAgg(self.fig, master=chart_container)
        self.canvas_chart.get_tk_widget().pack(fill=tk.BOTH, expand=True)

        self.refresh_charts()

    def refresh_charts(self):
        """Redraws the Matplotlib subplots with current cache metrics."""
        stats = self.simulator.cache.get_statistics()
        hits = stats["cache_hits"]
        misses = stats["cache_misses"]
        evictions = stats["evictions"]
        hit_rate = stats["hit_rate_pct"]

        # Subplot 1: Hits vs Misses & Evictions
        self.ax1.clear()
        self.ax1.set_facecolor("#1e293b")
        categories = ["Hits", "Misses", "Evictions"]
        values = [hits, misses, evictions]
        colors = ["#34d399", "#f87171", "#fbbf24"]

        bars = self.ax1.bar(categories, values, color=colors, width=0.55)
        self.ax1.set_title(f"Request Breakdown (Hit Rate: {hit_rate}%)", color="#f8fafc", fontsize=11, fontweight="bold")
        self.ax1.tick_params(colors="#94a3b8")
        for spine in self.ax1.spines.values():
            spine.set_color("#334155")

        # Value annotations
        for bar in bars:
            height = bar.get_height()
            self.ax1.annotate(
                f"{int(height)}",
                xy=(bar.get_x() + bar.get_width() / 2, height),
                xytext=(0, 3),
                textcoords="offset points",
                ha="center", va="bottom",
                color="#f8fafc", fontsize=9, fontweight="bold"
            )

        # Subplot 2: Timeline of Hit Rate / Cache Occupancy
        self.ax2.clear()
        self.ax2.set_facecolor("#1e293b")
        timeline = self.simulator.request_timeline

        if timeline and len(timeline) > 1:
            req_nums = [item["request_num"] for item in timeline]
            hit_rates = [item["hit_rate"] for item in timeline]
            self.ax2.plot(req_nums, hit_rates, color="#38bdf8", marker="o", markersize=4, linewidth=2, label="Hit Rate %")
            self.ax2.set_title("Hit Rate Progression Over Time", color="#f8fafc", fontsize=11, fontweight="bold")
            self.ax2.set_xlabel("Request Number", color="#94a3b8", fontsize=9)
            self.ax2.set_ylabel("Hit Rate (%)", color="#94a3b8", fontsize=9)
            self.ax2.set_ylim(0, 105)
        else:
            # Fallback bar showing cache capacity utilization
            curr_sz = stats["current_size"]
            cap = stats["capacity"]
            self.ax2.barh(["Cache Space"], [curr_sz], color="#38bdf8", height=0.4)
            self.ax2.set_xlim(0, max(cap, 5))
            self.ax2.set_title(f"Cache Utilization ({curr_sz}/{cap} slots)", color="#f8fafc", fontsize=11, fontweight="bold")
            self.ax2.annotate(f" {curr_sz} / {cap} Files", xy=(curr_sz, 0), color="#f8fafc", va="center", fontweight="bold")

        self.ax2.tick_params(colors="#94a3b8")
        for spine in self.ax2.spines.values():
            spine.set_color("#334155")

        self.fig.tight_layout()
        self.canvas_chart.draw_idle()

    def _run_benchmark(self):
        """Executes actual wall-clock comparative benchmark."""
        try:
            ops = int(self.bench_ops_var.get())
        except ValueError:
            ops = 10000

        res = self.simulator.run_benchmark(operations=ops)
        if not res:
            return

        summary = (
            f"Results ({ops:,} ops):  Custom LRU: {res['lru_time_sec']:.4f}s ({res['lru_avg_op_us']} μs/op)  |  "
            f"Linear Search: {res['linear_time_sec']:.4f}s ({res['linear_avg_op_us']} μs/op)  |  "
            f"⚡ Speedup: {res['speedup_ratio']}x Faster"
        )
        self.lbl_bench_result.config(text=summary, fg="#34d399")
