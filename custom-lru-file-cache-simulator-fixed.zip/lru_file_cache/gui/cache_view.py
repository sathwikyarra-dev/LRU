"""
Cache View & Canvas Visualizer.
Renders Doubly Linked List nodes from MRU (Head) to LRU (Tail) with bidirectional arrows.
Includes:
- Step-by-Step execution stepper
- Automatic LRU Demo runner
- Node state highlights (MRU, LRU, Hit, Eviction)
"""

import tkinter as tk
from tkinter import ttk, messagebox
from typing import TYPE_CHECKING, List, Optional

if TYPE_CHECKING:
    from ..simulator.simulator import Simulator
    from ..models.file_node import FileNode


class CacheView(ttk.Frame):
    """Visualizes the Doubly Linked List nodes horizontally with bidirectional links."""

    def __init__(self, parent, simulator: "Simulator", on_state_change=None, **kwargs):
        super().__init__(parent, **kwargs)
        self.simulator = simulator
        self.on_state_change = on_state_change

        # Step-by-step state
        self.active_steps: List[dict] = []
        self.current_step_idx: int = 0

        # Demo state
        self.demo_running: bool = False
        self.demo_paused: bool = False
        self.demo_sequence = ["report.pdf", "assignment.docx", "photo.jpg", "report.pdf", "video.mp4", "assignment.docx", "notes.txt"]
        self.demo_step: int = 0

        self._build_ui()

    def _build_ui(self):
        # Top Action Bar
        top_bar = ttk.Frame(self)
        top_bar.pack(fill=tk.X, padx=16, pady=(16, 8))

        ttk.Label(
            top_bar,
            text="Cache Memory — Doubly Linked List (MRU ⇄ LRU)",
            font=("Segoe UI", 16, "bold")
        ).pack(side=tk.LEFT)

        # Demo & Step controls
        ctrl_frame = ttk.Frame(top_bar)
        ctrl_frame.pack(side=tk.RIGHT)

        self.btn_run_demo = ttk.Button(ctrl_frame, text="▶ Run LRU Demo", command=self._start_demo)
        self.btn_run_demo.pack(side=tk.LEFT, padx=4)

        self.btn_pause_demo = ttk.Button(ctrl_frame, text="⏸ Pause", command=self._toggle_pause_demo, state=tk.DISABLED)
        self.btn_pause_demo.pack(side=tk.LEFT, padx=4)

        ttk.Button(ctrl_frame, text="Step-by-Step Mode", command=self._open_stepper_modal).pack(side=tk.LEFT, padx=4)
        ttk.Button(ctrl_frame, text="Refresh", command=self.draw_cache).pack(side=tk.LEFT, padx=4)

        # Step explanation / Status banner
        self.banner_frame = tk.Frame(self, bg="#1e293b", bd=1, relief=tk.SOLID, padx=12, pady=8)
        self.banner_frame.pack(fill=tk.X, padx=16, pady=4)

        self.lbl_status = tk.Label(
            self.banner_frame,
            text="Cache Active. Head pointer indicates Most Recently Used (MRU). Tail pointer indicates Least Recently Used (LRU).",
            font=("Segoe UI", 10),
            fg="#38bdf8",
            bg="#1e293b"
        )
        self.lbl_status.pack(anchor=tk.W)

        # Canvas for Doubly Linked List
        self.canvas_container = ttk.Frame(self)
        self.canvas_container.pack(fill=tk.BOTH, expand=True, padx=16, pady=8)

        self.canvas = tk.Canvas(self.canvas_container, bg="#0b1329", highlightthickness=1, highlightbackground="#1e293b")
        scroll_x = ttk.Scrollbar(self.canvas_container, orient=tk.HORIZONTAL, command=self.canvas.xview)
        self.canvas.configure(xscrollcommand=scroll_x.set)

        self.canvas.pack(fill=tk.BOTH, expand=True)
        scroll_x.pack(fill=tk.X)

        self.draw_cache()

    def draw_cache(self, highlight_file_id: Optional[str] = None, highlight_type: str = "hit"):
        """Draws the Doubly Linked List horizontally on the Canvas."""
        self.canvas.delete("all")

        nodes = self.simulator.cache.get_state()
        count = len(nodes)
        capacity = self.simulator.cache.capacity

        if count == 0:
            self.canvas.create_text(
                450, 180,
                text="Cache is currently empty.\nAccess a file from File Storage or run the LRU Demo.",
                fill="#64748b",
                font=("Segoe UI", 13, "italic"),
                justify=tk.CENTER
            )
            return

        node_width = 170
        node_height = 130
        gap = 70
        start_x = 60
        y = 120

        total_width = start_x + count * (node_width + gap) + 100
        self.canvas.configure(scrollregion=(0, 0, max(total_width, 1000), 380))

        # Title markers
        self.canvas.create_text(
            start_x + 85, y - 55,
            text="HEAD / MRU",
            fill="#38bdf8",
            font=("Segoe UI", 11, "bold")
        )
        self.canvas.create_line(start_x + 85, y - 40, start_x + 85, y - 10, fill="#38bdf8", width=2, arrow=tk.LAST)

        tail_x = start_x + (count - 1) * (node_width + gap) + 85
        self.canvas.create_text(
            tail_x, y + node_height + 55,
            text="TAIL / LRU (Next to Evict)",
            fill="#f59e0b",
            font=("Segoe UI", 11, "bold")
        )
        self.canvas.create_line(tail_x, y + node_height + 40, tail_x, y + node_height + 10, fill="#f59e0b", width=2, arrow=tk.LAST)

        for i, node in enumerate(nodes):
            x1 = start_x + i * (node_width + gap)
            y1 = y
            x2 = x1 + node_width
            y2 = y1 + node_height

            is_mru = (i == 0)
            is_lru = (i == count - 1)
            is_target = (node.file_id == highlight_file_id)

            # Determine colors
            if is_target:
                fill_color = "#064e3b" if highlight_type == "hit" else "#451a03"
                border_color = "#34d399" if highlight_type == "hit" else "#f87171"
            elif is_mru:
                fill_color = "#0f2e4c"
                border_color = "#38bdf8"
            elif is_lru:
                fill_color = "#2e1a0b"
                border_color = "#f59e0b"
            else:
                fill_color = "#1e293b"
                border_color = "#475569"

            # Draw Node Card
            self.canvas.create_rectangle(x1, y1, x2, y2, fill=fill_color, outline=border_color, width=2)

            # Node Badge / Tag
            badge_text = "MRU" if is_mru else ("LRU" if is_lru else f"#{i+1}")
            badge_color = "#38bdf8" if is_mru else ("#f59e0b" if is_lru else "#94a3b8")
            self.canvas.create_text(x1 + 12, y1 + 16, text=badge_text, fill=badge_color, font=("Segoe UI", 9, "bold"), anchor=tk.W)

            # File Name
            self.canvas.create_text(x1 + 12, y1 + 42, text=node.file_name, fill="#f8fafc", font=("Segoe UI", 10, "bold"), anchor=tk.W)

            # File Type & Size
            self.canvas.create_text(x1 + 12, y1 + 68, text=f"Type: {node.file_type}  |  {node.file_size} MB", fill="#94a3b8", font=("Segoe UI", 9), anchor=tk.W)

            # Access Count
            self.canvas.create_text(x1 + 12, y1 + 92, text=f"Access Count: {node.access_count}", fill="#38bdf8", font=("Segoe UI", 8), anchor=tk.W)

            # Bidirectional Pointer Arrows
            if i < count - 1:
                mid_y_top = y1 + 45
                mid_y_bot = y1 + 85
                arrow_start_x = x2 + 5
                arrow_end_x = x2 + gap - 5

                # Next Pointer (Forward: MRU -> LRU)
                self.canvas.create_line(arrow_start_x, mid_y_top, arrow_end_x, mid_y_top, fill="#38bdf8", width=2, arrow=tk.LAST)
                self.canvas.create_text((arrow_start_x + arrow_end_x) / 2, mid_y_top - 10, text="next", fill="#38bdf8", font=("Consolas", 8))

                # Prev Pointer (Backward: LRU -> MRU)
                self.canvas.create_line(arrow_end_x, mid_y_bot, arrow_start_x, mid_y_bot, fill="#a855f7", width=2, arrow=tk.LAST)
                self.canvas.create_text((arrow_start_x + arrow_end_x) / 2, mid_y_bot + 10, text="prev", fill="#a855f7", font=("Consolas", 8))

    def _start_demo(self):
        """Starts automated LRU demonstration."""
        if self.demo_running:
            return

        self.demo_running = True
        self.demo_paused = False
        self.demo_step = 0
        self.btn_run_demo.config(state=tk.DISABLED)
        self.btn_pause_demo.config(state=tk.NORMAL, text="⏸ Pause")

        # Set capacity to 3 for standard demonstration
        self.simulator.cache.set_capacity(3)
        self.simulator.reset()
        self._demo_tick()

    def _demo_tick(self):
        if not self.demo_running:
            return
        if self.demo_paused:
            self.after(500, self._demo_tick)
            return

        if self.demo_step >= len(self.demo_sequence):
            self.demo_running = False
            self.btn_run_demo.config(state=tk.NORMAL)
            self.btn_pause_demo.config(state=tk.DISABLED)
            self.lbl_status.config(text="✓ Demonstration Complete. All test access patterns demonstrated.")
            return

        target_file = self.demo_sequence[self.demo_step]
        res = self.simulator.access_file(target_file)
        self.demo_step += 1

        evicted_info = f" [Evicted: {res['evicted'][0].file_name}]" if res.get("evicted") else ""
        self.lbl_status.config(
            text=f"Demo Step {self.demo_step}/{len(self.demo_sequence)}: Request '{target_file}' → {res['status']}{evicted_info}"
        )

        file_id = res["file"].file_id if res.get("file") else None
        self.draw_cache(highlight_file_id=file_id, highlight_type="hit" if res["status"] == "HIT" else "miss")

        if self.on_state_change:
            self.on_state_change()

        # Schedule next tick in 1800ms
        self.after(1800, self._demo_tick)

    def _toggle_pause_demo(self):
        self.demo_paused = not self.demo_paused
        self.btn_pause_demo.config(text="▶ Resume" if self.demo_paused else "⏸ Pause")

    def _open_stepper_modal(self):
        """Opens interactive Step-by-Step execution dialog."""
        dlg = tk.Toplevel(self)
        dlg.title("Step-by-Step Algorithm Execution")
        dlg.geometry("640 × 480".replace("×", "x"))
        dlg.configure(bg="#0f172a")

        files = self.simulator.storage.files
        if not files:
            messagebox.showinfo("Storage Empty", "No files available in storage repository.", parent=dlg)
            dlg.destroy()
            return

        # Selection row
        sel_frame = tk.Frame(dlg, bg="#0f172a", pady=10)
        sel_frame.pack(fill=tk.X, padx=16)

        tk.Label(sel_frame, text="Select File to Access: ", font=("Segoe UI", 10), fg="#f8fafc", bg="#0f172a").pack(side=tk.LEFT)
        file_names = [f.file_name for f in files]
        combo_var = tk.StringVar(value=file_names[0])
        combo = ttk.Combobox(sel_frame, textvariable=combo_var, values=file_names, state="readonly", width=25)
        combo.pack(side=tk.LEFT, padx=6)

        # Step card
        card = tk.Frame(dlg, bg="#1e293b", bd=1, relief=tk.SOLID, padx=16, pady=16)
        card.pack(fill=tk.BOTH, expand=True, padx=16, pady=8)

        step_num_lbl = tk.Label(card, text="STEP 1 OF --", font=("Segoe UI", 11, "bold"), fg="#38bdf8", bg="#1e293b")
        step_num_lbl.pack(anchor=tk.W)

        step_title_lbl = tk.Label(card, text="Ready", font=("Segoe UI", 14, "bold"), fg="#f8fafc", bg="#1e293b")
        step_title_lbl.pack(anchor=tk.W, pady=(4, 8))

        step_desc_lbl = tk.Label(card, text="Click 'Generate Steps' to trace through the LRU algorithm.", font=("Segoe UI", 10), fg="#cbd5e1", bg="#1e293b", justify=tk.LEFT, wraplength=560)
        step_desc_lbl.pack(anchor=tk.W, fill=tk.BOTH, expand=True)

        # Buttons
        btn_bar = tk.Frame(dlg, bg="#0f172a", pady=10)
        btn_bar.pack(fill=tk.X, padx=16)

        def generate_steps():
            nonlocal self
            target = combo_var.get()
            self.active_steps = self.simulator.get_step_by_step_trace(target)
            self.current_step_idx = 0
            show_step(0)

        def show_step(idx):
            nonlocal self
            if not self.active_steps:
                return
            idx = max(0, min(idx, len(self.active_steps) - 1))
            self.current_step_idx = idx
            st = self.active_steps[idx]

            step_num_lbl.config(text=f"STEP {idx + 1} OF {len(self.active_steps)}")
            step_title_lbl.config(text=st["title"])
            step_desc_lbl.config(text=st["description"])

            prev_btn.config(state=tk.NORMAL if idx > 0 else tk.DISABLED)
            next_btn.config(state=tk.NORMAL if idx < len(self.active_steps) - 1 else tk.DISABLED)

            # If last step, execute actual access
            if idx == len(self.active_steps) - 1:
                target = combo_var.get()
                self.simulator.access_file(target)
                self.draw_cache()
                if self.on_state_change:
                    self.on_state_change()

        def next_step():
            show_step(self.current_step_idx + 1)

        def prev_step():
            show_step(self.current_step_idx - 1)

        ttk.Button(sel_frame, text="Generate Steps", command=generate_steps).pack(side=tk.LEFT, padx=6)

        prev_btn = ttk.Button(btn_bar, text="◀ Previous", command=prev_step, state=tk.DISABLED)
        prev_btn.pack(side=tk.LEFT, padx=4)

        next_btn = ttk.Button(btn_bar, text="Next ▶", command=next_step, state=tk.DISABLED)
        next_btn.pack(side=tk.LEFT, padx=4)

        ttk.Button(btn_bar, text="Close", command=dlg.destroy).pack(side=tk.RIGHT, padx=4)

        generate_steps()
