"""
DSA Educational Concepts & Complexity View.
Explains:
- Hashing & Polynomial Rolling Hash
- Collision Resolution via Separate Chaining
- Doubly Linked List Mechanics
- LRU Replacement Strategy
- Combined HashMap + Doubly Linked List Architecture
- Asymptotic Complexity Analysis Table
"""

import tkinter as tk
from tkinter import ttk


class DSAView(ttk.Frame):
    """Educational DSA Concept Explainer and Complexity Reference."""

    def __init__(self, parent, **kwargs):
        super().__init__(parent, **kwargs)
        self._build_ui()

    def _build_ui(self):
        # Scrollable container
        canvas = tk.Canvas(self, bg="#0f172a", highlightthickness=0)
        scrollbar = ttk.Scrollbar(self, orient=tk.VERTICAL, command=canvas.yview)
        content = tk.Frame(canvas, bg="#0f172a")

        content.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        c_win = canvas.create_window((0, 0), window=content, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=16, pady=16)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y, pady=16)

        canvas.bind(
            "<Configure>",
            lambda e: canvas.itemconfig(c_win, width=e.width)
        )

        # Title
        tk.Label(
            content,
            text="Data Structures & Algorithms: The LRU Architecture",
            font=("Segoe UI", 16, "bold"),
            fg="#f8fafc",
            bg="#0f172a"
        ).pack(anchor=tk.W, pady=(0, 4))

        tk.Label(
            content,
            text="Understanding how HashMaps and Doubly Linked Lists synchronize to achieve O(1) cache access and eviction.",
            font=("Segoe UI", 10),
            fg="#94a3b8",
            bg="#0f172a"
        ).pack(anchor=tk.W, pady=(0, 16))

        # Concept Cards
        concepts = [
            (
                "1. Custom Hashing & Distribution",
                "Hash functions map variable-length string keys (e.g. 'report.pdf') into bounded integer bucket indices.\n"
                "We implement a polynomial rolling hash with prime base 31:\n\n"
                "    hash = 0\n"
                "    for character in key:\n"
                "        hash = (hash * 31 + ord(character)) % capacity\n\n"
                "This ensures good avalanche properties and avoids clustering across buckets without relying on built-in hash().",
                "#38bdf8"
            ),
            (
                "2. Collision Handling: Separate Chaining",
                "Due to the Pigeonhole Principle, when key count exceeds buckets (or by bad luck), multiple keys share the same hash index.\n"
                "In Separate Chaining, each bucket stores the head of a linked list of entries:\n\n"
                "    Bucket 0  →  [report.pdf]  →  [video.mp4]\n"
                "    Bucket 1  →  [image.jpg]\n"
                "    Bucket 2  →  EMPTY\n\n"
                "Average lookup remains O(1 + load_factor).",
                "#a855f7"
            ),
            (
                "3. Doubly Linked List for O(1) Reordering",
                "A Doubly Linked List maintains nodes with both 'previous' and 'next' references:\n\n"
                "    HEAD (MRU)  ⇄  [Node C]  ⇄  [Node A]  ⇄  [Node B]  ⇄  TAIL (LRU)\n\n"
                "Because a node contains pointers to both neighbors, detaching it and placing it at HEAD is strictly O(1) — no array shifts!",
                "#34d399"
            ),
            (
                "4. Combined LRU Cache Architecture",
                "The synergy of both structures provides optimal performance:\n\n"
                "    Custom HashMap       ──> Fast O(1) Node Address Lookup\n"
                "          ↓\n"
                "    Doubly Linked List   ──> Fast O(1) MRU Promotion & LRU Eviction\n"
                "          ↓\n"
                "    LRU File Cache       ──> Constant-Time In-Memory File Delivery",
                "#fbbf24"
            )
        ]

        for title, desc, accent in concepts:
            box = tk.Frame(content, bg="#1e293b", bd=1, relief=tk.SOLID)
            box.pack(fill=tk.X, expand=True, pady=8)

            tk.Label(
                box,
                text=title,
                font=("Segoe UI", 12, "bold"),
                fg=accent,
                bg="#1e293b"
            ).pack(anchor=tk.W, padx=14, pady=(12, 4))

            tk.Label(
                box,
                text=desc,
                font=("Segoe UI", 9),
                fg="#cbd5e1",
                bg="#1e293b",
                justify=tk.LEFT
            ).pack(anchor=tk.W, padx=14, pady=(0, 12))

        # Complexity Table
        tk.Label(
            content,
            text="Asymptotic Complexity Comparison",
            font=("Segoe UI", 13, "bold"),
            fg="#f8fafc",
            bg="#0f172a"
        ).pack(anchor=tk.W, pady=(16, 8))

        table_frame = tk.Frame(content, bg="#1e293b", bd=1, relief=tk.SOLID)
        table_frame.pack(fill=tk.X, expand=True, pady=(0, 20))

        headers = ["Operation", "Time Complexity (Average)", "Time Complexity (Worst)", "Space Complexity", "Technical Notes"]
        for col_idx, h in enumerate(headers):
            lbl = tk.Label(table_frame, text=h, font=("Segoe UI", 9, "bold"), fg="#38bdf8", bg="#0f172a", padx=8, pady=6)
            lbl.grid(row=0, column=col_idx, sticky="nsew", padx=1, pady=1)

        rows = [
            ("HashMap GET", "O(1)", "O(N) [All Collisions]", "O(1) extra", "Navigates bucket chain"),
            ("HashMap PUT", "O(1)", "O(N) [All Collisions]", "O(1) extra", "Inserts at head of chain"),
            ("LRU Cache GET", "O(1)", "O(N)", "O(1)", "HashMap lookup + DLL move to front"),
            ("LRU Cache PUT", "O(1)", "O(N)", "O(1)", "Check capacity + remove tail + insert head"),
            ("Move to MRU", "O(1)", "O(1)", "O(1)", "Pointer rewiring in DLL"),
            ("Remove LRU Tail", "O(1)", "O(1)", "O(1)", "Unlink tail node in DLL"),
            ("Total Cache Space", "O(Capacity)", "O(Capacity)", "O(Capacity)", "Stores nodes in DLL & HashMap buckets")
        ]

        for row_idx, row_data in enumerate(rows, start=1):
            bg_color = "#1e293b" if row_idx % 2 == 0 else "#243248"
            for col_idx, cell in enumerate(row_data):
                lbl = tk.Label(table_frame, text=cell, font=("Segoe UI", 9), fg="#e2e8f0", bg=bg_color, padx=8, pady=5)
                lbl.grid(row=row_idx, column=col_idx, sticky="nsew", padx=1, pady=1)

        for i in range(5):
            table_frame.grid_columnconfigure(i, weight=1)
