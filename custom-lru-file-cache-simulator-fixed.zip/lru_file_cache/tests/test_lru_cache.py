import unittest
from lru_file_cache.models.file_node import FileNode
from lru_file_cache.dsa.lru_cache import LRUCache


class TestLRUCache(unittest.TestCase):

    def setUp(self):
        self.cache = LRUCache(capacity=3)

    def test_required_lru_test_1(self):
        """
        capacity = 3
        put(A)
        put(B)
        put(C)
        get(A)
        put(D)
        Expected: D -> A -> C (B must be evicted)
        """
        node_a = FileNode("A", "fileA.txt", "TXT", 1.0)
        node_b = FileNode("B", "fileB.txt", "TXT", 1.0)
        node_c = FileNode("C", "fileC.txt", "TXT", 1.0)
        node_d = FileNode("D", "fileD.txt", "TXT", 1.0)

        self.cache.put(node_a)
        self.cache.put(node_b)
        self.cache.put(node_c)
        # Order is C -> B -> A

        # get(A) makes A MRU: A -> C -> B
        node, hit = self.cache.get("A")
        self.assertTrue(hit)
        self.assertEqual(node.file_id, "A")

        order_after_get = [n.file_id for n in self.cache.get_state()]
        self.assertEqual(order_after_get, ["A", "C", "B"])

        # put(D): cache is full (capacity=3), LRU is B -> B is evicted
        evicted = self.cache.put(node_d)
        self.assertEqual(len(evicted), 1)
        self.assertEqual(evicted[0].file_id, "B")

        # Final order: D -> A -> C
        final_order = [n.file_id for n in self.cache.get_state()]
        self.assertEqual(final_order, ["D", "A", "C"])
        self.assertFalse(self.cache.contains("B"))
        self.assertTrue(self.cache.contains("D"))
        self.assertTrue(self.cache.contains("A"))
        self.assertTrue(self.cache.contains("C"))

    def test_required_lru_test_2(self):
        """
        put(A)
        put(B)
        put(C)
        get(B)
        put(D)
        Expected: D -> B -> C (A must be evicted)
        """
        node_a = FileNode("A", "fileA.txt", "TXT", 1.0)
        node_b = FileNode("B", "fileB.txt", "TXT", 1.0)
        node_c = FileNode("C", "fileC.txt", "TXT", 1.0)
        node_d = FileNode("D", "fileD.txt", "TXT", 1.0)

        self.cache.put(node_a)
        self.cache.put(node_b)
        self.cache.put(node_c)
        # Order: C -> B -> A

        # get(B) moves B to MRU: B -> C -> A
        node, hit = self.cache.get("B")
        self.assertTrue(hit)

        order_after_get = [n.file_id for n in self.cache.get_state()]
        self.assertEqual(order_after_get, ["B", "C", "A"])

        # put(D): A is at tail (LRU) -> A evicted
        evicted = self.cache.put(node_d)
        self.assertEqual(len(evicted), 1)
        self.assertEqual(evicted[0].file_id, "A")

        # Expected: D -> B -> C
        final_order = [n.file_id for n in self.cache.get_state()]
        self.assertEqual(final_order, ["D", "B", "C"])

    def test_prompt_section_50_demonstration(self):
        """
        Access report.pdf -> MISS -> Insert
        Access image.jpg -> MISS -> Insert
        Access video.mp4 -> MISS -> Insert
        Access report.pdf -> HIT -> Move report.pdf to MRU
        Access database.sql -> MISS -> Cache full -> Evict image.jpg -> Insert database.sql
        Final cache: database.sql -> report.pdf -> video.mp4
        Hits: 1, Misses: 4, Evictions: 1, Hit Rate: 20%
        """
        f1 = FileNode("f1", "report.pdf", "PDF", 2.4)
        f2 = FileNode("f2", "image.jpg", "JPG", 4.1)
        f3 = FileNode("f3", "video.mp4", "MP4", 15.0)
        f4 = FileNode("f4", "database.sql", "SQL", 5.2)

        # 1. report.pdf
        _, hit1 = self.cache.get("f1")
        self.assertFalse(hit1)
        self.cache.put(f1)

        # 2. image.jpg
        _, hit2 = self.cache.get("f2")
        self.assertFalse(hit2)
        self.cache.put(f2)

        # 3. video.mp4
        _, hit3 = self.cache.get("f3")
        self.assertFalse(hit3)
        self.cache.put(f3)

        # 4. report.pdf
        _, hit4 = self.cache.get("f1")
        self.assertTrue(hit4)

        # 5. database.sql
        _, hit5 = self.cache.get("f4")
        self.assertFalse(hit5)
        evicted = self.cache.put(f4)

        self.assertEqual(len(evicted), 1)
        self.assertEqual(evicted[0].file_name, "image.jpg")

        final_names = [n.file_name for n in self.cache.get_state()]
        self.assertEqual(final_names, ["database.sql", "report.pdf", "video.mp4"])

        stats = self.cache.get_statistics()
        self.assertEqual(stats["cache_hits"], 1)
        self.assertEqual(stats["cache_misses"], 4)
        self.assertEqual(stats["evictions"], 1)
        self.assertEqual(stats["hit_rate_pct"], 20.0)

    def test_capacity_reduction(self):
        c = LRUCache(capacity=4)
        c.put(FileNode("1", "f1", "TXT", 1.0))
        c.put(FileNode("2", "f2", "TXT", 1.0))
        c.put(FileNode("3", "f3", "TXT", 1.0))
        c.put(FileNode("4", "f4", "TXT", 1.0))
        self.assertEqual(c.current_size, 4)

        # Resize to 2: should evict 2 items (f1, f2)
        evicted = c.set_capacity(2)
        self.assertEqual(len(evicted), 2)
        self.assertEqual(c.current_size, 2)
        self.assertEqual([n.file_id for n in c.get_state()], ["4", "3"])


if __name__ == "__main__":
    unittest.main()
