import unittest
from lru_file_cache.models.file_node import FileNode
from lru_file_cache.dsa.doubly_linked_list import DoublyLinkedList


class TestDoublyLinkedList(unittest.TestCase):

    def setUp(self):
        self.dll = DoublyLinkedList()
        self.node_a = FileNode("A", "file_a.txt", "TXT", 1.0)
        self.node_b = FileNode("B", "file_b.jpg", "JPG", 2.0)
        self.node_c = FileNode("C", "file_c.pdf", "PDF", 3.0)

    def test_empty_list(self):
        self.assertEqual(self.dll.size(), 0)
        self.assertTrue(self.dll.is_empty())
        self.assertIsNone(self.dll.get_first())
        self.assertIsNone(self.dll.get_last())
        self.assertIsNone(self.dll.remove_last())

    def test_single_element(self):
        self.dll.add_to_front(self.node_a)
        self.assertEqual(self.dll.size(), 1)
        self.assertEqual(self.dll.get_first().file_id, "A")
        self.assertEqual(self.dll.get_last().file_id, "A")

        removed = self.dll.remove_last()
        self.assertEqual(removed.file_id, "A")
        self.assertEqual(self.dll.size(), 0)
        self.assertIsNone(self.dll.get_first())
        self.assertIsNone(self.dll.get_last())

    def test_add_and_ordering(self):
        self.dll.add_to_front(self.node_a)
        self.dll.add_to_front(self.node_b)
        self.dll.add_to_front(self.node_c)

        # Expected MRU -> C -> B -> A -> LRU
        nodes = self.dll.to_list()
        self.assertEqual([n.file_id for n in nodes], ["C", "B", "A"])
        self.assertEqual(self.dll.get_first().file_id, "C")
        self.assertEqual(self.dll.get_last().file_id, "A")

    def test_remove_middle(self):
        self.dll.add_to_front(self.node_a)
        self.dll.add_to_front(self.node_b)
        self.dll.add_to_front(self.node_c)
        # Order: C -> B -> A

        self.dll.remove_node(self.node_b)
        nodes = self.dll.to_list()
        self.assertEqual([n.file_id for n in nodes], ["C", "A"])
        self.assertEqual(self.dll.size(), 2)

    def test_move_to_front(self):
        self.dll.add_to_front(self.node_a)
        self.dll.add_to_front(self.node_b)
        self.dll.add_to_front(self.node_c)
        # Order: C -> B -> A

        self.dll.move_to_front(self.node_a)
        # Expected: A -> C -> B
        nodes = self.dll.to_list()
        self.assertEqual([n.file_id for n in nodes], ["A", "C", "B"])
        self.assertEqual(self.dll.get_first().file_id, "A")
        self.assertEqual(self.dll.get_last().file_id, "B")


if __name__ == "__main__":
    unittest.main()
