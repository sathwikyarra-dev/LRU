import unittest
from lru_file_cache.dsa.custom_hash_map import CustomHashMap


class TestCustomHashMap(unittest.TestCase):

    def setUp(self):
        self.hm = CustomHashMap(capacity=4)

    def test_put_and_get(self):
        self.hm.put("file1", "content1")
        self.hm.put("file2", "content2")
        self.assertEqual(self.hm.get("file1"), "content1")
        self.assertEqual(self.hm.get("file2"), "content2")
        self.assertIsNone(self.hm.get("nonexistent"))
        self.assertEqual(self.hm.size(), 2)

    def test_update_duplicate_key(self):
        self.hm.put("keyA", "first_value")
        self.assertEqual(self.hm.get("keyA"), "first_value")
        self.assertEqual(self.hm.size(), 1)

        # Update
        self.hm.put("keyA", "second_value")
        self.assertEqual(self.hm.get("keyA"), "second_value")
        self.assertEqual(self.hm.size(), 1)

    def test_remove(self):
        self.hm.put("k1", "v1")
        self.hm.put("k2", "v2")
        self.assertTrue(self.hm.contains("k1"))
        
        val = self.hm.remove("k1")
        self.assertEqual(val, "v1")
        self.assertFalse(self.hm.contains("k1"))
        self.assertEqual(self.hm.size(), 1)
        self.assertIsNone(self.hm.remove("nonexistent"))

    def test_collision_handling(self):
        # By having small capacity (4), multiple keys will hash to the same bucket
        self.hm.put("alpha", "1")
        self.hm.put("beta", "2")
        self.hm.put("gamma", "3")
        self.hm.put("delta", "4")
        self.hm.put("epsilon", "5")

        self.assertEqual(self.hm.size(), 5)
        self.assertEqual(self.hm.get("alpha"), "1")
        self.assertEqual(self.hm.get("beta"), "2")
        self.assertEqual(self.hm.get("gamma"), "3")
        self.assertEqual(self.hm.get("delta"), "4")
        self.assertEqual(self.hm.get("epsilon"), "5")

        diagnostics = self.hm.get_diagnostics()
        self.assertGreaterEqual(diagnostics["entries"], 5)
        self.assertTrue(any(b["count"] > 1 for b in diagnostics["buckets"]))

    def test_clear(self):
        self.hm.put("k1", "v1")
        self.hm.put("k2", "v2")
        self.hm.clear()
        self.assertEqual(self.hm.size(), 0)
        self.assertFalse(self.hm.contains("k1"))


if __name__ == "__main__":
    unittest.main()
