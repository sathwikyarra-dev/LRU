"""
Persistence & Export Utilities for LRU File Cache Simulator.
Supports JSON state saving/loading and CSV/JSON report exports.
"""

import csv
import json
import os
from typing import Any, Dict, Optional
from ..simulator.simulator import Simulator
from ..models.file_node import FileNode


def save_state(simulator: Simulator, filepath: str = "lru_file_cache/data/cache_state.json") -> bool:
    """Serializes full simulator state to JSON."""
    try:
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        stats = simulator.cache.get_statistics()
        cache_nodes = [node.to_dict() for node in simulator.cache.get_state()]
        storage_files = [f.to_dict() for f in simulator.storage.files]

        state = {
            "capacity": simulator.cache.capacity,
            "policy": simulator.cache.policy,
            "max_memory_mb": simulator.cache.max_memory_mb,
            "statistics": stats,
            "cache_nodes": cache_nodes,
            "storage_files": storage_files,
            "activity_logs": simulator.activity_logs[-100:],  # keep last 100 entries
        }

        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(state, f, indent=2)
        return True
    except Exception as e:
        print(f"Error saving state: {e}")
        return False


def load_state(simulator: Simulator, filepath: str = "lru_file_cache/data/cache_state.json") -> bool:
    """Restores simulator state from JSON."""
    try:
        if not os.path.exists(filepath):
            return False

        with open(filepath, "r", encoding="utf-8") as f:
            state = json.load(f)

        # Restore capacity & policy
        simulator.cache.capacity = state.get("capacity", 5)
        simulator.cache.policy = state.get("policy", "max_files")
        simulator.cache.max_memory_mb = state.get("max_memory_mb", 50.0)

        # Restore storage files
        if "storage_files" in state:
            simulator.storage.files = [
                FileNode(
                    f["file_id"],
                    f["file_name"],
                    f["file_type"],
                    f["file_size"],
                    f.get("created_at"),
                    f.get("last_accessed"),
                    f.get("access_count", 0),
                )
                for f in state["storage_files"]
            ]

        # Restore cache
        simulator.cache.clear()
        if "cache_nodes" in state:
            # Nodes are saved from MRU to LRU, so inserting in reverse puts them in proper order
            for node_data in reversed(state["cache_nodes"]):
                node = FileNode(
                    node_data["file_id"],
                    node_data["file_name"],
                    node_data["file_type"],
                    node_data["file_size"],
                    node_data.get("created_at"),
                    node_data.get("last_accessed"),
                    node_data.get("access_count", 0),
                )
                simulator.cache.put(node)

        # Restore statistics
        if "statistics" in state:
            s = state["statistics"]
            simulator.cache.cache_hits = s.get("cache_hits", 0)
            simulator.cache.cache_misses = s.get("cache_misses", 0)
            simulator.cache.evictions = s.get("evictions", 0)
            simulator.cache.total_requests = s.get("total_requests", 0)

        # Restore logs
        if "activity_logs" in state:
            simulator.activity_logs = state["activity_logs"]

        return True
    except Exception as e:
        print(f"Error loading state: {e}")
        return False


def export_json_report(simulator: Simulator, filepath: str) -> bool:
    """Exports structured performance and cache audit report as JSON."""
    try:
        stats = simulator.cache.get_statistics()
        cache_state = [f.to_dict() for f in simulator.cache.get_state()]
        report = {
            "report_title": "LRU File Cache Simulator Performance Report",
            "statistics": stats,
            "cache_state": cache_state,
            "total_cached_files": len(cache_state),
            "activity_history": simulator.activity_logs,
        }
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2)
        return True
    except Exception as e:
        print(f"Error exporting JSON: {e}")
        return False


def export_csv_report(simulator: Simulator, filepath: str) -> bool:
    """Exports activity and cache log as CSV."""
    try:
        with open(filepath, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["ID", "Timestamp", "Operation", "File Name", "Status", "Latency (ms)", "Details"])
            for log in simulator.activity_logs:
                writer.writerow([
                    log.get("id"),
                    log.get("timestamp"),
                    log.get("operation"),
                    log.get("file_name"),
                    log.get("status"),
                    log.get("latency_ms"),
                    log.get("details"),
                ])
        return True
    except Exception as e:
        print(f"Error exporting CSV: {e}")
        return False
