"""
UI formatting and style helpers.
"""


def format_bytes(size_mb: float) -> str:
    """Formats size in MB or KB."""
    if size_mb < 0.1:
        return f"{int(size_mb * 1024)} KB"
    return f"{size_mb:.1f} MB"


def get_file_type_badge_color(file_type: str) -> str:
    """Returns color hex corresponding to file category."""
    mapping = {
        "PDF": "#ef4444",    # Red
        "DOCX": "#3b82f6",   # Blue
        "JPG": "#10b981",    # Emerald
        "JPEG": "#10b981",
        "PNG": "#10b981",
        "MP4": "#8b5cf6",    # Violet
        "TXT": "#64748b",    # Slate
        "SQL": "#f59e0b",    # Amber
        "CSV": "#06b6d4",    # Cyan
        "PPTX": "#f97316",   # Orange
        "MP3": "#ec4899",    # Pink
        "ZIP": "#a855f7",    # Purple
    }
    return mapping.get(file_type.upper(), "#64748b")
