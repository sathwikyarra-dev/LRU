"""
Main Application Entry Point for Custom LRU-Based File Cache Simulator.
Constructs the 1280x800 desktop application with dark navy theme,
sidebar navigation, and integrated views.
"""

import os
import sys
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

from lru_file_cache.simulator.simulator import Simulator
from lru_file_cache.gui.dashboard import DashboardView
from lru_file_cache.gui.cache_view import CacheView
from lru_file_cache.gui.storage_view import StorageView
from lru_file_cache.gui.hashmap_view import HashMapView
from lru_file_cache.gui.statistics_view import StatisticsView
from lru_file_cache.gui.activity_view import ActivityView
from lru_file_cache.gui.dsa_view import DSAView
from lru_file_cache.gui.viva_view import VivaView
from lru_file_cache.utils.persistence import save_state, load_state, export_json_report, export_csv_report


class LRUSimulatorApp:
    """Main desktop application window and navigation controller."""

    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Custom LRU File Cache Simulator")
        self.root.geometry("1280x800")
        self.root.minsize(1024, 680)

        # Initialize Simulator Core
        data_path = os.path.join(os.path.dirname(__file__), "data", "files.json")
        self.simulator = Simulator(capacity=5, policy="max_files", max_memory_mb=50.0)

        # Apply dark theme styling
        self._setup_theme()

        # Build Main Layout: Header, Sidebar, and Content Deck
        self._build_layout()

        # Switch to default view
        self.show_view("dashboard")

    def _setup_theme(self):
        style = ttk.Style()
        style.theme_use("clam")

        self.root.configure(bg="#0b1329")

        # Custom ttk styles
        style.configure("TFrame", background="#0b1329")
        style.configure("TLabel", background="#0b1329", foreground="#f8fafc")
        style.configure(
            "TButton",
            background="#1e293b",
            foreground="#f8fafc",
            borderwidth=1,
            focuscolor="none",
            font=("Segoe UI", 9)
        )
        style.map(
            "TButton",
            background=[("active", "#38bdf8"), ("pressed", "#0284c7")],
            foreground=[("active", "#0f172a"), ("pressed", "#ffffff")]
        )
        style.configure("Treeview", background="#1e293b", foreground="#f8fafc", fieldbackground="#1e293b", borderwidth=0)
        style.map("Treeview", background=[("selected", "#0284c7")])
        style.configure("Treeview.Heading", background="#0f172a", foreground="#38bdf8", font=("Segoe UI", 9, "bold"))

    def _build_layout(self):
        # 1. Top Header Banner
        top_header = tk.Frame(self.root, bg="#0f172a", bd=1, relief=tk.SOLID, height=54)
        top_header.pack(fill=tk.X, side=tk.TOP)

        title_lbl = tk.Label(
            top_header,
            text="CUSTOM LRU FILE CACHE SIMULATOR",
            font=("Segoe UI", 13, "bold"),
            fg="#38bdf8",
            bg="#0f172a",
            padx=16
        )
        title_lbl.pack(side=tk.LEFT)

        subtitle_lbl = tk.Label(
            top_header,
            text="HashMap + Doubly Linked List • DSA Academic Visualizer",
            font=("Segoe UI", 9),
            fg="#94a3b8",
            bg="#0f172a"
        )
        subtitle_lbl.pack(side=tk.LEFT, padx=4)

        # Header utility buttons (Save, Load, Export, Reset)
        hdr_actions = tk.Frame(top_header, bg="#0f172a")
        hdr_actions.pack(side=tk.RIGHT, padx=16)

        ttk.Button(hdr_actions, text="💾 Save", command=self._save_state).pack(side=tk.LEFT, padx=3)
        ttk.Button(hdr_actions, text="📂 Load", command=self._load_state).pack(side=tk.LEFT, padx=3)
        ttk.Button(hdr_actions, text="📊 Export", command=self._open_export_dialog).pack(side=tk.LEFT, padx=3)
        ttk.Button(hdr_actions, text="🔄 Reset", command=self._confirm_reset).pack(side=tk.LEFT, padx=3)

        # 2. Main Body (Sidebar + Content Deck)
        body = tk.Frame(self.root, bg="#0b1329")
        body.pack(fill=tk.BOTH, expand=True)

        # Sidebar Navigation
        sidebar = tk.Frame(body, bg="#0f172a", width=220, bd=1, relief=tk.SOLID)
        sidebar.pack(side=tk.LEFT, fill=tk.Y)
        sidebar.pack_propagate(False)

        nav_title = tk.Label(sidebar, text="NAVIGATION", font=("Segoe UI", 8, "bold"), fg="#64748b", bg="#0f172a")
        nav_title.pack(anchor=tk.W, padx=16, pady=(16, 6))

        self.nav_buttons = {}
        nav_items = [
            ("dashboard", "📊 Dashboard"),
            ("cache", "⚡ Cache Memory"),
            ("storage", "💾 File Storage"),
            ("hashmap", "🗄️ Custom HashMap"),
            ("statistics", "📈 Statistics & Lab"),
            ("activity", "📋 Activity Log"),
            ("dsa", "📘 DSA Concepts"),
            ("viva", "🎓 Viva Mode"),
        ]

        for key, label in nav_items:
            btn = tk.Button(
                sidebar,
                text=label,
                font=("Segoe UI", 10),
                fg="#cbd5e1",
                bg="#0f172a",
                activebackground="#1e293b",
                activeforeground="#38bdf8",
                relief=tk.FLAT,
                anchor=tk.W,
                padx=16,
                pady=10,
                cursor="hand2",
                command=lambda k=key: self.show_view(k)
            )
            btn.pack(fill=tk.X)
            self.nav_buttons[key] = btn

        # Sidebar pattern generator trigger
        tk.Label(sidebar, text="WORKLOAD GENERATOR", font=("Segoe UI", 8, "bold"), fg="#64748b", bg="#0f172a").pack(anchor=tk.W, padx=16, pady=(24, 6))
        ttk.Button(sidebar, text="⚡ Run Pattern", command=self._open_pattern_dialog).pack(fill=tk.X, padx=14, pady=4)

        # Content Deck
        self.content_frame = tk.Frame(body, bg="#0b1329")
        self.content_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Instantiate Views
        self.views = {
            "dashboard": DashboardView(self.content_frame, self.simulator, on_state_change=self._notify_all_views),
            "cache": CacheView(self.content_frame, self.simulator, on_state_change=self._notify_all_views),
            "storage": StorageView(self.content_frame, self.simulator, on_state_change=self._notify_all_views),
            "hashmap": HashMapView(self.content_frame, self.simulator),
            "statistics": StatisticsView(self.content_frame, self.simulator),
            "activity": ActivityView(self.content_frame, self.simulator),
            "dsa": DSAView(self.content_frame),
            "viva": VivaView(self.content_frame),
        }

    def show_view(self, key: str):
        """Switches active view panel and highlights active navigation button."""
        for v_key, view in self.views.items():
            if v_key == key:
                view.pack(fill=tk.BOTH, expand=True)
                # Refresh view contents if it has a refresh handler
                if hasattr(view, "refresh_dashboard"):
                    view.refresh_dashboard()
                elif hasattr(view, "draw_cache"):
                    view.draw_cache()
                elif hasattr(view, "refresh_table"):
                    view.refresh_table()
                elif hasattr(view, "refresh_view"):
                    view.refresh_view()
                elif hasattr(view, "refresh_charts"):
                    view.refresh_charts()
                elif hasattr(view, "refresh_log"):
                    view.refresh_log()
            else:
                view.pack_forget()

        # Update button highlights
        for b_key, btn in self.nav_buttons.items():
            if b_key == key:
                btn.configure(bg="#1e293b", fg="#38bdf8", font=("Segoe UI", 10, "bold"))
            else:
                btn.configure(bg="#0f172a", fg="#cbd5e1", font=("Segoe UI", 10))

    def _notify_all_views(self):
        """Called whenever cache state or storage changes to keep all tabs synchronized."""
        if hasattr(self.views["dashboard"], "refresh_dashboard"):
            self.views["dashboard"].refresh_dashboard()
        if hasattr(self.views["cache"], "draw_cache"):
            self.views["cache"].draw_cache()
        if hasattr(self.views["storage"], "refresh_table"):
            self.views["storage"].refresh_table()
        if hasattr(self.views["hashmap"], "refresh_view"):
            self.views["hashmap"].refresh_view()
        if hasattr(self.views["activity"], "refresh_log"):
            self.views["activity"].refresh_log()
        if hasattr(self.views["statistics"], "refresh_charts"):
            self.views["statistics"].refresh_charts()

    def _confirm_reset(self):
        """Prompt confirmation for clearing simulator state."""
        msg = "This will clear:\n\n• Cache memory\n• Statistics & Hit counts\n• Activity Log\n• Request Timeline\n\nContinue?"
        if messagebox.askyesno("Reset Simulator", msg):
            self.simulator.reset()
            self._notify_all_views()
            messagebox.showinfo("Reset Complete", "Simulator reset to fresh initial state.")

    def _save_state(self):
        saved = save_state(self.simulator)
        if saved:
            messagebox.showinfo("Saved", "State saved to data/cache_state.json")
        else:
            messagebox.showerror("Error", "Failed to save state.")

    def _load_state(self):
        loaded = load_state(self.simulator)
        if loaded:
            self._notify_all_views()
            messagebox.showinfo("Loaded", "State restored from data/cache_state.json")
        else:
            messagebox.showinfo("Notice", "No saved state found at data/cache_state.json")

    def _open_export_dialog(self):
        """Exports audit report as CSV or JSON."""
        dlg = tk.Toplevel(self.root)
        dlg.title("Export Report")
        dlg.geometry("380x200")
        dlg.configure(bg="#0f172a")

        tk.Label(dlg, text="Export Performance Report", font=("Segoe UI", 12, "bold"), fg="#f8fafc", bg="#0f172a").pack(pady=12)

        def do_json():
            fpath = filedialog.asksaveasfilename(defaultextension=".json", filetypes=[("JSON files", "*.json")])
            if fpath:
                export_json_report(self.simulator, fpath)
                messagebox.showinfo("Export Successful", f"Report exported to {fpath}", parent=dlg)
                dlg.destroy()

        def do_csv():
            fpath = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files", "*.csv")])
            if fpath:
                export_csv_report(self.simulator, fpath)
                messagebox.showinfo("Export Successful", f"Activity log exported to {fpath}", parent=dlg)
                dlg.destroy()

        btn_box = tk.Frame(dlg, bg="#0f172a")
        btn_box.pack(pady=12)
        ttk.Button(btn_box, text="Export JSON Report", command=do_json).pack(side=tk.LEFT, padx=6)
        ttk.Button(btn_box, text="Export CSV Activity Log", command=do_csv).pack(side=tk.LEFT, padx=6)

    def _open_pattern_dialog(self):
        """Access pattern generator dialog (Section 31)."""
        dlg = tk.Toplevel(self.root)
        dlg.title("Workload & Access Pattern Generator")
        dlg.geometry("520x340")
        dlg.configure(bg="#0f172a")

        tk.Label(dlg, text="Access Pattern Generator", font=("Segoe UI", 14, "bold"), fg="#f8fafc", bg="#0f172a").pack(pady=10)

        card = tk.Frame(dlg, bg="#1e293b", padx=16, pady=12)
        card.pack(fill=tk.BOTH, expand=True, padx=16, pady=4)

        tk.Label(card, text="Select Workload Pattern:", font=("Segoe UI", 10, "bold"), fg="#38bdf8", bg="#1e293b").pack(anchor=tk.W)

        patterns = {
            "Sequential Scan": "report.pdf, assignment.docx, photo.jpg, video.mp4, notes.txt, database.sql",
            "Repeated Hot Set": "report.pdf, assignment.docx, report.pdf, assignment.docx, report.pdf, photo.jpg",
            "Hot / Cold Skew": "report.pdf, report.pdf, video.mp4, report.pdf, music.mp3, report.pdf, project.zip",
            "Random Access": "assignment.docx, database.sql, report.pdf, project.zip, photo.jpg, dataset.csv",
        }

        pattern_var = tk.StringVar(value="Repeated Hot Set")
        pat_combo = ttk.Combobox(card, textvariable=pattern_var, values=list(patterns.keys()), state="readonly", width=30)
        pat_combo.pack(anchor=tk.W, pady=6)

        seq_var = tk.StringVar(value=patterns["Repeated Hot Set"])
        seq_entry = ttk.Entry(card, textvariable=seq_var, width=54)
        seq_entry.pack(anchor=tk.W, pady=6)

        def on_pat_change(e):
            sel = pattern_var.get()
            seq_var.set(patterns.get(sel, ""))

        pat_combo.bind("<<ComboboxSelected>>", on_pat_change)

        def execute():
            items = [s.strip() for s in seq_var.get().split(",") if s.strip()]
            for item in items:
                self.simulator.access_file(item)
            self._notify_all_views()
            dlg.destroy()
            messagebox.showinfo("Workload Processed", f"Executed {len(items)} requests successfully.\nCheck Dashboard and Statistics for updated hit rates.")

        btn_bar = tk.Frame(dlg, bg="#0f172a", pady=10)
        btn_bar.pack(fill=tk.X, padx=16)
        ttk.Button(btn_bar, text="Cancel", command=dlg.destroy).pack(side=tk.RIGHT, padx=4)
        ttk.Button(btn_bar, text="Execute Workload", command=execute).pack(side=tk.RIGHT, padx=4)


def main():
    # Check if a display is available for Tkinter
    display = os.environ.get("DISPLAY")
    if not display and sys.platform.startswith("linux"):
        print("\n=======================================================")
        print("  CUSTOM LRU-BASED FILE CACHE SIMULATOR (CLI Mode)     ")
        print("=======================================================")
        print("Notice: No graphical X11 DISPLAY detected.")
        print("Running simulator verification suite...")
        sim = Simulator(capacity=3)
        print("\n--- Executing Required LRU Test Demonstration ---")
        seq = ["report.pdf", "photo.jpg", "video.mp4", "report.pdf", "database.sql"]
        for fname in seq:
            res = sim.access_file(fname)
            if res.get("success"):
                print(f"Access '{fname}': Status={res['status']}, Latency={res['latency_ms']}ms")
            else:
                print(f"Access '{fname}': Failed - {res.get('error')}")
        print("\nFinal Cache State (MRU -> LRU):")
        for node in sim.cache.get_state():
            print(f"  [{node.file_name}] - Type: {node.file_type}, Hits: {node.access_count}")
        stats = sim.cache.get_statistics()
        print(f"\nStatistics: Hits={stats['cache_hits']}, Misses={stats['cache_misses']}, "
              f"Evictions={stats['evictions']}, Hit Rate={stats['hit_rate_pct']}%")
        print("\nTo launch the complete Tkinter GUI on Windows/macOS/Linux Desktop:")
        print("  python main.py")
        print("=======================================================\n")
        return

    root = tk.Tk()
    app = LRUSimulatorApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
