"""
Simulated File Storage (Repository / Disk Storage layer).
Stores persistent file assets and simulates retrieval latency.
"""

import json
import os
from typing import Dict, List, Optional
from ..models.file_node import FileNode


class FileStorage:
    """
    Simulates secondary disk storage where files reside before being cached in memory.
    """

    def __init__(self, data_file_path: Optional[str] = None):
        self.files: List[FileNode] = []
        if data_file_path and os.path.exists(data_file_path):
            self.load_from_json(data_file_path)
        else:
            self._load_defaults()

    def _load_defaults(self) -> None:
        """Initializes storage with 10 standard simulation files."""
        defaults = [
            ("F001", "report.pdf", "PDF", 2.4),
            ("F002", "assignment.docx", "DOCX", 1.2),
            ("F003", "photo.jpg", "JPG", 4.1),
            ("F004", "video.mp4", "MP4", 28.5),
            ("F005", "notes.txt", "TXT", 0.05),
            ("F006", "database.sql", "SQL", 6.8),
            ("F007", "dataset.csv", "CSV", 12.3),
            ("F008", "presentation.pptx", "PPTX", 8.7),
            ("F009", "music.mp3", "MP3", 5.4),
            ("F010", "project.zip", "ZIP", 19.8),
        ]
        self.files = [FileNode(fid, name, ftype, size) for fid, name, ftype, size in defaults]

    def add_file(self, file_node: FileNode) -> bool:
        """Adds a new file to storage if ID does not already exist."""
        if any(f.file_id == file_node.file_id for f in self.files):
            return False
        self.files.append(file_node)
        return True

    def delete_file(self, file_id: str) -> Optional[FileNode]:
        """Deletes a file by ID from secondary storage."""
        for i, f in enumerate(self.files):
            if f.file_id == file_id:
                return self.files.pop(i)
        return None

    def get_file(self, file_id: str) -> Optional[FileNode]:
        """Finds a file by ID."""
        for f in self.files:
            if f.file_id == file_id:
                return f
        return None

    def get_by_name(self, file_name: str) -> Optional[FileNode]:
        """Finds a file by exact file name."""
        for f in self.files:
            if f.file_name.lower() == file_name.lower():
                return f
        return None

    def list_files(self, search: str = "", category: str = "All") -> List[FileNode]:
        """Filters files by search keyword and category."""
        results = []
        search_lower = search.strip().lower()

        category_map = {
            "PDF": ["PDF"],
            "Images": ["JPG", "JPEG", "PNG", "GIF", "WEBP"],
            "Videos": ["MP4", "MKV", "AVI", "MOV"],
            "Documents": ["DOCX", "TXT", "PPTX", "PDF"],
            "Data": ["CSV", "SQL", "JSON", "XML"],
        }

        for f in self.files:
            # Search filter
            matches_search = (
                not search_lower or
                search_lower in f.file_id.lower() or
                search_lower in f.file_name.lower() or
                search_lower in f.file_type.lower()
            )
            if not matches_search:
                continue

            # Category filter
            if category == "All":
                results.append(f)
            elif category in category_map and f.file_type in category_map[category]:
                results.append(f)
            elif category == "Other":
                all_known = [ext for exts in category_map.values() for ext in exts]
                if f.file_type not in all_known:
                    results.append(f)
            else:
                results.append(f)

        return results

    def save_to_json(self, filepath: str) -> None:
        """Serializes files to JSON."""
        data = [f.to_dict() for f in self.files]
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        with open(filepath, "w", encoding="utf-8") as fp:
            json.dump(data, fp, indent=2)

    def load_from_json(self, filepath: str) -> None:
        """Loads files from JSON."""
        with open(filepath, "r", encoding="utf-8") as fp:
            data = json.load(fp)
            self.files = [
                FileNode(
                    item["file_id"],
                    item["file_name"],
                    item["file_type"],
                    item["file_size"],
                    item.get("created_at"),
                    item.get("last_accessed"),
                    item.get("access_count", 0),
                )
                for item in data
            ]
