import datetime
from typing import Optional


class FileNode:
    """Represents a simulated file stored in the Doubly Linked List and Hash Map."""

    def __init__(
        self,
        file_id: str,
        file_name: str,
        file_type: str,
        file_size: float,
        created_at: Optional[str] = None,
        last_accessed: Optional[str] = None,
        access_count: int = 0
    ):
        self.file_id: str = str(file_id)
        self.file_name: str = str(file_name)
        self.file_type: str = str(file_type).upper()
        self.file_size: float = float(file_size)  # in MB

        now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.created_at: str = created_at if created_at else now_str
        self.last_accessed: Optional[str] = last_accessed
        self.access_count: int = access_count

        # Doubly Linked List pointers
        self.previous: Optional["FileNode"] = None
        self.next: Optional["FileNode"] = None

    def record_access(self) -> None:
        """Increment access counter and update timestamp."""
        self.access_count += 1
        self.last_accessed = datetime.datetime.now().strftime("%H:%M:%S")

    def to_dict(self) -> dict:
        """Serialize metadata for storage and reporting."""
        return {
            "file_id": self.file_id,
            "file_name": self.file_name,
            "file_type": self.file_type,
            "file_size": self.file_size,
            "created_at": self.created_at,
            "last_accessed": self.last_accessed,
            "access_count": self.access_count,
        }

    def __repr__(self) -> str:
        return f"<FileNode {self.file_id}: {self.file_name} ({self.file_type}, {self.file_size}MB)>"
