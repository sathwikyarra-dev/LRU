"""
LRU Cache Implementation.
Combines CustomHashMap (for O(1) key lookup) and DoublyLinkedList (for O(1) MRU/LRU reordering).
Strictly adheres to DSA restrictions: No functools.lru_cache, no Python dict, no OrderedDict.
"""

from typing import Any, Dict, List, Optional, Tuple
from ..models.file_node import FileNode
from .custom_hash_map import CustomHashMap
from .doubly_linked_list import DoublyLinkedList


class LRUCache:
    """
    Least Recently Used (LRU) File Cache.
    - CustomHashMap: maps file_id -> FileNode in DoublyLinkedList
    - DoublyLinkedList: maintains temporal order (Head = MRU, Tail = LRU)
    - Supports both 'max_files' and 'max_memory' eviction policies.
    """

    def __init__(
        self,
        capacity: int = 5,
        policy: str = "max_files",
        max_memory_mb: float = 50.0
    ):
        self.capacity: int = max(1, capacity)
        self.policy: str = policy  # "max_files" or "max_memory"
        self.max_memory_mb: float = float(max_memory_mb)

        # Core custom data structures
        self.hash_map: CustomHashMap = CustomHashMap(capacity=max(8, self.capacity * 2))
        self.linked_list: DoublyLinkedList = DoublyLinkedList()

        # Telemetry & Statistics
        self.cache_hits: int = 0
        self.cache_misses: int = 0
        self.evictions: int = 0
        self.total_requests: int = 0

    @property
    def current_size(self) -> int:
        return self.linked_list.size()

    @property
    def current_memory_mb(self) -> float:
        total = 0.0
        for node in self.linked_list.to_list():
            total += node.file_size
        return round(total, 2)

    def contains(self, file_id: str) -> bool:
        """O(1) check if file_id exists in cache."""
        return self.hash_map.contains(str(file_id))

    def get(self, file_id: str) -> Tuple[Optional[FileNode], bool]:
        """
        GET Algorithm:
        1. Search CustomHashMap for file_id.
        2. If found:
           - Cache HIT
           - Increment hits & total requests
           - Record access on node (count & timestamp)
           - Move node to HEAD (MRU) of DoublyLinkedList
           - Return (node, True)
        3. If not found:
           - Cache MISS
           - Increment misses & total requests
           - Return (None, False)
        """
        self.total_requests += 1
        node: Optional[FileNode] = self.hash_map.get(str(file_id))

        if node is not None:
            self.cache_hits += 1
            node.record_access()
            self.linked_list.move_to_front(node)
            return node, True
        else:
            self.cache_misses += 1
            return None, False

    def put(self, file_node: FileNode) -> List[FileNode]:
        """
        PUT Algorithm:
        - If file already exists in cache:
          - Update fields
          - Move existing node to HEAD (MRU)
          - Return empty evicted list
        - Else:
          - Check capacity constraints:
            - If policy == "max_files" and current_size >= capacity:
              evict TAIL (LRU)
            - If policy == "max_memory" and current_memory + file.size > max_memory:
              evict TAIL nodes iteratively until space is sufficient
          - Add new node to HEAD (MRU) of DoublyLinkedList
          - Add (file_id, node) to CustomHashMap
          - Return list of evicted FileNodes
        """
        if file_node is None:
            return []

        file_id = str(file_node.file_id)
        existing: Optional[FileNode] = self.hash_map.get(file_id)
        evicted_nodes: List[FileNode] = []

        if existing is not None:
            # Update attributes
            existing.file_name = file_node.file_name
            existing.file_type = file_node.file_type
            existing.file_size = file_node.file_size
            existing.record_access()
            self.linked_list.move_to_front(existing)
            return []

        # Eviction checks
        if self.policy == "max_files":
            while self.linked_list.size() >= self.capacity and self.linked_list.size() > 0:
                lru_node = self.linked_list.remove_last()
                if lru_node is not None:
                    self.hash_map.remove(lru_node.file_id)
                    self.evictions += 1
                    evicted_nodes.append(lru_node)
        elif self.policy == "max_memory":
            while (self.current_memory_mb + file_node.file_size > self.max_memory_mb) and (self.linked_list.size() > 0):
                lru_node = self.linked_list.remove_last()
                if lru_node is not None:
                    self.hash_map.remove(lru_node.file_id)
                    self.evictions += 1
                    evicted_nodes.append(lru_node)

        # Insert at HEAD (MRU)
        self.linked_list.add_to_front(file_node)
        self.hash_map.put(file_id, file_node)

        return evicted_nodes

    def remove(self, file_id: str) -> Optional[FileNode]:
        """Manually remove a file from cache."""
        node: Optional[FileNode] = self.hash_map.remove(str(file_id))
        if node is not None:
            self.linked_list.remove_node(node)
            return node
        return None

    def set_capacity(self, new_capacity: int) -> List[FileNode]:
        """
        Changes cache capacity.
        If new_capacity is smaller than current items, evicts LRU nodes until it fits.
        """
        self.capacity = max(1, min(50, int(new_capacity)))
        evicted: List[FileNode] = []

        while self.linked_list.size() > self.capacity:
            lru_node = self.linked_list.remove_last()
            if lru_node is not None:
                self.hash_map.remove(lru_node.file_id)
                self.evictions += 1
                evicted.append(lru_node)

        return evicted

    def clear(self) -> None:
        """Empties the cache and resets internal structures."""
        self.linked_list.clear()
        self.hash_map.clear()

    def reset_statistics(self) -> None:
        """Resets hit/miss/eviction counters."""
        self.cache_hits = 0
        self.cache_misses = 0
        self.evictions = 0
        self.total_requests = 0

    def get_state(self) -> List[FileNode]:
        """Returns the ordered list of files from MRU (head) to LRU (tail)."""
        return self.linked_list.to_list()

    def get_statistics(self) -> Dict[str, Any]:
        """Calculates cache hit rate and returns complete telemetry."""
        hit_rate = 0.0
        if self.total_requests > 0:
            hit_rate = (self.cache_hits / self.total_requests) * 100.0

        return {
            "capacity": self.capacity,
            "current_size": self.linked_list.size(),
            "policy": self.policy,
            "max_memory_mb": self.max_memory_mb,
            "current_memory_mb": self.current_memory_mb,
            "total_requests": self.total_requests,
            "cache_hits": self.cache_hits,
            "cache_misses": self.cache_misses,
            "hit_rate_pct": round(hit_rate, 2),
            "evictions": self.evictions,
        }
