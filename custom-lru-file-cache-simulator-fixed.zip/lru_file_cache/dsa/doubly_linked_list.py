"""
Doubly Linked List Implementation.
Head represents MRU (Most Recently Used).
Tail represents LRU (Least Recently Used).
"""

from typing import List, Optional
from ..models.file_node import FileNode


class DoublyLinkedList:
    """
    Maintains items in access order:
    - Head = MRU (Most Recently Used)
    - Tail = LRU (Least Recently Used)
    All core re-ordering operations are strictly O(1).
    """

    def __init__(self):
        self.head: Optional[FileNode] = None
        self.tail: Optional[FileNode] = None
        self._size: int = 0

    def add_to_front(self, node: FileNode) -> None:
        """
        Inserts a node at the head (MRU).
        Time Complexity: O(1).
        """
        if node is None:
            return

        node.previous = None
        node.next = self.head

        if self.head is not None:
            self.head.previous = node
        self.head = node

        # If list was empty, head is also tail
        if self.tail is None:
            self.tail = node

        self._size += 1

    def remove_node(self, node: FileNode) -> Optional[FileNode]:
        """
        Unlinks a given node from anywhere in the list.
        Time Complexity: O(1) because node reference is already available.
        """
        if node is None or self._size == 0:
            return None

        # Update previous pointer
        if node.previous is not None:
            node.previous.next = node.next
        else:
            # node was head
            self.head = node.next

        # Update next pointer
        if node.next is not None:
            node.next.previous = node.previous
        else:
            # node was tail
            self.tail = node.previous

        node.previous = None
        node.next = None
        self._size -= 1
        return node

    def remove_last(self) -> Optional[FileNode]:
        """
        Removes and returns the tail node (LRU).
        Time Complexity: O(1).
        """
        if self.tail is None:
            return None
        return self.remove_node(self.tail)

    def move_to_front(self, node: FileNode) -> None:
        """
        Moves an existing node in the list to the head (MRU).
        Time Complexity: O(1).
        """
        if node is None or node is self.head:
            return
        self.remove_node(node)
        self.add_to_front(node)

    def get_last(self) -> Optional[FileNode]:
        """Returns the tail node (LRU) without removing it."""
        return self.tail

    def get_first(self) -> Optional[FileNode]:
        """Returns the head node (MRU)."""
        return self.head

    def clear(self) -> None:
        """Clears all nodes from the list."""
        current = self.head
        while current is not None:
            nxt = current.next
            current.previous = None
            current.next = None
            current = nxt
        self.head = None
        self.tail = None
        self._size = 0

    def size(self) -> int:
        return self._size

    def is_empty(self) -> bool:
        return self._size == 0

    def to_list(self) -> List[FileNode]:
        """
        Traverses from Head (MRU) to Tail (LRU).
        Returns list of FileNodes.
        """
        nodes: List[FileNode] = []
        current = self.head
        while current is not None:
            nodes.append(current)
            current = current.next
        return nodes

    def __len__(self) -> int:
        return self._size

    def __repr__(self) -> str:
        items = [n.file_name for n in self.to_list()]
        return f"MRU -> {' -> '.join(items)} -> LRU"
