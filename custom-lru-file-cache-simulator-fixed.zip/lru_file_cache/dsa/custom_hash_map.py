"""
Custom Hash Map Implementation with Separate Chaining Collision Resolution.
Strictly does NOT use Python's built-in dict for storage.
"""

from typing import Any, List, Optional, Tuple


class HashNode:
    """Entry node for separate chaining within a hash map bucket."""

    def __init__(self, key: str, value: Any):
        self.key: str = str(key)
        self.value: Any = value
        self.next: Optional["HashNode"] = None

    def __repr__(self) -> str:
        return f"[{self.key}]"


class CustomHashMap:
    """
    Manual Hash Map implementation demonstrating:
    - Custom polynomial rolling hash calculation (base 31)
    - Fixed or dynamic bucket array
    - Collision handling via Separate Chaining
    - Real-time diagnostic tracking: collisions, load factor, bucket utilization
    """

    DEFAULT_INITIAL_CAPACITY = 8

    def __init__(self, capacity: int = DEFAULT_INITIAL_CAPACITY):
        self.capacity: int = max(4, capacity)
        self._size: int = 0
        self.collision_count: int = 0

        # Initialize bucket array as a list of head nodes (None)
        # Each index points to the head of a linked list of HashNodes
        self.buckets: List[Optional[HashNode]] = [None] * self.capacity

    def _hash(self, key: str) -> int:
        """
        Custom polynomial rolling hash function:
        hash = (hash * 31 + ord(character)) % capacity
        Does NOT use Python's native hash() function.
        """
        h = 0
        for ch in str(key):
            h = (h * 31 + ord(ch)) % self.capacity
        return h

    def put(self, key: str, value: Any) -> None:
        """
        Inserts or updates a key-value pair.
        Returns None.
        """
        key_str = str(key)
        index = self._hash(key_str)
        head = self.buckets[index]

        # Check if key already exists in the chain
        current = head
        while current is not None:
            if current.key == key_str:
                current.value = value
                return
            current = current.next

        # Key is not present. If bucket is occupied, this is a collision
        if head is not None:
            self.collision_count += 1

        # Insert new node at head of chain (O(1) insertion)
        new_node = HashNode(key_str, value)
        new_node.next = head
        self.buckets[index] = new_node
        self._size += 1

    def get(self, key: str) -> Optional[Any]:
        """
        Retrieves the value associated with key.
        Returns value or None if not found.
        """
        key_str = str(key)
        index = self._hash(key_str)
        current = self.buckets[index]

        while current is not None:
            if current.key == key_str:
                return current.value
            current = current.next
        return None

    def remove(self, key: str) -> Optional[Any]:
        """
        Removes the key-value pair from the hash map.
        Returns the removed value or None if key does not exist.
        """
        key_str = str(key)
        index = self._hash(key_str)
        current = self.buckets[index]
        prev: Optional[HashNode] = None

        while current is not None:
            if current.key == key_str:
                if prev is None:
                    self.buckets[index] = current.next
                else:
                    prev.next = current.next
                self._size -= 1
                return current.value
            prev = current
            current = current.next
        return None

    def contains(self, key: str) -> bool:
        """Checks if a key is present in the hash map."""
        return self.get(key) is not None

    def size(self) -> int:
        """Returns the total number of stored entries."""
        return self._size

    def is_empty(self) -> bool:
        return self._size == 0

    def items(self) -> List[Tuple[str, Any]]:
        """Returns all (key, value) pairs as a list of tuples."""
        result: List[Tuple[str, Any]] = []
        for head in self.buckets:
            curr = head
            while curr is not None:
                result.append((curr.key, curr.value))
                curr = curr.next
        return result

    def keys(self) -> List[str]:
        """Returns all keys."""
        return [k for k, _ in self.items()]

    def values(self) -> List[Any]:
        """Returns all values."""
        return [v for _, v in self.items()]

    def clear(self) -> None:
        """Resets the hash map to empty."""
        self.buckets = [None] * self.capacity
        self._size = 0
        self.collision_count = 0

    def get_diagnostics(self) -> dict:
        """
        Returns diagnostic metrics:
        - bucket_count
        - entries
        - collisions
        - load_factor
        - bucket_utilization
        - bucket_chains: list of [key1, key2, ...] for each bucket
        """
        bucket_chains = []
        occupied_count = 0

        for i, head in enumerate(self.buckets):
            chain_keys = []
            curr = head
            while curr is not None:
                chain_keys.append(curr.key)
                curr = curr.next
            if len(chain_keys) > 0:
                occupied_count += 1
            bucket_chains.append({
                "index": i,
                "keys": chain_keys,
                "count": len(chain_keys),
                "is_collision": len(chain_keys) > 1
            })

        load_factor = self._size / self.capacity if self.capacity > 0 else 0.0
        utilization = (occupied_count / self.capacity) * 100.0 if self.capacity > 0 else 0.0

        return {
            "capacity": self.capacity,
            "entries": self._size,
            "collisions": self.collision_count,
            "load_factor": round(load_factor, 3),
            "occupied_buckets": occupied_count,
            "bucket_utilization_pct": round(utilization, 1),
            "buckets": bucket_chains
        }
