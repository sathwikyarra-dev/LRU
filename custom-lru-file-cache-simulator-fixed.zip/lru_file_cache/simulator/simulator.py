"""
Simulator Engine orchestrating:
- File Storage (Disk)
- LRU Cache (Memory with CustomHashMap + DoublyLinkedList)
- Telemetry, Step-by-Step Execution, Workload Generators, and Benchmarks
"""

import datetime
import random
import time
from typing import Any, Dict, List, Optional, Tuple
from ..models.file_node import FileNode
from ..dsa.lru_cache import LRUCache
from ..storage.file_storage import FileStorage


class Simulator:
    """
    Main simulator orchestrator bridging user actions, file storage, and the LRU cache.
    """

    def __init__(
        self,
        capacity: int = 5,
        policy: str = "max_files",
        max_memory_mb: float = 50.0,
        storage: Optional[FileStorage] = None
    ):
        self.storage: FileStorage = storage if storage is not None else FileStorage()
        self.cache: LRUCache = LRUCache(
            capacity=capacity,
            policy=policy,
            max_memory_mb=max_memory_mb
        )
        self.activity_logs: List[Dict[str, Any]] = []
        self.request_timeline: List[Dict[str, Any]] = []

    def log_activity(
        self,
        operation: str,
        file_name: str,
        status: str,
        details: str = "",
        latency_ms: float = 0.0
    ) -> None:
        """Appends an event to the activity log."""
        timestamp = datetime.datetime.now().strftime("%H:%M:%S")
        entry = {
            "id": len(self.activity_logs) + 1,
            "timestamp": timestamp,
            "operation": operation,
            "file_name": file_name,
            "status": status,
            "details": details,
            "latency_ms": round(latency_ms, 2)
        }
        self.activity_logs.append(entry)

        # Timeline data point for charts
        stats = self.cache.get_statistics()
        self.request_timeline.append({
            "request_num": stats["total_requests"],
            "timestamp": timestamp,
            "file_name": file_name,
            "status": status,
            "hit_rate": stats["hit_rate_pct"],
            "cache_size": stats["current_size"]
        })

    def access_file(self, file_id_or_name: str) -> Dict[str, Any]:
        """
        Executes real LRU access logic:
        1. Resolve file in storage (validates existence)
        2. Query LRUCache.get()
        3. If HIT: fast memory latency (1-3ms simulated)
        4. If MISS: storage retrieval latency (10-25ms simulated), call LRUCache.put()
        """
        # Find file in storage
        file_obj = self.storage.get_file(file_id_or_name)
        if file_obj is None:
            file_obj = self.storage.get_by_name(file_id_or_name)

        if file_obj is None:
            return {
                "success": False,
                "error": f"File '{file_id_or_name}' not found in storage repository."
            }

        file_id = file_obj.file_id
        file_name = file_obj.file_name

        # Query Cache
        cached_node, is_hit = self.cache.get(file_id)

        if is_hit and cached_node is not None:
            # HIT
            latency = round(random.uniform(1.2, 3.5), 2)
            self.log_activity("GET", file_name, "HIT", "Found in memory cache (O(1) lookup)", latency)
            return {
                "success": True,
                "status": "HIT",
                "file": cached_node,
                "latency_ms": latency,
                "evicted": [],
                "message": f"✓ CACHE HIT\n\n{file_name} was found in the cache.\nAccess Time: {latency} ms"
            }
        else:
            # MISS
            disk_latency = round(random.uniform(12.0, 24.0), 2)
            self.log_activity("GET", file_name, "MISS", "Not in cache; loading from disk", disk_latency)

            # Insert into cache (clone node to keep storage independent)
            node_to_cache = FileNode(
                file_obj.file_id,
                file_obj.file_name,
                file_obj.file_type,
                file_obj.file_size
            )
            node_to_cache.record_access()

            evicted_nodes = self.cache.put(node_to_cache)

            for evicted in evicted_nodes:
                self.log_activity("EVICT", evicted.file_name, "EVICTED", "Removed from TAIL (LRU) to free capacity")

            self.log_activity("INSERT", file_name, "CACHED", "Inserted at HEAD (MRU)")

            return {
                "success": True,
                "status": "MISS",
                "file": node_to_cache,
                "latency_ms": disk_latency,
                "evicted": evicted_nodes,
                "message": f"⚠ CACHE MISS\n\n{file_name} was loaded from storage.\nAccess Time: {disk_latency} ms\nInserted into cache."
            }

    def get_step_by_step_trace(self, file_id_or_name: str) -> List[Dict[str, Any]]:
        """
        Constructs a detailed step-by-step trace explaining every stage of the algorithm:
        Step 1: Hash Calculation & HashMap Lookup
        Step 2: Hit/Miss Branch
        Step 3: Storage retrieval (if miss) / Access update (if hit)
        Step 4: Capacity & Eviction check
        Step 5: Eviction of LRU Tail (if needed)
        Step 6: Head insertion or reordering to MRU
        Step 7: Final state summary
        """
        file_obj = self.storage.get_file(file_id_or_name)
        if file_obj is None:
            file_obj = self.storage.get_by_name(file_id_or_name)
        if file_obj is None:
            return [{"step": 1, "title": "Error", "description": f"File '{file_id_or_name}' not found."}]

        steps = []
        file_id = file_obj.file_id
        file_name = file_obj.file_name

        # 1. HashMap Lookup
        bucket_index = self.cache.hash_map._hash(file_id)
        already_cached = self.cache.contains(file_id)

        steps.append({
            "step": 1,
            "title": "Searching Custom HashMap",
            "description": f"Computed polynomial hash for key '{file_id}' → Bucket #{bucket_index}.\nInspecting bucket chain for '{file_id}'...",
            "target": file_name,
            "result": "FOUND in HashMap" if already_cached else "NOT FOUND in HashMap"
        })

        # 2. Result Classification
        if already_cached:
            steps.append({
                "step": 2,
                "title": "CACHE HIT Detected",
                "description": f"Node for '{file_name}' resides in memory. No disk I/O required.",
                "status": "HIT"
            })
            steps.append({
                "step": 3,
                "title": "Update Access Metadata",
                "description": f"Increment access count and set last_accessed timestamp to current time.",
                "status": "METADATA_UPDATED"
            })
            steps.append({
                "step": 4,
                "title": "Doubly Linked List Reordering",
                "description": f"Unlink '{file_name}' from its current position in DoublyLinkedList.\nSplice it to HEAD (MRU position).",
                "status": "MRU_PROMOTED"
            })
        else:
            steps.append({
                "step": 2,
                "title": "CACHE MISS Detected",
                "description": f"'{file_name}' is not in memory. Must fetch from secondary storage.",
                "status": "MISS"
            })
            steps.append({
                "step": 3,
                "title": "Retrieve File from Simulated Storage",
                "description": f"Read {file_name} ({file_obj.file_size} MB, type {file_obj.file_type}) from disk repository.",
                "status": "LOADED_FROM_DISK"
            })

            # Check capacity
            is_full = (self.cache.policy == "max_files" and self.cache.current_size >= self.cache.capacity) or \
                      (self.cache.policy == "max_memory" and self.cache.current_memory_mb + file_obj.file_size > self.cache.max_memory_mb)

            steps.append({
                "step": 4,
                "title": "Check Cache Capacity Constraints",
                "description": f"Current size: {self.cache.current_size}/{self.cache.capacity}. Full = {is_full}.",
                "is_full": is_full
            })

            if is_full and self.cache.linked_list.tail is not None:
                tail_file = self.cache.linked_list.tail
                steps.append({
                    "step": 5,
                    "title": "Evict LRU Node from Tail",
                    "description": f"Cache full. Evicting least recently used item: '{tail_file.file_name}'.\nRemoved from DoublyLinkedList TAIL and unmapped from CustomHashMap.",
                    "evicted": tail_file.file_name
                })

            steps.append({
                "step": 6 if is_full else 5,
                "title": "Insert New Node at Head (MRU)",
                "description": f"Insert '{file_name}' at HEAD of DoublyLinkedList.\nRegister mapping '{file_id}' → Node in CustomHashMap.",
                "status": "INSERTED"
            })

        return steps

    def run_benchmark(self, operations: int = 10000) -> Dict[str, Any]:
        """
        Runs real comparative benchmark:
        - Custom LRU Cache with HashMap + DoublyLinkedList: O(1) average lookup
        - Linear Search (list scan): O(n) lookup
        Measures real wall-clock time using time.perf_counter().
        """
        test_files = self.storage.files
        if not test_files:
            return {}

        file_ids = [f.file_id for f in test_files]

        # Warm up LRU Cache with items
        benchmark_cache = LRUCache(capacity=len(file_ids) + 5)
        for f in test_files:
            benchmark_cache.put(FileNode(f.file_id, f.file_name, f.file_type, f.file_size))

        # Array for Linear Search
        linear_array = [FileNode(f.file_id, f.file_name, f.file_type, f.file_size) for f in test_files]

        queries = [random.choice(file_ids) for _ in range(operations)]

        # Benchmark 1: Custom LRU Cache
        start_lru = time.perf_counter()
        for q in queries:
            benchmark_cache.get(q)
        end_lru = time.perf_counter()
        lru_duration = max(0.00001, end_lru - start_lru)

        # Benchmark 2: Linear Search
        start_linear = time.perf_counter()
        for q in queries:
            # O(N) scan
            for item in linear_array:
                if item.file_id == q:
                    break
        end_linear = time.perf_counter()
        linear_duration = max(0.00001, end_linear - start_linear)

        speedup = linear_duration / lru_duration

        return {
            "operations": operations,
            "lru_time_sec": round(lru_duration, 5),
            "linear_time_sec": round(linear_duration, 5),
            "lru_avg_op_us": round((lru_duration / operations) * 1_000_000, 3),
            "linear_avg_op_us": round((linear_duration / operations) * 1_000_000, 3),
            "speedup_ratio": round(speedup, 2),
            "lru_complexity": "O(1) Average Lookup",
            "linear_complexity": "O(N) Sequential Scan"
        }

    def reset(self) -> None:
        """Resets cache, statistics, and activity log."""
        self.cache.clear()
        self.cache.reset_statistics()
        self.activity_logs.clear()
        self.request_timeline.clear()
