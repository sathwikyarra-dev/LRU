import { PolicyState, PolicyComparisonResult } from "./types";

export class PolicySimulator {
  private capacity: number;
  private lruCache: string[] = []; // MRU at index 0, LRU at end
  private fifoQueue: string[] = []; // Newest at end, Oldest at index 0
  private lfuCache: string[] = []; // keys
  private lfuFreq: Record<string, number> = {};
  private randomCache: string[] = [];

  public lruStats = { hits: 0, misses: 0, evictions: 0, lastEvicted: null as string | null, lastAction: "MISS" as "HIT" | "MISS" };
  public fifoStats = { hits: 0, misses: 0, evictions: 0, lastEvicted: null as string | null, lastAction: "MISS" as "HIT" | "MISS" };
  public lfuStats = { hits: 0, misses: 0, evictions: 0, lastEvicted: null as string | null, lastAction: "MISS" as "HIT" | "MISS" };
  public randomStats = { hits: 0, misses: 0, evictions: 0, lastEvicted: null as string | null, lastAction: "MISS" as "HIT" | "MISS" };

  constructor(capacity: number = 4) {
    this.capacity = capacity;
  }

  public reset(capacity?: number) {
    if (capacity) this.capacity = capacity;
    this.lruCache = [];
    this.fifoQueue = [];
    this.lfuCache = [];
    this.lfuFreq = {};
    this.randomCache = [];

    this.lruStats = { hits: 0, misses: 0, evictions: 0, lastEvicted: null, lastAction: "MISS" };
    this.fifoStats = { hits: 0, misses: 0, evictions: 0, lastEvicted: null, lastAction: "MISS" };
    this.lfuStats = { hits: 0, misses: 0, evictions: 0, lastEvicted: null, lastAction: "MISS" };
    this.randomStats = { hits: 0, misses: 0, evictions: 0, lastEvicted: null, lastAction: "MISS" };
  }

  public step(key: string, stepIndex: number): PolicyComparisonResult {
    // 1. LRU
    const lruIdx = this.lruCache.indexOf(key);
    if (lruIdx !== -1) {
      this.lruStats.hits++;
      this.lruStats.lastAction = "HIT";
      this.lruStats.lastEvicted = null;
      // promote to head (index 0)
      this.lruCache.splice(lruIdx, 1);
      this.lruCache.unshift(key);
    } else {
      this.lruStats.misses++;
      this.lruStats.lastAction = "MISS";
      let evicted: string | null = null;
      if (this.lruCache.length >= this.capacity) {
        evicted = this.lruCache.pop() || null;
        this.lruStats.evictions++;
      }
      this.lruStats.lastEvicted = evicted;
      this.lruCache.unshift(key);
    }

    // 2. FIFO
    const fifoIdx = this.fifoQueue.indexOf(key);
    if (fifoIdx !== -1) {
      this.fifoStats.hits++;
      this.fifoStats.lastAction = "HIT";
      this.fifoStats.lastEvicted = null;
      // in pure FIFO, hit does not change queue order
    } else {
      this.fifoStats.misses++;
      this.fifoStats.lastAction = "MISS";
      let evicted: string | null = null;
      if (this.fifoQueue.length >= this.capacity) {
        evicted = this.fifoQueue.shift() || null; // remove oldest
        this.fifoStats.evictions++;
      }
      this.fifoStats.lastEvicted = evicted;
      this.fifoQueue.push(key);
    }

    // 3. LFU
    this.lfuFreq[key] = (this.lfuFreq[key] || 0) + 1;
    const lfuIdx = this.lfuCache.indexOf(key);
    if (lfuIdx !== -1) {
      this.lfuStats.hits++;
      this.lfuStats.lastAction = "HIT";
      this.lfuStats.lastEvicted = null;
    } else {
      this.lfuStats.misses++;
      this.lfuStats.lastAction = "MISS";
      let evicted: string | null = null;
      if (this.lfuCache.length >= this.capacity) {
        // find key with lowest frequency
        let minKey = this.lfuCache[0];
        let minFreq = this.lfuFreq[minKey] || 0;
        for (const k of this.lfuCache) {
          const f = this.lfuFreq[k] || 0;
          if (f < minFreq) {
            minFreq = f;
            minKey = k;
          }
        }
        evicted = minKey;
        this.lfuCache = this.lfuCache.filter((k) => k !== evicted);
        this.lfuStats.evictions++;
      }
      this.lfuStats.lastEvicted = evicted;
      this.lfuCache.push(key);
    }

    // 4. Random
    const randIdx = this.randomCache.indexOf(key);
    if (randIdx !== -1) {
      this.randomStats.hits++;
      this.randomStats.lastAction = "HIT";
      this.randomStats.lastEvicted = null;
    } else {
      this.randomStats.misses++;
      this.randomStats.lastAction = "MISS";
      let evicted: string | null = null;
      if (this.randomCache.length >= this.capacity) {
        const victimIdx = Math.floor(Math.random() * this.randomCache.length);
        evicted = this.randomCache[victimIdx];
        this.randomCache.splice(victimIdx, 1);
        this.randomStats.evictions++;
      }
      this.randomStats.lastEvicted = evicted;
      this.randomCache.push(key);
    }

    const calcRate = (hits: number, misses: number) => {
      const tot = hits + misses;
      return tot > 0 ? Number(((hits / tot) * 100).toFixed(1)) : 0;
    };

    return {
      stepIndex,
      currentKey: key,
      policies: {
        LRU: {
          name: "LRU",
          cache: [...this.lruCache],
          hits: this.lruStats.hits,
          misses: this.lruStats.misses,
          evictions: this.lruStats.evictions,
          hitRate: calcRate(this.lruStats.hits, this.lruStats.misses),
          lastEvicted: this.lruStats.lastEvicted,
          lastActionStatus: this.lruStats.lastAction
        },
        FIFO: {
          name: "FIFO",
          cache: [...this.fifoQueue],
          hits: this.fifoStats.hits,
          misses: this.fifoStats.misses,
          evictions: this.fifoStats.evictions,
          hitRate: calcRate(this.fifoStats.hits, this.fifoStats.misses),
          lastEvicted: this.fifoStats.lastEvicted,
          lastActionStatus: this.fifoStats.lastAction
        },
        LFU: {
          name: "LFU",
          cache: [...this.lfuCache],
          hits: this.lfuStats.hits,
          misses: this.lfuStats.misses,
          evictions: this.lfuStats.evictions,
          hitRate: calcRate(this.lfuStats.hits, this.lfuStats.misses),
          frequencies: { ...this.lfuFreq },
          lastEvicted: this.lfuStats.lastEvicted,
          lastActionStatus: this.lfuStats.lastAction
        },
        Random: {
          name: "Random",
          cache: [...this.randomCache],
          hits: this.randomStats.hits,
          misses: this.randomStats.misses,
          evictions: this.randomStats.evictions,
          hitRate: calcRate(this.randomStats.hits, this.randomStats.misses),
          lastEvicted: this.randomStats.lastEvicted,
          lastActionStatus: this.randomStats.lastAction
        }
      }
    };
  }

  public runAll(sequence: string[]): PolicyComparisonResult[] {
    const results: PolicyComparisonResult[] = [];
    this.reset();
    for (let i = 0; i < sequence.length; i++) {
      results.push(this.step(sequence[i], i + 1));
    }
    return results;
  }
}
