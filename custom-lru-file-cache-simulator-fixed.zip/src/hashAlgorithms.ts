export type HashAlgorithmId = "polynomial" | "djb2" | "fnv1a" | "simple_sum" | "lose_lose";

export interface AlgorithmStep {
  step: number;
  char: string;
  charCode: number;
  prevVal: number | string;
  operationText: string;
  rawResult: number;
  bucketResult: number;
}

export interface HashAlgorithmDef {
  id: HashAlgorithmId;
  name: string;
  shortName: string;
  author: string;
  formula: string;
  formulaExplanation: string;
  quality: "Superior" | "High Performance" | "Standard (Java)" | "Educational / Poor";
  qualityColor: string;
  badgeBg: string;
  badgeBorder: string;
  computeIndex: (key: string, capacity: number) => number;
  computeRaw: (key: string) => number;
  computeSteps: (key: string, capacity: number) => AlgorithmStep[];
}

export const HASH_ALGORITHMS: Record<HashAlgorithmId, HashAlgorithmDef> = {
  djb2: {
    id: "djb2",
    name: "DJB2 (Dan Bernstein)",
    shortName: "DJB2",
    author: "Prof. Daniel J. Bernstein (1991)",
    formula: "H = ((H << 5) + H) + c = (H × 33) + c",
    formulaExplanation:
      "Initializes to 5381 (a prime with optimal bit density). Multiplies by 33 via fast bit-shift `(H << 5) + H` before adding ASCII code `c`.",
    quality: "High Performance",
    qualityColor: "text-emerald-400",
    badgeBg: "bg-emerald-500/10",
    badgeBorder: "border-emerald-500/30",
    computeRaw: (key: string) => {
      let hash = 5381;
      for (let i = 0; i < key.length; i++) {
        hash = ((hash << 5) + hash + key.charCodeAt(i)) | 0;
      }
      return hash >>> 0;
    },
    computeIndex: (key: string, capacity: number) => {
      let hash = 5381;
      for (let i = 0; i < key.length; i++) {
        hash = ((hash << 5) + hash + key.charCodeAt(i)) | 0;
      }
      return Math.abs(hash >>> 0) % capacity;
    },
    computeSteps: (key: string, capacity: number) => {
      const steps: AlgorithmStep[] = [];
      let hash = 5381;
      for (let i = 0; i < key.length; i++) {
        const char = key[i];
        const code = key.charCodeAt(i);
        const prev = hash;
        hash = ((prev << 5) + prev + code) | 0;
        const raw = hash >>> 0;
        steps.push({
          step: i + 1,
          char,
          charCode: code,
          prevVal: prev,
          operationText: `(${prev} << 5) + ${prev} + ${code}`,
          rawResult: raw,
          bucketResult: raw % capacity
        });
      }
      return steps;
    }
  },

  fnv1a: {
    id: "fnv1a",
    name: "FNV-1a (Fowler–Noll–Vo)",
    shortName: "FNV-1a",
    author: "Glenn Fowler, Landon Curt Noll, Phong Vo",
    formula: "H = (H ⊕ c) × 16777619",
    formulaExplanation:
      "Uses 32-bit FNV offset basis (2166136261) and FNV prime (16777619). XORs the byte before prime multiplication to maximize the avalanche effect.",
    quality: "Superior",
    qualityColor: "text-cyan-400",
    badgeBg: "bg-cyan-500/10",
    badgeBorder: "border-cyan-500/30",
    computeRaw: (key: string) => {
      let hash = 2166136261;
      for (let i = 0; i < key.length; i++) {
        hash ^= key.charCodeAt(i);
        // 32-bit integer multiplication with 16777619
        hash = Math.imul(hash, 16777619);
      }
      return hash >>> 0;
    },
    computeIndex: (key: string, capacity: number) => {
      let hash = 2166136261;
      for (let i = 0; i < key.length; i++) {
        hash ^= key.charCodeAt(i);
        hash = Math.imul(hash, 16777619);
      }
      return (hash >>> 0) % capacity;
    },
    computeSteps: (key: string, capacity: number) => {
      const steps: AlgorithmStep[] = [];
      let hash = 2166136261;
      for (let i = 0; i < key.length; i++) {
        const char = key[i];
        const code = key.charCodeAt(i);
        const prev = hash >>> 0;
        const xored = (hash ^ code) >>> 0;
        hash = Math.imul(hash ^ code, 16777619);
        const raw = hash >>> 0;
        steps.push({
          step: i + 1,
          char,
          charCode: code,
          prevVal: prev,
          operationText: `(${prev} ^ ${code}) × 16777619`,
          rawResult: raw,
          bucketResult: raw % capacity
        });
      }
      return steps;
    }
  },

  polynomial: {
    id: "polynomial",
    name: "Polynomial Rolling Hash (Base 31)",
    shortName: "Polynomial 31",
    author: "Java String.hashCode() Standard",
    formula: "H = (H × 31 + c) % M",
    formulaExplanation:
      "Accumulates prime 31 polynomial weights: s[0]*31^(n-1) + s[1]*31^(n-2) + ... Prime 31 avoids power-of-two harmonic resonance.",
    quality: "Standard (Java)",
    qualityColor: "text-sky-400",
    badgeBg: "bg-sky-500/10",
    badgeBorder: "border-sky-500/30",
    computeRaw: (key: string) => {
      let hash = 0;
      for (let i = 0; i < key.length; i++) {
        hash = (hash * 31 + key.charCodeAt(i)) | 0;
      }
      return Math.abs(hash);
    },
    computeIndex: (key: string, capacity: number) => {
      let hash = 0;
      for (let i = 0; i < key.length; i++) {
        hash = (hash * 31 + key.charCodeAt(i)) % capacity;
      }
      return Math.abs(hash);
    },
    computeSteps: (key: string, capacity: number) => {
      const steps: AlgorithmStep[] = [];
      let hash = 0;
      for (let i = 0; i < key.length; i++) {
        const char = key[i];
        const code = key.charCodeAt(i);
        const prev = hash;
        const times31 = prev * 31;
        const plusCode = times31 + code;
        hash = Math.abs(plusCode % capacity);
        steps.push({
          step: i + 1,
          char,
          charCode: code,
          prevVal: prev,
          operationText: `(${prev} × 31) + ${code}`,
          rawResult: plusCode,
          bucketResult: hash
        });
      }
      return steps;
    }
  },

  simple_sum: {
    id: "simple_sum",
    name: "Simple Modulo (Sum of ASCII)",
    shortName: "Simple Modulo",
    author: "Naive Baseline Hashing",
    formula: "H = (Σ ASCII charCodes) % M",
    formulaExplanation:
      "Simply sums character byte values and applies modulo. Highly vulnerable to anagram collisions (e.g., 'ab' & 'ba' yield identical values!).",
    quality: "Educational / Poor",
    qualityColor: "text-rose-400",
    badgeBg: "bg-rose-500/10",
    badgeBorder: "border-rose-500/30",
    computeRaw: (key: string) => {
      let sum = 0;
      for (let i = 0; i < key.length; i++) {
        sum += key.charCodeAt(i);
      }
      return sum;
    },
    computeIndex: (key: string, capacity: number) => {
      let sum = 0;
      for (let i = 0; i < key.length; i++) {
        sum += key.charCodeAt(i);
      }
      return sum % capacity;
    },
    computeSteps: (key: string, capacity: number) => {
      const steps: AlgorithmStep[] = [];
      let sum = 0;
      for (let i = 0; i < key.length; i++) {
        const char = key[i];
        const code = key.charCodeAt(i);
        const prev = sum;
        sum += code;
        steps.push({
          step: i + 1,
          char,
          charCode: code,
          prevVal: prev,
          operationText: `${prev} + ${code}`,
          rawResult: sum,
          bucketResult: sum % capacity
        });
      }
      return steps;
    }
  },

  lose_lose: {
    id: "lose_lose",
    name: "Lose-Lose Hash (K&R C Classic)",
    shortName: "Lose-Lose",
    author: "Brian Kernighan & Dennis Ritchie (1978)",
    formula: "H = (H + c) % M",
    formulaExplanation:
      "Humorously dubbed 'lose-lose' in the K&R C manual because it discards entropy and clusters short strings into low bucket ranges.",
    quality: "Educational / Poor",
    qualityColor: "text-amber-400",
    badgeBg: "bg-amber-500/10",
    badgeBorder: "border-amber-500/30",
    computeRaw: (key: string) => {
      let hash = 0;
      for (let i = 0; i < key.length; i++) {
        hash += key.charCodeAt(i);
      }
      return hash;
    },
    computeIndex: (key: string, capacity: number) => {
      let hash = 0;
      for (let i = 0; i < key.length; i++) {
        hash += key.charCodeAt(i);
      }
      return hash % capacity;
    },
    computeSteps: (key: string, capacity: number) => {
      const steps: AlgorithmStep[] = [];
      let hash = 0;
      for (let i = 0; i < key.length; i++) {
        const char = key[i];
        const code = key.charCodeAt(i);
        const prev = hash;
        hash += code;
        steps.push({
          step: i + 1,
          char,
          charCode: code,
          prevVal: prev,
          operationText: `${prev} + ${code}`,
          rawResult: hash,
          bucketResult: hash % capacity
        });
      }
      return steps;
    }
  }
};

export const ALGORITHM_LIST: HashAlgorithmDef[] = [
  HASH_ALGORITHMS.djb2,
  HASH_ALGORITHMS.fnv1a,
  HASH_ALGORITHMS.polynomial,
  HASH_ALGORITHMS.simple_sum,
  HASH_ALGORITHMS.lose_lose
];
