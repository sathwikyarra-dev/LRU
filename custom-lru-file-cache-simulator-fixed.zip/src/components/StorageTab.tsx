import React, { useState } from "react";
import { FileNodeItem } from "../types";
import { Plus, Trash2, Info, Zap, Search, CheckCircle2, AlertCircle, Eye } from "lucide-react";

interface StorageTabProps {
  files: FileNodeItem[];
  cachedFileIds: Set<string>;
  onAddFile: (file: FileNodeItem) => void;
  onDeleteFile: (fileId: string) => void;
  onAccessFile: (fileId: string) => void;
  onInspectFile?: (file: FileNodeItem) => void;
}

export const StorageTab: React.FC<StorageTabProps> = ({
  files,
  cachedFileIds,
  onAddFile,
  onDeleteFile,
  onAccessFile,
  onInspectFile
}) => {
  const [search, setSearch] = useState("");
  const [filterCat, setFilterCat] = useState("All");
  const [selectedFileId, setSelectedFileId] = useState<string | null>(null);

  // Modal states
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [newFileId, setNewFileId] = useState(`F${String(files.length + 1).padStart(3, "0")}`);
  const [newFileName, setNewFileName] = useState("");
  const [newFileType, setNewFileType] = useState("PDF");
  const [newFileSize, setNewFileSize] = useState("2.5");

  const filteredFiles = files.filter((f) => {
    const inCache = cachedFileIds.has(f.fileId);
    if (filterCat === "Cached" && !inCache) return false;
    if (filterCat === "Not Cached" && inCache) return false;

    const catMap: Record<string, string[]> = {
      PDF: ["PDF"],
      Images: ["JPG", "JPEG", "PNG", "GIF"],
      Videos: ["MP4", "MKV", "AVI"],
      Documents: ["DOCX", "TXT", "PPTX", "PDF"],
    };

    if (catMap[filterCat] && !catMap[filterCat].includes(f.fileType)) return false;

    if (filterCat === "Other") {
      const known = Object.values(catMap).flat();
      if (known.includes(f.fileType)) return false;
    }

    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        f.fileId.toLowerCase().includes(q) ||
        f.fileName.toLowerCase().includes(q) ||
        f.fileType.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const selectedFile = files.find((f) => f.fileId === selectedFileId);

  const handleCreateFile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFileName.trim()) return;

    const size = parseFloat(newFileSize) || 1.0;
    const file: FileNodeItem = {
      fileId: newFileId.trim() || `F${String(files.length + 1).padStart(3, "0")}`,
      fileName: newFileName.trim(),
      fileType: newFileType,
      fileSize: size,
      createdAt: new Date().toLocaleDateString() + " " + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      lastAccessed: null,
      accessCount: 0
    };

    onAddFile(file);
    setIsAddOpen(false);
    setNewFileName("");
    setNewFileId(`F${String(files.length + 2).padStart(3, "0")}`);
  };

  return (
    <div className="space-y-5 p-6 max-w-7xl mx-auto">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-100 flex items-center space-x-2">
            <span>Simulated File Storage (Secondary Disk)</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Manages repository files stored on simulated disk. Accessing files triggers real LRU cache operations.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            id="btn-add-file"
            onClick={() => setIsAddOpen(true)}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold rounded-lg text-xs transition cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add File</span>
          </button>

          <button
            id="btn-delete-file"
            disabled={!selectedFileId}
            onClick={() => {
              if (selectedFileId) onDeleteFile(selectedFileId);
              setSelectedFileId(null);
            }}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 rounded-lg text-xs font-semibold disabled:opacity-40 transition cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Delete</span>
          </button>

          <button
            id="btn-view-details"
            disabled={!selectedFileId}
            onClick={() => setIsDetailsOpen(true)}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold disabled:opacity-40 transition cursor-pointer"
          >
            <Info className="w-3.5 h-3.5 text-sky-400" />
            <span>Details</span>
          </button>

          {onInspectFile && (
            <button
              id="btn-inspect-payload"
              disabled={!selectedFileId}
              onClick={() => {
                const target = files.find((f) => f.fileId === selectedFileId);
                if (target) onInspectFile(target);
              }}
              className="flex items-center space-x-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold disabled:opacity-40 transition cursor-pointer"
            >
              <Eye className="w-3.5 h-3.5 text-sky-400" />
              <span>Inspect Payload</span>
            </button>
          )}

          <button
            id="btn-storage-access"
            disabled={!selectedFileId}
            onClick={() => {
              if (selectedFileId) onAccessFile(selectedFileId);
            }}
            className="flex items-center space-x-1.5 px-3.5 py-1.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold rounded-lg text-xs disabled:opacity-40 transition cursor-pointer shadow"
          >
            <Zap className="w-3.5 h-3.5 fill-current" />
            <span>ACCESS FILE</span>
          </button>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-3 rounded-xl">
        <div className="flex items-center space-x-2 w-full sm:w-72 bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800">
          <Search className="w-3.5 h-3.5 text-slate-400" />
          <input
            id="storage-search-input"
            type="text"
            placeholder="Search by ID, name, or type..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="bg-transparent text-xs text-slate-200 placeholder-slate-500 outline-none w-full"
          />
        </div>

        <div className="flex items-center space-x-2 text-xs text-slate-400">
          <span>Filter:</span>
          {["All", "Cached", "Not Cached", "PDF", "Images", "Videos", "Documents"].map((cat) => (
            <button
              key={cat}
              onClick={() => setFilterCat(cat)}
              className={`px-2.5 py-1 rounded text-xs transition cursor-pointer ${
                filterCat === cat
                  ? "bg-sky-500 text-slate-950 font-bold"
                  : "bg-slate-800 text-slate-300 hover:bg-slate-700"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* File Storage Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 font-mono text-[11px] uppercase border-b border-slate-800">
              <tr>
                <th className="p-3">File ID</th>
                <th className="p-3">File Name</th>
                <th className="p-3">Type</th>
                <th className="p-3 text-right">Size</th>
                <th className="p-3">Created</th>
                <th className="p-3">Last Accessed</th>
                <th className="p-3 text-center">Hits</th>
                <th className="p-3 text-center">Cache Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredFiles.map((file) => {
                const isSelected = selectedFileId === file.fileId;
                const isCached = cachedFileIds.has(file.fileId);

                return (
                  <tr
                    key={file.fileId}
                    id={`storage-row-${file.fileId}`}
                    onClick={() => setSelectedFileId(file.fileId)}
                    onDoubleClick={() => onAccessFile(file.fileId)}
                    className={`cursor-pointer transition-colors ${
                      isSelected ? "bg-sky-500/10 text-sky-200" : "hover:bg-slate-800/40"
                    }`}
                  >
                    <td className="p-3 font-mono font-bold text-sky-400">{file.fileId}</td>
                    <td className="p-3 font-semibold text-slate-100">{file.fileName}</td>
                    <td className="p-3">
                      <span className="px-1.5 py-0.5 rounded bg-slate-800 font-mono text-[10px] text-slate-300">
                        {file.fileType}
                      </span>
                    </td>
                    <td className="p-3 text-right font-mono">{file.fileSize} MB</td>
                    <td className="p-3 text-slate-400">{file.createdAt}</td>
                    <td className="p-3 font-mono text-slate-400">{file.lastAccessed || "Never"}</td>
                    <td className="p-3 text-center font-bold text-slate-300">{file.accessCount}</td>
                    <td className="p-3 text-center">
                      {isCached ? (
                        <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>IN CACHE</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-slate-800 text-slate-400">
                          <span>DISK ONLY</span>
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add File Modal */}
      {isAddOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleCreateFile}
            className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl"
          >
            <h3 className="text-base font-bold text-slate-100">Add New File to Storage</h3>
            <p className="text-xs text-slate-400">Create a simulated secondary storage file entry.</p>

            <div className="space-y-3">
              <div>
                <label className="text-[11px] font-semibold text-slate-400 block mb-1">File ID:</label>
                <input
                  type="text"
                  value={newFileId}
                  onChange={(e) => setNewFileId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 outline-none focus:border-sky-500 font-mono"
                  required
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-400 block mb-1">File Name:</label>
                <input
                  type="text"
                  placeholder="e.g. database_backup.sql"
                  value={newFileName}
                  onChange={(e) => setNewFileName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 outline-none focus:border-sky-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-semibold text-slate-400 block mb-1">File Type:</label>
                  <select
                    value={newFileType}
                    onChange={(e) => setNewFileType(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 outline-none focus:border-sky-500"
                  >
                    {["PDF", "DOCX", "JPG", "PNG", "MP4", "TXT", "SQL", "CSV", "PPTX", "ZIP"].map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[11px] font-semibold text-slate-400 block mb-1">Size (MB):</label>
                  <input
                    type="number"
                    step="0.1"
                    min="0.01"
                    value={newFileSize}
                    onChange={(e) => setNewFileSize(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 outline-none focus:border-sky-500 font-mono"
                    required
                  />
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end space-x-2 pt-2">
              <button
                type="button"
                onClick={() => setIsAddOpen(false)}
                className="px-4 py-1.5 rounded text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 rounded text-xs font-bold bg-sky-500 hover:bg-sky-400 text-slate-950"
              >
                Save File
              </button>
            </div>
          </form>
        </div>
      )}

      {/* View Details Modal */}
      {isDetailsOpen && selectedFile && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-slate-100">File Metadata Details</h3>
              <button
                onClick={() => setIsDetailsOpen(false)}
                className="text-xs text-slate-400 hover:text-slate-200 bg-slate-800 px-2 py-1 rounded"
              >
                Close
              </button>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-800/40">
                <span className="text-slate-400 font-medium">File ID:</span>
                <span className="font-mono text-sky-400 font-bold">{selectedFile.fileId}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/40">
                <span className="text-slate-400 font-medium">File Name:</span>
                <span className="font-semibold text-slate-200">{selectedFile.fileName}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/40">
                <span className="text-slate-400 font-medium">Type:</span>
                <span className="font-mono text-slate-300">{selectedFile.fileType}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/40">
                <span className="text-slate-400 font-medium">Size:</span>
                <span className="font-mono text-slate-300">{selectedFile.fileSize} MB</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/40">
                <span className="text-slate-400 font-medium">Created:</span>
                <span className="text-slate-300">{selectedFile.createdAt}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/40">
                <span className="text-slate-400 font-medium">Last Accessed:</span>
                <span className="font-mono text-slate-300">{selectedFile.lastAccessed || "Never"}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/40">
                <span className="text-slate-400 font-medium">Access Hits:</span>
                <span className="font-bold text-slate-200">{selectedFile.accessCount}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-400 font-medium">Memory Cache Status:</span>
                <span className={`font-bold ${cachedFileIds.has(selectedFile.fileId) ? "text-emerald-400" : "text-slate-400"}`}>
                  {cachedFileIds.has(selectedFile.fileId) ? "● CURRENTLY IN RAM" : "○ SECONDARY DISK ONLY"}
                </span>
              </div>
            </div>

            <div className="pt-2">
              <button
                onClick={() => {
                  setIsDetailsOpen(false);
                  onAccessFile(selectedFile.fileId);
                }}
                className="w-full py-2 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-xs rounded-lg transition cursor-pointer"
              >
                Access File Now
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
