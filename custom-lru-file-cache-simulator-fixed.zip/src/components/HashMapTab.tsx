import React, { useState, useMemo } from "react";
import { BucketItem, FileNodeItem } from "../types";
import {
  Hash,
  AlertTriangle,
  CheckCircle2,
  ArrowRight,
  Calculator,
  BarChart3,
  Cpu,
  Layers,
  Sparkles,
  Info,
  ShieldCheck,
  Zap
} from "lucide-react";
import { DynamicHashMappingVisualizer } from "./DynamicHashMappingVisualizer";
import {
  HashAlgorithmId,
  HASH_ALGORITHMS,
  ALGORITHM_LIST,
  AlgorithmStep
} from "../hashAlgorithms";
import { soundFx } from "../audioSynth";

interface HashMapTabProps {
  diagnostics: {
    capacity: number;
    entries: number;
    collisions: number;
    loadFactor: number;
    bucketUtilizationPct: number;
    buckets: BucketItem[];
  };
  onRefresh: () => void;
  allFiles?: FileNodeItem[];
}

export const HashMapTab: React.FC<HashMapTabProps> = ({
  diagnostics,
  onRefresh,
  allFiles = []
}) => {
  const [selectedAlgorithm, setSelectedAlgorithm] = useState<HashAlgorithmId>("polynomial");
  const [testKey, setTestKey] = useState<string>("report.pdf");

  const currentAlgoDef = HASH_ALGORITHMS[selectedAlgorithm] || HASH_ALGORITHMS.polynomial;

  // Extract all distinct files currently in the cache
  const activeFileList: FileNodeItem[] = useMemo(() => {
    const map = new Map<string, FileNodeItem>();
    diagnostics.buckets.forEach((b) => {
      b.entries.forEach((e) => {
        if (!map.has(e.fileId)) {
          map.set(e.fileId, e);
        }
      });
    });
    // If empty or has extra files from props
    allFiles.forEach((f) => {
      if (!map.has(f.fileId) && map.size < 16) {
        map.set(f.fileId, f);
      }
    });
    return Array.from(map.values());
  }, [diagnostics.buckets, allFiles]);

  // Compute dynamic bucket array for the currently selected hash function algorithm
  const dynamicBuckets: BucketItem[] = useMemo(() => {
    const buckets: BucketItem[] = Array.from({ length: diagnostics.capacity }, (_, i) => ({
      index: i,
      keys: [],
      isCollision: false,
      entries: []
    }));

    activeFileList.forEach((file) => {
      const slot = currentAlgoDef.computeIndex(file.fileId, diagnostics.capacity);
      if (buckets[slot]) {
        buckets[slot].keys.push(file.fileId);
        buckets[slot].entries.push(file);
        if (buckets[slot].entries.length > 1) {
          buckets[slot].isCollision = true;
        }
      }
    });

    return buckets;
  }, [activeFileList, diagnostics.capacity, currentAlgoDef]);

  // Dynamic collision stats for selected algorithm
  const { dynamicCollisions, dynamicUtilizationPct } = useMemo(() => {
    let cols = 0;
    let occupied = 0;
    dynamicBuckets.forEach((b) => {
      if (b.entries.length > 0) occupied++;
      if (b.entries.length > 1) {
        cols += b.entries.length - 1;
      }
    });
    const util = Math.round((occupied / diagnostics.capacity) * 100);
    return { dynamicCollisions: cols, dynamicUtilizationPct: util };
  }, [dynamicBuckets, diagnostics.capacity]);

  // Real-time benchmark scoreboard for all 5 algorithms on current cache entries
  const algorithmScoreboard = useMemo(() => {
    const scoreboard: Record<
      HashAlgorithmId,
      { collisions: number; occupied: number; collisionRatePct: number }
    > = {} as any;

    ALGORITHM_LIST.forEach((algo) => {
      const counts = new Array(diagnostics.capacity).fill(0);
      activeFileList.forEach((f) => {
        const slot = algo.computeIndex(f.fileId, diagnostics.capacity);
        counts[slot] = (counts[slot] || 0) + 1;
      });

      let cols = 0;
      let occ = 0;
      counts.forEach((c) => {
        if (c > 0) occ++;
        if (c > 1) cols += c - 1;
      });

      const rate = activeFileList.length > 0
        ? Math.round((cols / activeFileList.length) * 100)
        : 0;

      scoreboard[algo.id] = {
        collisions: cols,
        occupied: occ,
        collisionRatePct: rate
      };
    });

    return scoreboard;
  }, [activeFileList, diagnostics.capacity]);

  // Step-by-step computation for the selected algorithm
  const { steps, finalBucket, rawHash } = useMemo(() => {
    const calcSteps: AlgorithmStep[] = currentAlgoDef.computeSteps(testKey, diagnostics.capacity);
    const bucket = currentAlgoDef.computeIndex(testKey, diagnostics.capacity);
    const raw = currentAlgoDef.computeRaw(testKey);
    return { steps: calcSteps, finalBucket: bucket, rawHash: raw };
  }, [testKey, diagnostics.capacity, currentAlgoDef]);

  const targetBucket = dynamicBuckets.find((b) => b.index === finalBucket);
  const willCollide =
    targetBucket &&
    targetBucket.entries.length > 0 &&
    !targetBucket.keys.includes(testKey);

  const handleSelectAlgorithm = (id: HashAlgorithmId) => {
    setSelectedAlgorithm(id);
    soundFx.playClick();
  };

  return (
    <div className="space-y-5 p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-100 flex items-center space-x-2">
            <span>Custom Hash Map & Algorithm Collision Lab</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Switch between hash algorithms to observe real-time avalanche dispersal, collision clustering, and bucket separate chaining.
          </p>
        </div>

        <button
          onClick={onRefresh}
          className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold transition cursor-pointer self-start md:self-auto flex items-center space-x-1.5"
        >
          <span>Refresh Buckets</span>
        </button>
      </div>

      {/* Hash Function Algorithm Selector & Comparison Suite */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-lg">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-lg bg-sky-500/10 border border-sky-500/30 flex items-center justify-center text-sky-400">
              <Cpu className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-100 flex items-center space-x-2">
                <span>Selectable Hash Function Algorithm Suite</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                  {ALGORITHM_LIST.length} Algorithms
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Choose an algorithm to immediately rehash active keys and observe collision fluctuations across all buckets.
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <span className="text-xs text-slate-400">Active:</span>
            <span className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold border ${currentAlgoDef.badgeBg} ${currentAlgoDef.qualityColor} ${currentAlgoDef.badgeBorder}`}>
              {currentAlgoDef.name}
            </span>
          </div>
        </div>

        {/* Algorithm Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {ALGORITHM_LIST.map((algo) => {
            const isSelected = algo.id === selectedAlgorithm;
            const stats = algorithmScoreboard[algo.id] || {
              collisions: 0,
              occupied: 0,
              collisionRatePct: 0
            };
            const hasCollisions = stats.collisions > 0;

            return (
              <button
                key={algo.id}
                onClick={() => handleSelectAlgorithm(algo.id)}
                className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between space-y-2.5 ${
                  isSelected
                    ? "bg-sky-950/40 border-sky-500 ring-2 ring-sky-500/60 shadow-md"
                    : "bg-slate-950 border-slate-800 hover:border-slate-700 hover:bg-slate-900"
                }`}
              >
                <div>
                  <div className="flex items-start justify-between gap-1.5 mb-1">
                    <span
                      className={`text-xs font-bold font-mono ${
                        isSelected ? "text-sky-300" : "text-slate-200"
                      }`}
                    >
                      {algo.shortName}
                    </span>
                    <span
                      className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold border shrink-0 ${
                        hasCollisions
                          ? "bg-rose-950/80 text-rose-400 border-rose-500/60"
                          : "bg-emerald-950/60 text-emerald-400 border-emerald-500/40"
                      }`}
                    >
                      {stats.collisions} {stats.collisions === 1 ? "collision" : "collisions"}
                    </span>
                  </div>

                  <div className="text-[10px] font-mono text-slate-400 truncate">
                    {algo.formula}
                  </div>
                </div>

                <div className="space-y-1.5 pt-2 border-t border-slate-800/80 text-[10px]">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Quality:</span>
                    <span className={`font-semibold ${algo.qualityColor}`}>{algo.quality}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Collision Rate:</span>
                    <span
                      className={`font-mono font-bold ${
                        hasCollisions ? "text-rose-400" : "text-emerald-400"
                      }`}
                    >
                      {stats.collisionRatePct}% ({stats.collisions}/{activeFileList.length})
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Bucket Spread:</span>
                    <span className="font-mono text-slate-300">
                      {stats.occupied}/{diagnostics.capacity} slots
                    </span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Selected Algorithm Explanation Banner */}
        <div className="bg-slate-950 border border-slate-800/90 rounded-xl p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="space-y-1">
            <div className="flex items-center space-x-2">
              <span className="font-bold text-slate-200">{currentAlgoDef.name}</span>
              <span className="text-[10px] text-slate-500 font-mono">({currentAlgoDef.author})</span>
            </div>
            <p className="text-slate-400 text-[11px] leading-relaxed">
              {currentAlgoDef.formulaExplanation}
            </p>
          </div>

          <div className="shrink-0 flex items-center space-x-2 font-mono text-[11px] bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-800">
            <span className="text-slate-400">Formula:</span>
            <span className="text-sky-300 font-bold">{currentAlgoDef.formula}</span>
          </div>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Bucket Array Slots
          </span>
          <div className="text-lg font-bold text-sky-400 font-mono mt-1">
            {diagnostics.capacity}
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Active Entries
          </span>
          <div className="text-lg font-bold text-slate-100 font-mono mt-1">
            {activeFileList.length}
          </div>
        </div>

        <div
          className={`rounded-xl p-3 border transition-colors ${
            dynamicCollisions > 0
              ? "bg-rose-950/20 border-rose-500/50"
              : "bg-slate-900 border-slate-800"
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
              {currentAlgoDef.shortName} Collisions
            </span>
          </div>
          <div
            className={`text-lg font-bold font-mono mt-1 ${
              dynamicCollisions > 0 ? "text-rose-400 font-extrabold" : "text-emerald-400"
            }`}
          >
            {dynamicCollisions}
          </div>
        </div>

        <div
          className={`rounded-xl p-3 border transition-colors ${
            diagnostics.loadFactor >= 0.75
              ? "bg-rose-950/20 border-rose-500/50"
              : "bg-slate-900 border-slate-800"
          }`}
        >
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Load Factor (α)
          </span>
          <div
            className={`text-lg font-bold font-mono mt-1 ${
              diagnostics.loadFactor >= 0.75
                ? "text-rose-400 font-extrabold"
                : diagnostics.loadFactor >= 0.5
                ? "text-amber-400"
                : "text-emerald-400"
            }`}
          >
            {diagnostics.loadFactor}
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Bucket Utilization
          </span>
          <div className="text-lg font-bold text-emerald-400 font-mono mt-1">
            {dynamicUtilizationPct}%
          </div>
        </div>
      </div>

      {/* Dynamic Key-to-Bucket Mapping & Red Collision Visualizer */}
      <DynamicHashMappingVisualizer
        realCapacity={diagnostics.capacity}
        realBuckets={dynamicBuckets}
        allFiles={allFiles}
        algorithm={selectedAlgorithm}
        onAlgorithmChange={setSelectedAlgorithm}
      />

      {/* Interactive Hash Calculator & Algorithm Stepper */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-2">
            <Calculator className="w-4 h-4 text-sky-400" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Interactive {currentAlgoDef.name} Stepper
            </h3>
          </div>

          <div className="flex items-center space-x-2">
            <span className="text-xs text-slate-400">Test String Key:</span>
            <input
              type="text"
              value={testKey}
              onChange={(e) => setTestKey(e.target.value)}
              placeholder="e.g. report.pdf, F001"
              className="bg-slate-950 text-sky-300 font-mono text-xs px-3 py-1 rounded-lg border border-slate-700 outline-none focus:border-sky-500 w-44"
            />
          </div>
        </div>

        {/* Calculation Details Banner */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1">
            <span className="text-[10px] font-mono text-slate-400 uppercase block">Active Formula</span>
            <div className="font-mono text-xs text-sky-400 font-bold truncate">
              {currentAlgoDef.formula}
            </div>
            <p className="text-[11px] text-slate-400 line-clamp-2">
              {currentAlgoDef.formulaExplanation}
            </p>
          </div>

          <div className="bg-slate-950 p-3.5 rounded-xl border border-sky-500/30 space-y-1">
            <span className="text-[10px] font-mono text-slate-400 uppercase block">Target Bucket Slot</span>
            <div className="font-mono text-lg text-sky-300 font-bold">
              Bucket [{finalBucket}]
            </div>
            <p className="text-[11px] text-slate-400">
              Raw 32-bit hash: <span className="font-mono text-sky-400">{rawHash}</span> % {diagnostics.capacity}
            </p>
          </div>

          <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1">
            <span className="text-[10px] font-mono text-slate-400 uppercase block">Collision Prediction</span>
            <div className="font-mono text-sm font-bold flex items-center space-x-1.5">
              {willCollide ? (
                <span className="text-rose-400 flex items-center space-x-1 font-bold">
                  <AlertTriangle className="w-4 h-4 text-rose-500" />
                  <span>Collision Chain ({targetBucket?.entries.length} items present)</span>
                </span>
              ) : (
                <span className="text-emerald-400 flex items-center space-x-1">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Direct O(1) Slot Assignment</span>
                </span>
              )}
            </div>
            <p className="text-[11px] text-slate-400 truncate">
              {targetBucket?.entries.length === 0
                ? "Slot is currently empty"
                : `Contains: ${targetBucket?.keys.join(", ")}`}
            </p>
          </div>
        </div>

        {/* Stepper Table */}
        {steps.length > 0 && (
          <div className="overflow-x-auto max-h-56 overflow-y-auto rounded-lg border border-slate-800">
            <table className="w-full text-left border-collapse text-xs font-mono">
              <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 sticky top-0">
                <tr>
                  <th className="p-2">Step</th>
                  <th className="p-2">Char</th>
                  <th className="p-2">ASCII (c)</th>
                  <th className="p-2">Prev Val</th>
                  <th className="p-2">Operation Formula</th>
                  <th className="p-2">Raw Value</th>
                  <th className="p-2 text-sky-400">Bucket % {diagnostics.capacity}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 bg-slate-900/50 text-slate-300">
                {steps.map((st) => (
                  <tr key={st.step} className="hover:bg-slate-800/40">
                    <td className="p-2 font-bold text-slate-400">{st.step}</td>
                    <td className="p-2 text-sky-400 font-bold">'{st.char}'</td>
                    <td className="p-2 text-slate-400">{st.charCode}</td>
                    <td className="p-2 text-slate-400 truncate max-w-[120px]">{st.prevVal}</td>
                    <td className="p-2 text-amber-300 font-mono">{st.operationText}</td>
                    <td className="p-2 text-slate-400">{st.rawResult}</td>
                    <td className="p-2 font-bold text-sky-300 bg-sky-950/20">{st.bucketResult}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Bucket Distribution Histogram */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <BarChart3 className="w-4 h-4 text-sky-400" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              {currentAlgoDef.shortName} Slot Occupancy & Collision Histogram
            </h3>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            {activeFileList.length} items across {diagnostics.capacity} slots ({dynamicCollisions} collisions)
          </span>
        </div>

        <div className="grid grid-cols-8 sm:grid-cols-16 gap-1.5 pt-2">
          {dynamicBuckets.map((b) => {
            const count = b.entries.length;
            const isHighlight = b.index === finalBucket;
            return (
              <div
                key={b.index}
                className={`flex flex-col items-center justify-end p-2 rounded-lg border text-center transition-all ${
                  isHighlight
                    ? "bg-sky-950/60 border-sky-500 ring-1 ring-sky-500"
                    : count > 1
                    ? "bg-rose-950/40 border-rose-500/80 ring-1 ring-rose-500/50 shadow-sm shadow-rose-950/50"
                    : count === 1
                    ? "bg-emerald-950/20 border-emerald-500/30"
                    : "bg-slate-950 border-slate-800/80 opacity-60"
                }`}
              >
                <div
                  className={`text-xs font-bold font-mono mb-1 ${
                    count > 1 ? "text-rose-400 font-extrabold" : "text-slate-200"
                  }`}
                >
                  {count}
                </div>
                <div
                  className={`w-full rounded-t transition-all ${
                    isHighlight
                      ? "bg-sky-400"
                      : count > 1
                      ? "bg-rose-500 shadow-sm shadow-rose-500/50"
                      : count === 1
                      ? "bg-emerald-500"
                      : "bg-slate-800"
                  }`}
                  style={{ height: `${Math.max(6, count * 18)}px` }}
                />
                <span className="text-[9px] font-mono text-slate-400 mt-1.5">[{b.index}]</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Bucket Array Inspection (Separate Chaining) */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300">
            Separate Chaining Linked Lists ({currentAlgoDef.shortName})
          </h3>
          <span className="text-xs font-mono text-slate-400">
            Colliding buckets highlighted in <span className="text-rose-400 font-bold">RED</span>
          </span>
        </div>

        <div className="space-y-2">
          {dynamicBuckets.map((b) => {
            const hasEntries = b.entries.length > 0;
            const isCollision = b.isCollision;
            const isTarget = b.index === finalBucket;

            return (
              <div
                key={b.index}
                className={`bg-slate-900 border rounded-xl p-3 transition-all ${
                  isTarget
                    ? "ring-1 ring-sky-500 border-sky-500/80 bg-sky-950/10"
                    : isCollision
                    ? "border-rose-500/70 bg-rose-950/20 ring-1 ring-rose-500/40 shadow-sm shadow-rose-950/40"
                    : hasEntries
                    ? "border-slate-800 hover:border-slate-700"
                    : "border-slate-800/50 opacity-60"
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <span
                      className={`font-mono text-xs font-bold px-2 py-0.5 rounded border ${
                        isCollision
                          ? "text-rose-400 bg-rose-950/60 border-rose-500/50"
                          : "text-sky-400 bg-slate-950 border-slate-800"
                      }`}
                    >
                      Bucket [{b.index}]
                    </span>
                    {hasEntries && (
                      <span className="text-[11px] text-slate-400 font-mono">
                        {b.entries.length} {b.entries.length === 1 ? "entry" : "chained entries"}
                      </span>
                    )}
                  </div>

                  {isCollision ? (
                    <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40 animate-pulse">
                      <AlertTriangle className="w-3 h-3 text-rose-400" />
                      <span>COLLISION CHAIN ({b.entries.length} NODES)</span>
                    </span>
                  ) : hasEntries ? (
                    <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded text-[10px] font-medium bg-emerald-500/10 text-emerald-400">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>Direct 1:1 Map</span>
                    </span>
                  ) : (
                    <span className="text-[10px] font-mono text-slate-600 uppercase">
                      Empty Slot
                    </span>
                  )}
                </div>

                {/* Chained Linked List of Entries */}
                {!hasEntries ? (
                  <div className="font-mono text-xs text-slate-600 italic pl-1">
                    (null) — no nodes mapped to this bucket under {currentAlgoDef.shortName}
                  </div>
                ) : (
                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    {b.entries.map((entry, eIdx) => (
                      <React.Fragment key={entry.fileId}>
                        <div
                          className={`border px-3 py-2 rounded-lg flex items-center space-x-2.5 shadow-sm ${
                            isCollision
                              ? "bg-rose-950/40 border-rose-500/40 text-rose-200"
                              : "bg-slate-950 border-slate-800"
                          }`}
                        >
                          <span
                            className={`font-mono text-xs font-bold ${
                              isCollision ? "text-rose-400" : "text-sky-400"
                            }`}
                          >
                            {entry.fileId}
                          </span>
                          <div>
                            <div className="text-xs font-semibold text-slate-200">
                              {entry.fileName}
                            </div>
                            <div className="text-[10px] text-slate-500 font-mono">
                              {entry.fileType} • {entry.fileSize}MB
                            </div>
                          </div>
                        </div>

                        {eIdx < b.entries.length - 1 && (
                          <div
                            className={`flex items-center font-mono text-xs ${
                              isCollision ? "text-rose-400 font-bold" : "text-amber-400"
                            }`}
                          >
                            <span className="mr-1 text-[10px]">chain</span>
                            <ArrowRight className="w-3.5 h-3.5" />
                          </div>
                        )}
                      </React.Fragment>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
