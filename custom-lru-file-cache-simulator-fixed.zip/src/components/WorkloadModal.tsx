import React, { useState } from "react";
import { Sparkles, X, Play } from "lucide-react";

interface WorkloadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRunWorkload: (patternName: string, fileSequence: string[]) => void;
}

export const WorkloadModal: React.FC<WorkloadModalProps> = ({
  isOpen,
  onClose,
  onRunWorkload
}) => {
  const [selectedPattern, setSelectedPattern] = useState<string>("temporal");

  if (!isOpen) return null;

  const patterns = [
    {
      id: "temporal",
      name: "High Temporal Locality (High Hit Rate)",
      desc: "Simulates repeated access to a small active working set ('hot files'). Expected hit rate > 80%.",
      sequence: ["F001", "F002", "F001", "F003", "F001", "F002", "F001", "F003", "F002", "F001"]
    },
    {
      id: "thrashing",
      name: "Sequential Scan (Cache Thrashing)",
      desc: "Sweeps through 10 distinct files in order, causing continuous 100% cache miss and eviction if capacity < 10.",
      sequence: ["F001", "F002", "F003", "F004", "F005", "F006", "F007", "F008", "F009", "F010"]
    },
    {
      id: "zipf",
      name: "Zipfian Skewed Distribution",
      desc: "Realistic 80/20 power-law workload where top files receive the vast majority of access requests.",
      sequence: ["F001", "F001", "F002", "F001", "F005", "F001", "F002", "F006", "F001", "F003", "F001"]
    },
    {
      id: "alternating",
      name: "Alternating Ping-Pong Pattern",
      desc: "Swaps access between two files (F001 and F004) to demonstrate constant MRU/HEAD promotion.",
      sequence: ["F001", "F004", "F001", "F004", "F001", "F004", "F001", "F004"]
    }
  ];

  const handleRun = () => {
    const p = patterns.find((item) => item.id === selectedPattern);
    if (p) {
      onRunWorkload(p.name, p.sequence);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-2 text-sky-400">
            <Sparkles className="w-5 h-5" />
            <h3 className="text-base font-bold text-slate-100">
              Run Workload Access Pattern
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-200 rounded-lg hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <p className="text-xs text-slate-400">
          Select a benchmark access profile to evaluate cache hit ratios, tail evictions, and locality behaviors.
        </p>

        <div className="space-y-2.5">
          {patterns.map((p) => {
            const isSelected = selectedPattern === p.id;
            return (
              <div
                key={p.id}
                onClick={() => setSelectedPattern(p.id)}
                className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                  isSelected
                    ? "bg-sky-500/10 border-sky-500 ring-1 ring-sky-500/40"
                    : "bg-slate-950 border-slate-800 hover:border-slate-700"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-100">{p.name}</span>
                  <span className="text-[10px] font-mono text-sky-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                    {p.sequence.length} requests
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1">{p.desc}</p>
                <div className="text-[10px] font-mono text-slate-500 mt-2 truncate">
                  Sequence: {p.sequence.join(" → ")}
                </div>
              </div>
            );
          })}
        </div>

        <div className="flex items-center justify-end space-x-2 pt-2">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
          >
            Cancel
          </button>
          <button
            onClick={handleRun}
            className="flex items-center space-x-1.5 px-4 py-1.5 rounded text-xs font-bold bg-sky-500 hover:bg-sky-400 text-slate-950 transition cursor-pointer"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>Execute Pattern</span>
          </button>
        </div>
      </div>
    </div>
  );
};
