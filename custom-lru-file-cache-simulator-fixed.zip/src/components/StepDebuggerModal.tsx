import React, { useState, useEffect } from "react";
import { StepTrace } from "../types";
import { Play, Pause, ChevronLeft, ChevronRight, RotateCcw, X, ArrowRight, CheckCircle2, Cpu, Code2, Database } from "lucide-react";
import { soundFx } from "../audioSynth";

interface StepDebuggerModalProps {
  isOpen: boolean;
  onClose: () => void;
  traces: StepTrace[];
  fileName: string;
  onExecuteFinal: () => void;
}

export const StepDebuggerModal: React.FC<StepDebuggerModalProps> = ({
  isOpen,
  onClose,
  traces,
  fileName,
  onExecuteFinal
}) => {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setCurrentStepIndex(0);
      setIsPlaying(false);
    }
  }, [isOpen, traces]);

  useEffect(() => {
    let timer: any;
    if (isPlaying && currentStepIndex < traces.length - 1) {
      timer = setTimeout(() => {
        setCurrentStepIndex((prev) => prev + 1);
        soundFx.playClick();
      }, 1400);
    } else if (isPlaying && currentStepIndex >= traces.length - 1) {
      setIsPlaying(false);
    }
    return () => clearTimeout(timer);
  }, [isPlaying, currentStepIndex, traces.length]);

  if (!isOpen || traces.length === 0) return null;

  const currentTrace = traces[currentStepIndex];

  // Code snippets for each action type
  const getCodeSnippet = (actionType: string) => {
    switch (actionType) {
      case "lookup":
        return `// O(1) Hash Table Lookup
DLLNode* node = hashMap.get(fileId);
if (node != nullptr) {
    // Cache HIT: proceed to promotion
    promoteToHead(node);
    return node->data;
}`;
      case "hit_promote":
        return `// O(1) DLL Splice & Re-attach to Head
node->prev->next = node->next;
node->next->prev = node->prev;

node->next = head;
node->prev = nullptr;
head->prev = node;
head = node;`;
      case "miss_storage":
        return `// Cache MISS: Load from Storage Disk
FileRecord file = storageDisk.read(fileId); // ~1.8ms
if (dll.size >= capacity) {
    evictTail(); // make room
}
insertAtHead(file);`;
      case "evict_tail":
        return `// O(1) LRU Tail Eviction
DLLNode* victim = tail;
hashMap.remove(victim->key);
tail = tail->prev;
tail->next = nullptr;
delete victim; // Free RAM block`;
      case "insert_head":
        return `// O(1) Insert New Node at Head (MRU)
DLLNode* newNode = new DLLNode(key, fileData);
newNode->next = head;
if (head != nullptr) head->prev = newNode;
head = newNode;
hashMap.put(key, newNode);`;
      default:
        return `// Pointer state update in O(1)`;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 select-none">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/90">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-xl bg-sky-500/10 border border-sky-500/30 text-sky-400">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-sm font-bold uppercase tracking-wider text-slate-100">
                  Interactive Algorithmic Step Debugger
                </h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-sky-950 text-sky-300 border border-sky-800">
                  {fileName}
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Step-by-step microscopic trace of Hash Map & Doubly Linked List pointer operations
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 p-1.5 rounded-lg hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Progress Pills */}
        <div className="px-5 py-3 bg-slate-950/60 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            {traces.map((t, idx) => (
              <button
                key={idx}
                onClick={() => {
                  soundFx.playClick();
                  setCurrentStepIndex(idx);
                }}
                className={`px-3 py-1 rounded-full text-xs font-mono font-bold transition-all cursor-pointer ${
                  idx === currentStepIndex
                    ? "bg-sky-500 text-slate-950 shadow-md shadow-sky-500/30 ring-2 ring-sky-400"
                    : idx < currentStepIndex
                    ? "bg-emerald-950 text-emerald-300 border border-emerald-800"
                    : "bg-slate-800 text-slate-400 hover:bg-slate-700"
                }`}
              >
                Step {idx + 1}
              </button>
            ))}
          </div>

          <div className="text-xs font-mono text-slate-400">
            Progress: {currentStepIndex + 1} / {traces.length}
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          {/* Active Step Highlight Card */}
          <div className="bg-slate-950 border border-sky-500/30 rounded-xl p-4 shadow-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-sky-400 px-2 py-0.5 rounded bg-sky-950 border border-sky-800">
                Operation: {currentTrace.actionType.toUpperCase()}
              </span>
              <span className="text-xs font-mono text-slate-400">
                Step {currentTrace.step} of {traces.length}
              </span>
            </div>
            <h4 className="text-base font-bold text-slate-100">{currentTrace.title}</h4>
            <p className="text-xs text-slate-300 mt-1.5 leading-relaxed">
              {currentTrace.description}
            </p>
          </div>

          {/* Visual Memory Pointer Diagram */}
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-4">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center space-x-2">
                <Database className="w-3.5 h-3.5 text-sky-400" />
                <span>Memory State Visualization</span>
              </span>
              <span className="text-[10px] font-mono text-slate-500">
                Constant Time O(1) Pointer Relocation
              </span>
            </div>

            <div className="flex items-center justify-center py-4 px-2 space-x-3 overflow-x-auto">
              <div className="px-3 py-2 rounded-lg bg-sky-950/80 border border-sky-500/50 text-sky-300 text-center font-mono text-xs">
                <div className="text-[10px] text-sky-500 uppercase">Head Pointer</div>
                <div className="font-bold mt-0.5">HEAD (MRU)</div>
              </div>

              <span className="text-slate-500 font-mono">⇄</span>

              <div className={`px-4 py-3 rounded-xl border text-center transition-all ${
                currentTrace.actionType === "insert_head" || currentTrace.actionType === "hit_promote"
                  ? "bg-sky-500/20 border-sky-400 ring-2 ring-sky-400/50 text-sky-200"
                  : "bg-slate-900 border-slate-700 text-slate-300"
              }`}>
                <div className="text-[10px] font-mono text-slate-400">Target Node</div>
                <div className="font-bold text-xs mt-0.5">{currentTrace.targetFile}</div>
                <div className="text-[9px] font-mono text-slate-500 mt-1">prev ⇄ next</div>
              </div>

              <span className="text-slate-500 font-mono">⇄</span>

              <div className={`px-3 py-2 rounded-lg border text-center font-mono text-xs ${
                currentTrace.actionType === "evict_tail"
                  ? "bg-rose-950/80 border-rose-500 text-rose-300 ring-2 ring-rose-500/50"
                  : "bg-slate-900 border-slate-800 text-slate-400"
              }`}>
                <div className="text-[10px] text-amber-500 uppercase">Tail Pointer</div>
                <div className="font-bold mt-0.5">TAIL (LRU)</div>
              </div>
            </div>
          </div>

          {/* Machine Code Snippet */}
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center space-x-2">
                <Code2 className="w-3.5 h-3.5 text-indigo-400" />
                <span>Low-Level Algorithm Pointer Implementation</span>
              </span>
              <span className="text-[10px] font-mono text-slate-500">C++ / TS Syntax</span>
            </div>
            <pre className="text-xs font-mono text-sky-300 bg-slate-900/90 p-3 rounded-lg border border-slate-800 overflow-x-auto leading-relaxed">
              {getCodeSnippet(currentTrace.actionType)}
            </pre>
          </div>
        </div>

        {/* Modal Controls Footer */}
        <div className="px-5 py-3 border-t border-slate-800 bg-slate-950 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <button
              onClick={() => {
                soundFx.playClick();
                setCurrentStepIndex((prev) => Math.max(0, prev - 1));
              }}
              disabled={currentStepIndex === 0}
              className="flex items-center space-x-1 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold disabled:opacity-40 transition cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Previous</span>
            </button>

            <button
              onClick={() => {
                soundFx.playClick();
                setIsPlaying(!isPlaying);
              }}
              className="flex items-center space-x-1 px-3.5 py-1.5 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-950 text-xs font-bold transition cursor-pointer"
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              <span>{isPlaying ? "Pause" : "Auto Play"}</span>
            </button>

            <button
              onClick={() => {
                soundFx.playClick();
                setCurrentStepIndex((prev) => Math.min(traces.length - 1, prev + 1));
              }}
              disabled={currentStepIndex === traces.length - 1}
              className="flex items-center space-x-1 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold disabled:opacity-40 transition cursor-pointer"
            >
              <span>Next Step</span>
              <ChevronRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => {
                soundFx.playClick();
                setCurrentStepIndex(0);
                setIsPlaying(false);
              }}
              title="Reset Stepper to Step 1"
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 transition cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>

          <button
            onClick={() => {
              soundFx.playClick();
              onExecuteFinal();
              onClose();
            }}
            className="flex items-center space-x-1.5 px-4 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition cursor-pointer shadow-lg shadow-emerald-500/20"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Apply to Live Memory</span>
          </button>
        </div>
      </div>
    </div>
  );
};
