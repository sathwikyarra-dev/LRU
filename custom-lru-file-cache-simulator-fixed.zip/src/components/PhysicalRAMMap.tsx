import React, { useState } from "react";
import { FileNodeItem } from "../types";
import { HardDrive, Cpu, Shield, Search, Binary, ExternalLink, X } from "lucide-react";
import { soundFx } from "../audioSynth";

interface PhysicalRAMMapProps {
  cachedNodes: FileNodeItem[];
  capacity: number;
  onInspectNode?: (file: FileNodeItem) => void;
  onPromoteNode?: (fileId: string) => void;
}

export const PhysicalRAMMap: React.FC<PhysicalRAMMapProps> = ({
  cachedNodes,
  capacity,
  onInspectNode,
  onPromoteNode
}) => {
  const [selectedSlotIndex, setSelectedSlotIndex] = useState<number | null>(0);

  // Generate simulated slots up to capacity (max 20)
  const totalSlots = Math.max(capacity, 8);

  const slots = Array.from({ length: totalSlots }).map((_, index) => {
    const node = cachedNodes[index] || null;
    const baseAddress = 0x7fff0000 + index * 0x0040;
    const hexAddress = `0x${baseAddress.toString(16).toUpperCase()}`;
    const prevAddress = index > 0 && cachedNodes[index - 1]
      ? `0x${(0x7fff0000 + (index - 1) * 0x0040).toString(16).toUpperCase()}`
      : "0x00000000 (HEAD)";
    const nextAddress = index < cachedNodes.length - 1 && cachedNodes[index + 1]
      ? `0x${(0x7fff0000 + (index + 1) * 0x0040).toString(16).toUpperCase()}`
      : "0x00000000 (TAIL)";

    return {
      index,
      hexAddress,
      isAllocated: !!node,
      node,
      prevAddress,
      nextAddress,
      isHead: index === 0 && !!node,
      isTail: index === cachedNodes.length - 1 && !!node
    };
  });

  const selectedSlot = selectedSlotIndex !== null ? slots[selectedSlotIndex] : null;

  // Generate simulated hex dump bytes for the selected file
  const generateSimulatedHexDump = (file: FileNodeItem | null) => {
    if (!file) {
      return [
        "0000: 00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00 | ................",
        "0010: 00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00 | ................",
        "0020: 00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00 | ................",
        "0030: 00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00 | ................",
      ];
    }

    const nameBytes = file.fileName
      .split("")
      .map((c) => c.charCodeAt(0).toString(16).padStart(2, "0"))
      .join(" ");

    return [
      `0000: 4c 52 55 5f 4e 4f 44 45  ${nameBytes.slice(0, 23)} | LRU_NODE ${file.fileName.slice(0, 8)}`,
      `0010: 00 00 ${file.fileSize.toString(16).padStart(2, "0")} 00 00 00 00 00  ${file.fileType === "CODE" ? "63 6f 64 65" : "64 61 74 61"} 00 00 00 | ..${file.fileSize}M.... ${file.fileType.toLowerCase()}...`,
      `0020: 7f ff 00 ${((selectedSlotIndex || 0) * 64).toString(16).padStart(2, "0")} 00 00 00 00  00 00 00 00 00 00 00 00 | ................`,
      `0030: ff ff ff ff 00 00 00 00  ${(file.accessCount || 1).toString(16).padStart(2, "0")} 00 00 00 00 00 00 00 | ........${file.accessCount}.......`,
    ];
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div className="flex items-center space-x-2">
          <div className="p-1.5 rounded-lg bg-sky-500/10 border border-sky-500/30 text-sky-400">
            <Cpu className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200 flex items-center space-x-2">
              <span>Physical RAM Allocation Map & Hex Pointers</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-sky-400 border border-slate-700">
                {cachedNodes.length} / {capacity} Allocated
              </span>
            </h3>
            <p className="text-[11px] text-slate-400">
              Direct simulated 64-bit hexadecimal memory addresses and byte-level node structures
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-3 text-[11px] font-mono text-slate-400">
          <span className="flex items-center space-x-1">
            <span className="w-2.5 h-2.5 rounded bg-sky-500 inline-block" />
            <span>MRU (Head)</span>
          </span>
          <span className="flex items-center space-x-1">
            <span className="w-2.5 h-2.5 rounded bg-amber-500 inline-block" />
            <span>LRU (Tail)</span>
          </span>
          <span className="flex items-center space-x-1">
            <span className="w-2.5 h-2.5 rounded bg-slate-800 border border-slate-700 inline-block" />
            <span>Free Slot</span>
          </span>
        </div>
      </div>

      {/* Memory Slot Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-2">
        {slots.map((slot) => {
          const isSelected = selectedSlotIndex === slot.index;
          return (
            <button
              key={slot.hexAddress}
              onClick={() => {
                soundFx.playClick();
                setSelectedSlotIndex(slot.index);
              }}
              className={`p-2.5 rounded-lg border text-left transition-all cursor-pointer relative ${
                isSelected
                  ? "ring-2 ring-sky-400 border-sky-400 bg-slate-800"
                  : slot.isAllocated
                  ? slot.isHead
                    ? "bg-sky-950/40 border-sky-500/50 hover:border-sky-400"
                    : slot.isTail
                    ? "bg-amber-950/30 border-amber-500/50 hover:border-amber-400"
                    : "bg-slate-950 border-slate-800 hover:border-slate-700"
                  : "bg-slate-950/40 border-slate-900 border-dashed hover:border-slate-800 opacity-60"
              }`}
            >
              {/* Header: Slot and Tag */}
              <div className="flex items-center justify-between text-[10px] font-mono mb-1">
                <span className="text-slate-500">#{slot.index}</span>
                {slot.isHead && (
                  <span className="text-[9px] px-1 bg-sky-500 text-slate-950 font-bold rounded">
                    MRU
                  </span>
                )}
                {slot.isTail && !slot.isHead && (
                  <span className="text-[9px] px-1 bg-amber-500 text-slate-950 font-bold rounded">
                    LRU
                  </span>
                )}
                {!slot.isAllocated && (
                  <span className="text-[9px] text-slate-600">FREE</span>
                )}
              </div>

              {/* Memory Address */}
              <div className="font-mono text-[10px] text-sky-300 truncate">
                {slot.hexAddress}
              </div>

              {/* Node Payload */}
              <div className="mt-1.5">
                {slot.node ? (
                  <div>
                    <span className="text-xs font-bold text-slate-100 block truncate" title={slot.node.fileName}>
                      {slot.node.fileName}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {slot.node.fileSize}MB • {slot.node.fileType}
                    </span>
                  </div>
                ) : (
                  <span className="text-[11px] text-slate-600 italic block py-0.5">
                    Unmapped
                  </span>
                )}
              </div>
            </button>
          );
        })}
      </div>

      {/* Detailed Slot Inspection Panel */}
      {selectedSlot && (
        <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 mt-3">
          <div className="flex flex-col md:flex-row md:items-center justify-between pb-3 border-b border-slate-800 gap-2">
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xs font-bold text-slate-200">
                  Slot #{selectedSlot.index} Memory Inspection
                </span>
                <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-900 border border-slate-700 text-sky-400">
                  {selectedSlot.hexAddress}
                </span>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                  selectedSlot.isAllocated ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30" : "bg-slate-800 text-slate-400"
                }`}>
                  {selectedSlot.isAllocated ? "ALLOCATED (RAM ACTIVE)" : "FREE RAM BLOCK"}
                </span>
              </div>
            </div>

            {selectedSlot.node && (
              <div className="flex items-center space-x-2">
                {onPromoteNode && (
                  <button
                    onClick={() => onPromoteNode(selectedSlot.node!.fileId)}
                    className="px-2.5 py-1 bg-sky-500/10 hover:bg-sky-500/20 text-sky-300 border border-sky-500/30 rounded text-xs font-semibold transition cursor-pointer"
                  >
                    Promote to HEAD (0x7FFF0000)
                  </button>
                )}
                {onInspectNode && (
                  <button
                    onClick={() => onInspectNode(selectedSlot.node!)}
                    className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded text-xs font-semibold transition cursor-pointer flex items-center space-x-1"
                  >
                    <Binary className="w-3 h-3 text-sky-400" />
                    <span>View Payload</span>
                  </button>
                )}
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-3">
            {/* Pointers Metadata */}
            <div className="space-y-2 text-xs">
              <div className="bg-slate-900/80 p-3 rounded-lg border border-slate-800/80 space-y-1.5 font-mono">
                <div className="flex justify-between">
                  <span className="text-slate-500">Node Pointer (this):</span>
                  <span className="text-sky-300 font-bold">{selectedSlot.hexAddress}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Prev Pointer (node.prev):</span>
                  <span className="text-emerald-400 font-bold">{selectedSlot.prevAddress}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Next Pointer (node.next):</span>
                  <span className="text-amber-400 font-bold">{selectedSlot.nextAddress}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Access Hit Count:</span>
                  <span className="text-purple-400">{selectedSlot.node?.accessCount || 0} times</span>
                </div>
              </div>
            </div>

            {/* Simulated Hex View */}
            <div>
              <div className="bg-slate-900/80 p-3 rounded-lg border border-slate-800/80 font-mono text-[10px] space-y-1 text-slate-300 overflow-x-auto">
                <div className="text-slate-500 pb-1 border-b border-slate-800 flex justify-between">
                  <span>OFFSET: 00 01 02 03 04 05 06 07  08 09 0A 0B 0C 0D 0E 0F</span>
                  <span>ASCII DECODE</span>
                </div>
                {generateSimulatedHexDump(selectedSlot.node).map((line, i) => (
                  <div key={i} className="text-sky-200">
                    {line}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
