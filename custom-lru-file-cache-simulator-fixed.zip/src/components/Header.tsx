import React, { useState } from "react";
import {
  Cpu,
  Save,
  FolderOpen,
  Download,
  RotateCcw,
  Terminal,
  Search,
  Award,
  Volume2,
  VolumeX
} from "lucide-react";
import { soundFx } from "../audioSynth";

interface HeaderProps {
  onSave: () => void;
  onLoad: () => void;
  onExport: () => void;
  onReset: () => void;
  onOpenPythonGuide: () => void;
  onOpenCommandPalette: () => void;
  onOpenLabReport: () => void;
  onShowSplash?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onSave,
  onLoad,
  onExport,
  onReset,
  onOpenPythonGuide,
  onOpenCommandPalette,
  onOpenLabReport,
  onShowSplash
}) => {
  const [isMuted, setIsMuted] = useState(soundFx.isMuted);

  const handleToggleSound = () => {
    const muted = soundFx.toggleMute();
    setIsMuted(muted);
    if (!muted) {
      soundFx.playHit();
    }
  };

  return (
    <header className="h-14 border-b border-slate-800/90 bg-slate-900/95 backdrop-blur-md px-4 sm:px-5 flex items-center justify-between z-20 shrink-0 select-none">
      {/* Brand Identity & Architecture Spec */}
      <div className="flex items-center space-x-3">
        <button
          id="btn-header-logo"
          onClick={onShowSplash}
          className="w-9 h-9 rounded-xl bg-gradient-to-br from-sky-500/20 via-sky-600/10 to-indigo-600/20 border border-sky-500/30 flex items-center justify-center text-sky-400 shadow-sm shadow-sky-500/10 shrink-0 hover:border-sky-400/60 transition cursor-pointer"
          title="Replay 3-second startup logo animation"
        >
          <Cpu className="w-5 h-5" />
        </button>
        <div>
          <div className="flex items-center space-x-2">
            <h1 className="text-sm font-bold tracking-tight text-slate-100">
              LRU File Cache Simulator
            </h1>
            <span className="text-[10px] px-2 py-0.5 rounded-full font-mono font-semibold bg-sky-950/90 text-sky-300 border border-sky-800/60 shadow-xs">
              O(1) ENGINE
            </span>
          </div>
          <p className="text-[11px] text-slate-400 hidden sm:block">
            Polynomial Rolling Hash • Separate Chaining • Doubly Linked List
          </p>
        </div>
      </div>

      {/* Action Controls & Utilities */}
      <div className="flex items-center space-x-1.5 sm:space-x-2">
        {/* Sound FX Toggle */}
        <button
          id="btn-toggle-sound"
          onClick={handleToggleSound}
          className={`px-2.5 py-1.5 rounded-lg border text-xs transition cursor-pointer flex items-center space-x-1.5 ${
            isMuted
              ? "bg-slate-950/80 border-slate-800 text-slate-500 hover:text-slate-300"
              : "bg-sky-500/10 border-sky-500/40 text-sky-300 hover:bg-sky-500/20"
          }`}
          title={isMuted ? "Unmute hardware audio synth" : "Mute hardware audio synth"}
        >
          {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5 text-sky-400" />}
          <span className="text-[10px] font-mono hidden xl:inline">{isMuted ? "MUTED" : "AUDIO ON"}</span>
        </button>

        {/* Quick Search / Command Palette */}
        <button
          onClick={onOpenCommandPalette}
          className="flex items-center space-x-2 px-2.5 py-1.5 rounded-lg text-xs bg-slate-950/80 border border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700 transition cursor-pointer"
          title="Open Command Palette (Cmd+K)"
        >
          <Search className="w-3.5 h-3.5 text-sky-400" />
          <span className="hidden md:inline">Command</span>
          <kbd className="text-[10px] bg-slate-850 text-slate-300 px-1 py-0.5 rounded border border-slate-700 font-mono">
            ⌘K
          </kbd>
        </button>

        {/* Academic Lab Report */}
        <button
          onClick={onOpenLabReport}
          className="flex items-center space-x-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-sky-500/10 hover:bg-sky-500/20 text-sky-300 border border-sky-500/30 transition cursor-pointer"
          title="Generate Formal University Academic Lab Report"
        >
          <Award className="w-3.5 h-3.5 text-sky-400" />
          <span className="hidden lg:inline">Lab Report</span>
        </button>

        {/* Python Desktop App instructions */}
        <button
          id="btn-python-cli-guide"
          onClick={onOpenPythonGuide}
          className="flex items-center space-x-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/20 transition cursor-pointer"
          title="View Python Desktop GUI & Unit Tests"
        >
          <Terminal className="w-3.5 h-3.5" />
          <span className="hidden md:inline">Python GUI</span>
        </button>

        <div className="h-4 w-px bg-slate-800 hidden sm:block mx-1" />

        {/* Save / Load / JSON Dump */}
        <button
          id="btn-header-save"
          onClick={onSave}
          className="flex items-center space-x-1 px-2 py-1.5 rounded-lg text-xs font-medium bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700 transition cursor-pointer"
          title="Save Cache State to LocalStorage"
        >
          <Save className="w-3.5 h-3.5" />
          <span className="hidden lg:inline">Save</span>
        </button>

        <button
          id="btn-header-load"
          onClick={onLoad}
          className="flex items-center space-x-1 px-2 py-1.5 rounded-lg text-xs font-medium bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700 transition cursor-pointer"
          title="Load Cache State from LocalStorage"
        >
          <FolderOpen className="w-3.5 h-3.5" />
          <span className="hidden lg:inline">Load</span>
        </button>

        <button
          id="btn-header-export"
          onClick={onExport}
          className="flex items-center space-x-1 px-2 py-1.5 rounded-lg text-xs font-medium bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700 transition cursor-pointer"
          title="Export JSON telemetry state dump"
        >
          <Download className="w-3.5 h-3.5" />
          <span className="hidden lg:inline">JSON</span>
        </button>

        {/* Reset */}
        <button
          id="btn-header-reset"
          onClick={onReset}
          className="flex items-center space-x-1 px-2 py-1.5 rounded-lg text-xs font-medium bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 transition cursor-pointer"
          title="Reset Cache and Reinitialize Seed Storage"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Reset</span>
        </button>
      </div>
    </header>
  );
};
