import React, { useState } from "react";
import { FileNodeItem, StepTrace } from "../types";
import { Play, Pause, StepForward, ArrowRight, ArrowLeft, RefreshCw, FileText, Cpu, Zap, Eye, Trash2, Layers } from "lucide-react";
import { StepDebuggerModal } from "./StepDebuggerModal";
import { PhysicalRAMMap } from "./PhysicalRAMMap";

interface CacheMemoryTabProps {
  nodes: FileNodeItem[];
  capacity: number;
  onRunDemo: () => void;
  onPauseDemo: () => void;
  isDemoRunning: boolean;
  isDemoPaused: boolean;
  demoStepInfo: string;
  onRefresh: () => void;
  onGenerateStepTrace: (fileId: string) => StepTrace[];
  allStorageFiles: FileNodeItem[];
  onExecuteStepFinal: (fileId: string) => void;
  onSelectInspectFile?: (file: FileNodeItem) => void;
  onPromoteNode?: (fileId: string) => void;
  onEvictNode?: (fileId: string) => void;
}

export const CacheMemoryTab: React.FC<CacheMemoryTabProps> = ({
  nodes,
  capacity,
  onRunDemo,
  onPauseDemo,
  isDemoRunning,
  isDemoPaused,
  demoStepInfo,
  onRefresh,
  onGenerateStepTrace,
  allStorageFiles,
  onExecuteStepFinal,
  onSelectInspectFile,
  onPromoteNode,
  onEvictNode
}) => {
  const [isStepperOpen, setIsStepperOpen] = useState(false);
  const [stepperFileId, setStepperFileId] = useState<string>(allStorageFiles[0]?.fileId || "");
  const [steps, setSteps] = useState<StepTrace[]>([]);
  const [currentStepIdx, setCurrentStepIdx] = useState(0);

  // Selected node for pointer inspection
  const [inspectedNodeId, setInspectedNodeId] = useState<string | null>(nodes[0]?.fileId || null);

  const inspectedNode = nodes.find((n) => n.fileId === inspectedNodeId) || nodes[0] || null;
  const inspectedIdx = inspectedNode ? nodes.findIndex((n) => n.fileId === inspectedNode.fileId) : -1;

  // Generate simulated pointer addresses for academic memory visualization
  const getSimulatedAddress = (id: string) => {
    let num = 0;
    for (let i = 0; i < id.length; i++) num = (num * 37 + id.charCodeAt(i)) % 65536;
    return `0x7fff_${num.toString(16).padStart(4, "0").toUpperCase()}`;
  };

  const handleOpenStepper = () => {
    const fid = stepperFileId || allStorageFiles[0]?.fileId;
    if (fid) {
      const generated = onGenerateStepTrace(fid);
      setSteps(generated);
      setCurrentStepIdx(0);
      setIsStepperOpen(true);
    }
  };

  const handleStepperNext = () => {
    if (currentStepIdx < steps.length - 1) {
      const nextIdx = currentStepIdx + 1;
      setCurrentStepIdx(nextIdx);
      if (nextIdx === steps.length - 1) {
        onExecuteStepFinal(stepperFileId);
      }
    }
  };

  const handleStepperPrev = () => {
    if (currentStepIdx > 0) {
      setCurrentStepIdx(currentStepIdx - 1);
    }
  };

  return (
    <div className="space-y-5 p-6 max-w-7xl mx-auto">
      {/* Action Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-100 flex items-center space-x-2">
            <span>Cache Memory — Doubly Linked List & Pointer Architecture</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            HEAD pointer defines Most Recently Used (MRU). TAIL pointer defines Least Recently Used (LRU) victim.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          {!isDemoRunning ? (
            <button
              id="btn-run-demo"
              onClick={onRunDemo}
              className="flex items-center space-x-1.5 px-3 py-1.5 bg-sky-500 hover:bg-sky-400 text-slate-950 text-xs font-bold rounded-lg transition cursor-pointer shadow"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>▶ Run LRU Demo</span>
            </button>
          ) : (
            <button
              id="btn-pause-demo"
              onClick={onPauseDemo}
              className="flex items-center space-x-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-lg transition cursor-pointer"
            >
              {isDemoPaused ? (
                <>
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Resume Demo</span>
                </>
              ) : (
                <>
                  <Pause className="w-3.5 h-3.5 fill-current" />
                  <span>Pause Demo</span>
                </>
              )}
            </button>
          )}

          <button
            id="btn-step-by-step"
            onClick={handleOpenStepper}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold rounded-lg transition cursor-pointer"
          >
            <StepForward className="w-3.5 h-3.5 text-sky-400" />
            <span>Step-by-Step Mode</span>
          </button>

          <button
            id="btn-refresh-cache-view"
            onClick={onRefresh}
            className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 border border-slate-700 rounded-lg transition cursor-pointer"
            title="Refresh Display"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Demo Status Banner */}
      {demoStepInfo && (
        <div className="p-3 bg-sky-950/50 border border-sky-800/80 rounded-xl flex items-center justify-between text-xs text-sky-200 font-mono">
          <span className="flex items-center space-x-2">
            <span className="w-2 h-2 rounded-full bg-sky-400 animate-ping" />
            <span>{demoStepInfo}</span>
          </span>
          <span className="text-[11px] text-sky-400/80">Auto-Demonstration Active</span>
        </div>
      )}

      {/* Doubly Linked List Visual Stage */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 min-h-[360px] flex flex-col justify-center relative overflow-hidden">
        {/* Memory Header Bar */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800/80 text-xs">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1.5 text-slate-300 font-mono">
              <span className="w-2 h-2 rounded-full bg-sky-400" />
              <span className="font-bold">HEAD Pointer:</span>
              <span className="text-sky-400">
                {nodes[0] ? getSimulatedAddress(nodes[0].fileId) : "0x0000_0000 (NULL)"}
              </span>
            </div>
            <div className="flex items-center space-x-1.5 text-slate-300 font-mono">
              <span className="w-2 h-2 rounded-full bg-amber-400" />
              <span className="font-bold">TAIL Pointer:</span>
              <span className="text-amber-400">
                {nodes[nodes.length - 1]
                  ? getSimulatedAddress(nodes[nodes.length - 1].fileId)
                  : "0x0000_0000 (NULL)"}
              </span>
            </div>
          </div>

          <div className="text-slate-400 font-mono text-[11px]">
            Capacity: <span className="text-slate-200 font-bold">{nodes.length} / {capacity}</span> slots occupied
          </div>
        </div>

        {nodes.length === 0 ? (
          <div className="py-20 text-center space-y-3">
            <div className="w-12 h-12 mx-auto rounded-full bg-slate-800 flex items-center justify-center text-slate-400">
              <FileText className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-semibold text-slate-300">Cache Memory is Empty</h3>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              No files are currently stored in memory. Click "▶ Run LRU Demo" above or access a file from File Storage to load nodes into the Doubly Linked List.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto pb-4 pt-10">
            <div className="inline-flex items-center space-x-0 min-w-full px-6">
              {nodes.map((node, idx) => {
                const isHead = idx === 0;
                const isTail = idx === nodes.length - 1;
                const isSelected = inspectedNode?.fileId === node.fileId;

                return (
                  <React.Fragment key={node.fileId}>
                    {/* Node Card */}
                    <div className="relative flex flex-col items-center">
                      {/* MRU / LRU Header Indicators */}
                      {isHead && (
                        <div className="absolute -top-8 text-[10px] font-bold tracking-wider text-sky-400 uppercase bg-sky-950/90 px-2 py-0.5 rounded border border-sky-800 flex items-center space-x-1 shadow-sm">
                          <span>HEAD (MRU)</span>
                        </div>
                      )}
                      {isTail && (
                        <div className="absolute -top-8 text-[10px] font-bold tracking-wider text-amber-400 uppercase bg-amber-950/90 px-2 py-0.5 rounded border border-amber-800 flex items-center space-x-1 shadow-sm">
                          <span>TAIL (LRU)</span>
                        </div>
                      )}

                      <div
                        onClick={() => setInspectedNodeId(node.fileId)}
                        className={`w-52 bg-slate-950 rounded-xl p-3.5 border transition-all duration-300 shadow-xl cursor-pointer ${
                          isSelected
                            ? "ring-2 ring-sky-400 border-sky-400 shadow-sky-950"
                            : isHead
                            ? "border-sky-500/70 shadow-sky-950/50"
                            : isTail
                            ? "border-amber-500/70 shadow-amber-950/50"
                            : "border-slate-800 hover:border-slate-700"
                        }`}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-mono text-[11px] font-bold text-sky-400">
                            {node.fileId}
                          </span>
                          <span
                            className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                              isHead
                                ? "bg-sky-500/20 text-sky-300"
                                : isTail
                                ? "bg-amber-500/20 text-amber-300"
                                : "bg-slate-800 text-slate-400"
                            }`}
                          >
                            {isHead ? "MRU" : isTail ? "LRU" : `#${idx + 1}`}
                          </span>
                        </div>

                        <div className="font-bold text-slate-100 text-xs truncate mb-1" title={node.fileName}>
                          {node.fileName}
                        </div>

                        <div className="flex items-center justify-between text-[11px] text-slate-400 mb-2 font-mono">
                          <span className="px-1.5 py-0.5 bg-slate-900 rounded text-[10px]">
                            {node.fileType}
                          </span>
                          <span>{node.fileSize} MB</span>
                        </div>

                        {/* Memory pointer simulation */}
                        <div className="pt-2 border-t border-slate-900 flex items-center justify-between text-[10px] text-slate-400 font-mono">
                          <span>addr: {getSimulatedAddress(node.fileId).slice(0, 10)}</span>
                          <span className="text-sky-300">{node.accessCount} hits</span>
                        </div>
                      </div>

                      {/* Next to Evict warning badge */}
                      {isTail && (
                        <div className="absolute -bottom-6 text-[9px] font-bold text-rose-400/90 whitespace-nowrap font-mono">
                          ⚠ Next Eviction Victim
                        </div>
                      )}
                    </div>

                    {/* Bidirectional Pointer Link */}
                    {idx < nodes.length - 1 && (
                      <div className="px-2 flex flex-col items-center justify-center text-slate-400 space-y-1 select-none">
                        <div className="flex items-center space-x-1 text-sky-400 text-[10px] font-mono">
                          <span>next</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </div>
                        <div className="flex items-center space-x-1 text-purple-400 text-[10px] font-mono">
                          <ArrowLeft className="w-3.5 h-3.5" />
                          <span>prev</span>
                        </div>
                      </div>
                    )}
                  </React.Fragment>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Interactive Node Pointer Inspector (when a node is selected) */}
      {inspectedNode && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
            <div className="flex items-center space-x-2">
              <Cpu className="w-4 h-4 text-sky-400" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
                RAM Node Memory Inspector: <span className="text-sky-300 font-mono">{inspectedNode.fileName}</span> ({inspectedNode.fileId})
              </h3>
            </div>

            <div className="flex items-center space-x-2">
              {onPromoteNode && (
                <button
                  onClick={() => onPromoteNode(inspectedNode.fileId)}
                  className="flex items-center space-x-1 px-2.5 py-1 bg-sky-500/20 text-sky-300 border border-sky-500/40 rounded text-xs font-semibold hover:bg-sky-500/30 transition cursor-pointer"
                >
                  <Zap className="w-3 h-3" />
                  <span>Promote to HEAD (MRU)</span>
                </button>
              )}

              {onSelectInspectFile && (
                <button
                  onClick={() => onSelectInspectFile(inspectedNode)}
                  className="flex items-center space-x-1 px-2.5 py-1 bg-slate-800 text-slate-200 border border-slate-700 rounded text-xs font-semibold hover:bg-slate-700 transition cursor-pointer"
                >
                  <Eye className="w-3 h-3 text-sky-400" />
                  <span>View Payload</span>
                </button>
              )}

              {onEvictNode && (
                <button
                  onClick={() => onEvictNode(inspectedNode.fileId)}
                  className="flex items-center space-x-1 px-2.5 py-1 bg-rose-500/20 text-rose-300 border border-rose-500/40 rounded text-xs font-semibold hover:bg-rose-500/30 transition cursor-pointer"
                >
                  <Trash2 className="w-3 h-3" />
                  <span>Evict from RAM</span>
                </button>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-3 font-mono text-xs">
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
              <span className="text-[10px] text-slate-500 uppercase block">Node Address (this)</span>
              <div className="text-sky-400 font-bold mt-1">
                {getSimulatedAddress(inspectedNode.fileId)}
              </div>
            </div>

            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
              <span className="text-[10px] text-slate-500 uppercase block">Pointer: node.prev</span>
              <div className="text-purple-400 font-bold mt-1">
                {inspectedIdx > 0
                  ? `${getSimulatedAddress(nodes[inspectedIdx - 1].fileId)} (${nodes[inspectedIdx - 1].fileId})`
                  : "0x0000_0000 (HEAD / NULL)"}
              </div>
            </div>

            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
              <span className="text-[10px] text-slate-500 uppercase block">Pointer: node.next</span>
              <div className="text-sky-300 font-bold mt-1">
                {inspectedIdx < nodes.length - 1 && inspectedIdx !== -1
                  ? `${getSimulatedAddress(nodes[inspectedIdx + 1].fileId)} (${nodes[inspectedIdx + 1].fileId})`
                  : "0x0000_0000 (TAIL / NULL)"}
              </div>
            </div>

            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
              <span className="text-[10px] text-slate-500 uppercase block">Memory Cost & Hits</span>
              <div className="text-emerald-400 font-bold mt-1">
                {inspectedNode.fileSize} MB • {inspectedNode.accessCount} Cache Hits
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Hexadecimal Physical RAM Allocation Map */}
      <PhysicalRAMMap
        cachedNodes={nodes}
        capacity={capacity}
        onInspectNode={onSelectInspectFile}
        onPromoteNode={onPromoteNode}
      />

      {/* Advanced Interactive Step Debugger Modal */}
      <StepDebuggerModal
        isOpen={isStepperOpen}
        onClose={() => setIsStepperOpen(false)}
        traces={steps}
        fileName={allStorageFiles.find((f) => f.fileId === stepperFileId)?.fileName || stepperFileId}
        onExecuteFinal={() => onExecuteStepFinal(stepperFileId)}
      />
    </div>
  );
};
