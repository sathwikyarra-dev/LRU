import React from "react";
import { ActivityLogItem } from "../types";
import { Download, RefreshCw, Trash2, CheckCircle2, XCircle, AlertTriangle } from "lucide-react";

interface ActivityLogTabProps {
  logs: ActivityLogItem[];
  onClearLogs: () => void;
  onRefresh: () => void;
}

export const ActivityLogTab: React.FC<ActivityLogTabProps> = ({ logs, onClearLogs, onRefresh }) => {
  const exportCsv = () => {
    const headers = ["ID,Timestamp,Operation,FileName,Status,LatencyMs,Details"];
    const rows = logs.map(
      (l) => `${l.id},"${l.timestamp}","${l.operation}","${l.fileName}","${l.status}",${l.latencyMs},"${l.details.replace(/"/g, '""')}"`
    );
    const csvContent = "data:text/csv;charset=utf-8," + [headers, ...rows].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `lru_activity_log_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-5 p-6 max-w-7xl mx-auto">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-100 flex items-center space-x-2">
            <span>Live Activity & Audit Log</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Chronological audit log tracking every GET, MISS, INSERT, and EVICT operation with measured latency.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={exportCsv}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold transition cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={onClearLogs}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 rounded-lg text-xs font-semibold transition cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear Log</span>
          </button>

          <button
            onClick={onRefresh}
            className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 border border-slate-700 rounded-lg transition cursor-pointer"
            title="Refresh Log"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Log Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 font-mono text-[11px] uppercase border-b border-slate-800">
              <tr>
                <th className="p-3 w-12 text-center">#</th>
                <th className="p-3 w-24">Time</th>
                <th className="p-3 w-20">Op</th>
                <th className="p-3 w-48">File Name</th>
                <th className="p-3 w-28 text-center">Result Status</th>
                <th className="p-3 w-28 text-right">Latency</th>
                <th className="p-3">Operation Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {logs.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-slate-500 italic">
                    No operations logged yet. Access files or run workload generator to record activity.
                  </td>
                </tr>
              ) : (
                logs.slice().reverse().map((log) => {
                  const isHit = log.status === "HIT";
                  const isMiss = log.status === "MISS";
                  const isEvict = log.status === "EVICTED";

                  return (
                    <tr key={log.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="p-3 text-center text-slate-500">{log.id}</td>
                      <td className="p-3 text-slate-400">{log.timestamp}</td>
                      <td className="p-3 font-bold text-sky-400">{log.operation}</td>
                      <td className="p-3 font-sans font-semibold text-slate-200 truncate max-w-[180px]">
                        {log.fileName}
                      </td>
                      <td className="p-3 text-center">
                        <span
                          className={`inline-flex items-center space-x-1 px-2 py-0.5 rounded text-[10px] font-bold ${
                            isHit
                              ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
                              : isMiss
                              ? "bg-rose-500/10 text-rose-400 border border-rose-500/30"
                              : isEvict
                              ? "bg-amber-500/10 text-amber-400 border border-amber-500/30"
                              : "bg-slate-800 text-slate-300"
                          }`}
                        >
                          {isHit && <CheckCircle2 className="w-3 h-3" />}
                          {isMiss && <XCircle className="w-3 h-3" />}
                          {isEvict && <AlertTriangle className="w-3 h-3" />}
                          <span>{log.status}</span>
                        </span>
                      </td>
                      <td className="p-3 text-right font-bold text-sky-400">{log.latencyMs} ms</td>
                      <td className="p-3 font-sans text-slate-400 truncate max-w-[340px] text-[11px]">
                        {log.details}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
