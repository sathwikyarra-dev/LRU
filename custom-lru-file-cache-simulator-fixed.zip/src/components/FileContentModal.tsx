import React from "react";
import { FileNodeItem } from "../types";
import { X, FileCode, Database, FileText, Image, Film, FileArchive, Zap } from "lucide-react";

interface FileContentModalProps {
  file: FileNodeItem | null;
  isOpen: boolean;
  onClose: () => void;
  onAccess: (fileId: string) => void;
  isCached: boolean;
}

export const FileContentModal: React.FC<FileContentModalProps> = ({
  file,
  isOpen,
  onClose,
  onAccess,
  isCached
}) => {
  if (!isOpen || !file) return null;

  const renderContentPreview = () => {
    switch (file.fileType) {
      case "SQL":
        return (
          <div className="font-mono text-xs text-sky-300 bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-1 overflow-x-auto">
            <span className="text-slate-500">-- Academic Database Dump v2.4</span>
            <br />
            <span className="text-purple-400">CREATE TABLE</span> <span className="text-emerald-300">cache_registry</span> (
            <br />
            &nbsp;&nbsp;id <span className="text-amber-300">VARCHAR(32) PRIMARY KEY</span>,
            <br />
            &nbsp;&nbsp;filename <span className="text-amber-300">TEXT NOT NULL</span>,
            <br />
            &nbsp;&nbsp;bytes_size <span className="text-amber-300">BIGINT</span>,
            <br />
            &nbsp;&nbsp;mru_rank <span className="text-amber-300">INT DEFAULT 0</span>,
            <br />
            &nbsp;&nbsp;last_touch <span className="text-amber-300">TIMESTAMP DEFAULT CURRENT_TIMESTAMP</span>
            <br />
            );
            <br />
            <span className="text-purple-400">CREATE INDEX</span> idx_lru_rank <span className="text-purple-400">ON</span> cache_registry (mru_rank <span className="text-purple-400">DESC</span>);
          </div>
        );
      case "CSV":
        return (
          <div className="font-mono text-xs bg-slate-950 p-3 rounded-xl border border-slate-800 overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="p-1.5">record_id</th>
                  <th className="p-1.5">user_entropy</th>
                  <th className="p-1.5">latency_ms</th>
                  <th className="p-1.5">status</th>
                </tr>
              </thead>
              <tbody className="text-slate-300 divide-y divide-slate-900">
                <tr>
                  <td className="p-1.5">REC_1001</td>
                  <td className="p-1.5 font-bold text-sky-400">0.8492</td>
                  <td className="p-1.5 text-emerald-400">0.18ms</td>
                  <td className="p-1.5 text-emerald-300">HIT</td>
                </tr>
                <tr>
                  <td className="p-1.5">REC_1002</td>
                  <td className="p-1.5 font-bold text-sky-400">0.9104</td>
                  <td className="p-1.5 text-rose-400">2.41ms</td>
                  <td className="p-1.5 text-rose-300">MISS</td>
                </tr>
                <tr>
                  <td className="p-1.5">REC_1003</td>
                  <td className="p-1.5 font-bold text-sky-400">0.2415</td>
                  <td className="p-1.5 text-emerald-400">0.12ms</td>
                  <td className="p-1.5 text-emerald-300">HIT</td>
                </tr>
              </tbody>
            </table>
          </div>
        );
      case "PDF":
      case "DOCX":
        return (
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2 text-xs leading-relaxed text-slate-300">
            <div className="text-sm font-bold text-slate-100 flex items-center space-x-2">
              <FileText className="w-4 h-4 text-sky-400" />
              <span>Abstract & Theoretical Scope</span>
            </div>
            <p>
              This document synthesizes empirical cache replacement evaluation across operating system page caches,
              CPU cache hierarchies (L1/L2/L3), and distributed in-memory data grids. It examines how temporal locality
              minimizes average memory access latency using $O(1)$ Hash Map lookups combined with doubly linked list pointers.
            </p>
            <div className="text-[11px] text-slate-500 font-mono pt-1">
              Author: DSA Systems Lab • Status: Verified Peer Reviewed
            </div>
          </div>
        );
      case "JPG":
      case "PNG":
        return (
          <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 flex flex-col items-center justify-center space-y-2 text-slate-400">
            <div className="w-20 h-20 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center text-sky-400">
              <Image className="w-8 h-8" />
            </div>
            <span className="text-xs font-semibold text-slate-300">{file.fileName}</span>
            <span className="text-[11px] font-mono text-slate-500">Resolution: 3840 × 2160 (4K UHD) • Color: sRGB 10-bit</span>
          </div>
        );
      case "MP4":
        return (
          <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 flex flex-col items-center justify-center space-y-2 text-slate-400">
            <div className="w-20 h-20 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center text-purple-400">
              <Film className="w-8 h-8" />
            </div>
            <span className="text-xs font-semibold text-slate-300">{file.fileName}</span>
            <span className="text-[11px] font-mono text-slate-500">Codec: H.265 / HEVC • 60 FPS • Bitrate: 18 Mbps</span>
          </div>
        );
      default:
        return (
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 font-mono text-xs text-slate-300">
            [Raw Payload Content for {file.fileName}]
            <br />
            Size: {(file.fileSize * 1024).toFixed(0)} KB in secondary sector allocation.
          </div>
        );
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-lg bg-sky-500/10 border border-sky-500/30 flex items-center justify-center text-sky-400">
              <FileCode className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-100">{file.fileName}</h3>
              <p className="text-[11px] text-slate-400 font-mono">ID: {file.fileId} • {file.fileType}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-slate-200 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        {renderContentPreview()}

        {/* File Attributes Grid */}
        <div className="grid grid-cols-3 gap-2 bg-slate-950 p-3 rounded-xl border border-slate-800 text-center font-mono">
          <div>
            <span className="text-[9px] text-slate-500 uppercase block">Size</span>
            <span className="text-xs font-bold text-slate-200">{file.fileSize} MB</span>
          </div>
          <div>
            <span className="text-[9px] text-slate-500 uppercase block">Cache State</span>
            <span className={`text-xs font-bold ${isCached ? "text-emerald-400" : "text-slate-400"}`}>
              {isCached ? "IN RAM (MRU/LRU)" : "DISK ONLY"}
            </span>
          </div>
          <div>
            <span className="text-[9px] text-slate-500 uppercase block">Hits</span>
            <span className="text-xs font-bold text-sky-400">{file.accessCount}</span>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center justify-between pt-2">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
          >
            Close
          </button>
          <button
            onClick={() => {
              onAccess(file.fileId);
              onClose();
            }}
            className="flex items-center space-x-1.5 px-4 py-1.5 rounded-lg text-xs font-bold bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 transition cursor-pointer shadow"
          >
            <Zap className="w-3.5 h-3.5 fill-current" />
            <span>{isCached ? "Touch & Promote to MRU" : "Load into LRU Cache"}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
