import React from "react";
import { ToastItem } from "../types";
import { CheckCircle2, AlertTriangle, XCircle, Info, Flame, X } from "lucide-react";

interface ToastContainerProps {
  toasts: ToastItem[];
  onDismiss: (id: string) => void;
}

export const ToastContainer: React.FC<ToastContainerProps> = ({ toasts, onDismiss }) => {
  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col space-y-2 pointer-events-none max-w-sm w-full">
      {toasts.map((toast) => {
        let icon = <Info className="w-4 h-4 text-sky-400 shrink-0" />;
        let borderClass = "border-sky-500/40 bg-slate-900/95 text-sky-200";

        if (toast.type === "success") {
          icon = <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />;
          borderClass = "border-emerald-500/40 bg-slate-900/95 text-emerald-200";
        } else if (toast.type === "evict") {
          icon = <Flame className="w-4 h-4 text-amber-400 shrink-0" />;
          borderClass = "border-amber-500/40 bg-slate-900/95 text-amber-200";
        } else if (toast.type === "warning") {
          icon = <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />;
          borderClass = "border-amber-500/40 bg-slate-900/95 text-amber-200";
        } else if (toast.type === "error") {
          icon = <XCircle className="w-4 h-4 text-rose-400 shrink-0" />;
          borderClass = "border-rose-500/40 bg-slate-900/95 text-rose-200";
        }

        return (
          <div
            key={toast.id}
            className={`pointer-events-auto flex items-start justify-between p-3.5 rounded-xl border shadow-xl backdrop-blur-md transition-all duration-300 transform translate-y-0 opacity-100 ${borderClass}`}
          >
            <div className="flex items-start space-x-2.5">
              <div className="mt-0.5">{icon}</div>
              <div>
                <h4 className="text-xs font-bold text-slate-100">{toast.title}</h4>
                <p className="text-[11px] text-slate-300 mt-0.5 leading-tight">{toast.message}</p>
              </div>
            </div>
            <button
              onClick={() => onDismiss(toast.id)}
              className="text-slate-400 hover:text-slate-200 ml-2 p-0.5 rounded cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
