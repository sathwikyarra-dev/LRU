import React, { useState } from "react";
import { VIVA_QUESTIONS } from "../seedData";
import { Search, GraduationCap, ChevronDown, ChevronUp } from "lucide-react";

export const VivaModeTab: React.FC = () => {
  const [search, setSearch] = useState("");
  const [selectedCat, setSelectedCat] = useState("All");
  const [expandedIds, setExpandedIds] = useState<Set<number>>(new Set([1, 2, 3]));

  const toggleExpand = (id: number) => {
    const next = new Set(expandedIds);
    if (next.has(id)) {
      next.delete(id);
    } else {
      next.add(id);
    }
    setExpandedIds(next);
  };

  const expandAll = () => {
    setExpandedIds(new Set(VIVA_QUESTIONS.map((q) => q.id)));
  };

  const collapseAll = () => {
    setExpandedIds(new Set());
  };

  const filtered = VIVA_QUESTIONS.filter((q) => {
    if (selectedCat !== "All" && q.category !== selectedCat) return false;
    if (search.trim()) {
      const s = search.toLowerCase();
      return q.question.toLowerCase().includes(s) || q.answer.toLowerCase().includes(s);
    }
    return true;
  });

  return (
    <div className="space-y-5 p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-100 flex items-center space-x-2">
            <span>DSA Viva & Examination Mode</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            20 technical oral exam questions and detailed conceptual answers for LRU Caches and Data Structures.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={expandAll}
            className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs font-semibold"
          >
            Expand All
          </button>
          <button
            onClick={collapseAll}
            className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs font-semibold"
          >
            Collapse All
          </button>
        </div>
      </div>

      {/* Search & Category Filter */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-3 rounded-xl">
        <div className="flex items-center space-x-2 w-full sm:w-80 bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800">
          <Search className="w-3.5 h-3.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search questions or answers..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="bg-transparent text-xs text-slate-200 placeholder-slate-500 outline-none w-full"
          />
        </div>

        <div className="flex items-center space-x-2 text-xs text-slate-400">
          <span>Category:</span>
          {["All", "Architecture", "Hashing", "Linked List", "Complexity"].map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCat(cat)}
              className={`px-2.5 py-1 rounded text-xs transition cursor-pointer ${
                selectedCat === cat
                  ? "bg-sky-500 text-slate-950 font-bold"
                  : "bg-slate-800 text-slate-300 hover:bg-slate-700"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Questions Accordion List */}
      <div className="space-y-2.5">
        {filtered.map((item) => {
          const isExpanded = expandedIds.has(item.id);

          return (
            <div
              key={item.id}
              className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden transition-all"
            >
              <button
                onClick={() => toggleExpand(item.id)}
                className="w-full text-left p-4 flex items-center justify-between hover:bg-slate-800/40 transition-colors cursor-pointer"
              >
                <div className="flex items-center space-x-3 pr-4">
                  <span className="font-mono text-xs font-bold text-sky-400 shrink-0">
                    Q{item.id}
                  </span>
                  <span className="text-xs font-semibold text-slate-100">
                    {item.question}
                  </span>
                </div>

                <div className="flex items-center space-x-2 shrink-0">
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-800 text-slate-400 border border-slate-700/60">
                    {item.category}
                  </span>
                  {isExpanded ? (
                    <ChevronUp className="w-4 h-4 text-slate-400" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-slate-400" />
                  )}
                </div>
              </button>

              {isExpanded && (
                <div className="px-4 pb-4 pt-1 text-xs text-slate-300 leading-relaxed border-t border-slate-800/50 bg-slate-950/40">
                  <div className="p-3 bg-slate-900/90 rounded-lg border border-slate-800 text-slate-200">
                    <span className="font-semibold text-emerald-400 mr-2">Answer:</span>
                    {item.answer}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
