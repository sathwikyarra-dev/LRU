import React, { useState } from "react";
import { PolicySimulator } from "../policyEngines";
import { PolicyComparisonResult } from "../types";
import { Play, RotateCcw, StepForward, BarChart2, Layers, Cpu, CheckCircle2, XCircle, Flame, HelpCircle } from "lucide-react";

export const PolicyComparisonTab: React.FC = () => {
  const PRESET_WORKLOADS = [
    {
      name: "Zipfian 80/20 Locality (12 ops)",
      desc: "High temporal locality where 20% of files generate 80% of lookups",
      keys: ["F001", "F002", "F001", "F003", "F001", "F002", "F004", "F001", "F002", "F005", "F001", "F003"]
    },
    {
      name: "Cyclic Thrashing (N+1 Loop - 12 ops)",
      desc: "Accessing 5 distinct files in sequential cycles with cache capacity 4 — demonstrates LRU failure",
      keys: ["F001", "F002", "F003", "F004", "F005", "F001", "F002", "F003", "F004", "F005", "F001", "F002"]
    },
    {
      name: "Frequency Skew (LFU test - 14 ops)",
      desc: "Repeated access to F001 and F002 establishing high frequency before burst",
      keys: ["F001", "F001", "F001", "F002", "F002", "F003", "F004", "F005", "F006", "F001", "F002", "F007", "F001", "F002"]
    }
  ];

  const [capacity, setCapacity] = useState<number>(4);
  const [selectedPresetIdx, setSelectedPresetIdx] = useState<number>(0);
  const [customInput, setCustomInput] = useState<string>("");
  const [isCustom, setIsCustom] = useState<boolean>(false);

  // Simulation state
  const [simulator] = useState<PolicySimulator>(() => new PolicySimulator(4));
  const [history, setHistory] = useState<PolicyComparisonResult[]>([]);
  const [currentStepIdx, setCurrentStepIdx] = useState<number>(0);

  const activeSequence = isCustom
    ? customInput.split(",").map((s) => s.trim().toUpperCase()).filter((s) => s.length > 0)
    : PRESET_WORKLOADS[selectedPresetIdx].keys;

  const handleReset = (newCap = capacity) => {
    simulator.reset(newCap);
    setHistory([]);
    setCurrentStepIdx(0);
  };

  const handleStep = () => {
    if (currentStepIdx >= activeSequence.length) return;
    const nextKey = activeSequence[currentStepIdx];
    const res = simulator.step(nextKey, currentStepIdx + 1);
    setHistory((prev) => [...prev, res]);
    setCurrentStepIdx((curr) => curr + 1);
  };

  const handleRunAll = () => {
    simulator.reset(capacity);
    const results: PolicyComparisonResult[] = [];
    for (let i = 0; i < activeSequence.length; i++) {
      results.push(simulator.step(activeSequence[i], i + 1));
    }
    setHistory(results);
    setCurrentStepIdx(activeSequence.length);
  };

  const currentResult = history.length > 0 ? history[history.length - 1] : null;

  return (
    <div className="space-y-5 p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-100 flex items-center space-x-2">
            <span>Cache Replacement Policy Comparison Suite</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Empirical benchmark comparing LRU against FIFO, LFU, and Random replacement algorithms
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={handleStep}
            disabled={currentStepIdx >= activeSequence.length}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold disabled:opacity-40 transition cursor-pointer"
          >
            <StepForward className="w-3.5 h-3.5 text-sky-400" />
            <span>Step ({currentStepIdx}/{activeSequence.length})</span>
          </button>

          <button
            onClick={handleRunAll}
            className="flex items-center space-x-1.5 px-3.5 py-1.5 bg-gradient-to-r from-sky-500 to-cyan-500 hover:from-sky-400 hover:to-cyan-400 text-slate-950 font-bold rounded-lg text-xs transition cursor-pointer shadow"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>Run Complete Trace</span>
          </button>

          <button
            onClick={() => handleReset(capacity)}
            className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 border border-slate-700 rounded-lg transition cursor-pointer"
            title="Reset Simulation"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Workload Configuration Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          {/* Preset or Custom */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-semibold text-slate-400">Workload Pattern:</span>
            {PRESET_WORKLOADS.map((p, idx) => (
              <button
                key={p.name}
                onClick={() => {
                  setIsCustom(false);
                  setSelectedPresetIdx(idx);
                  handleReset(capacity);
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium transition cursor-pointer ${
                  !isCustom && selectedPresetIdx === idx
                    ? "bg-sky-500/20 text-sky-300 border border-sky-500/40"
                    : "bg-slate-950 text-slate-400 border border-slate-800 hover:text-slate-200"
                }`}
              >
                {p.name}
              </button>
            ))}

            <button
              onClick={() => {
                setIsCustom(true);
                if (!customInput) setCustomInput("F001, F002, F003, F001, F004, F005, F002");
                handleReset(capacity);
              }}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium transition cursor-pointer ${
                isCustom
                  ? "bg-sky-500/20 text-sky-300 border border-sky-500/40"
                  : "bg-slate-950 text-slate-400 border border-slate-800 hover:text-slate-200"
              }`}
            >
              Custom Sequence
            </button>
          </div>

          {/* Capacity Control */}
          <div className="flex items-center space-x-2">
            <span className="text-xs text-slate-400">Cache Slots:</span>
            <select
              value={capacity}
              onChange={(e) => {
                const newCap = Number(e.target.value);
                setCapacity(newCap);
                handleReset(newCap);
              }}
              className="bg-slate-800 text-xs text-slate-200 border border-slate-700 rounded px-2.5 py-1"
            >
              <option value={2}>2 Slots</option>
              <option value={3}>3 Slots</option>
              <option value={4}>4 Slots (Default)</option>
              <option value={5}>5 Slots</option>
              <option value={6}>6 Slots</option>
            </select>
          </div>
        </div>

        {isCustom && (
          <div className="pt-1">
            <input
              type="text"
              value={customInput}
              onChange={(e) => setCustomInput(e.target.value)}
              placeholder="Comma-separated file keys e.g. F001, F002, F003, F001"
              className="w-full bg-slate-950 text-xs text-sky-300 font-mono px-3 py-2 rounded-lg border border-slate-800 focus:border-sky-500 outline-none"
            />
          </div>
        )}

        {/* Sequence Tape View */}
        <div className="pt-2 border-t border-slate-800/80">
          <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 text-xs">
            <span className="text-[11px] text-slate-500 uppercase font-mono mr-2">Trace Tape:</span>
            {activeSequence.map((key, idx) => {
              const isPast = idx < currentStepIdx;
              const isCurrent = idx === currentStepIdx - 1;
              return (
                <span
                  key={idx}
                  className={`px-2 py-0.5 rounded font-mono text-[11px] whitespace-nowrap transition-all ${
                    isCurrent
                      ? "bg-sky-500 text-slate-950 font-bold ring-2 ring-sky-400/50"
                      : isPast
                      ? "bg-slate-800/60 text-slate-400"
                      : "bg-slate-950 text-slate-500 border border-slate-800/60"
                  }`}
                >
                  {key}
                </span>
              );
            })}
          </div>
        </div>
      </div>

      {/* Policy Comparison Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* LRU Policy Card */}
        <div className="bg-slate-900 border border-sky-500/40 rounded-xl p-4 flex flex-col justify-between shadow-lg relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-sky-500/5 rounded-full blur-xl pointer-events-none" />
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-sky-400 uppercase tracking-wider flex items-center space-x-1.5">
                <Cpu className="w-4 h-4" />
                <span>LRU (Least Recently Used)</span>
              </span>
              {currentResult && (
                <span
                  className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                    currentResult.policies.LRU.lastActionStatus === "HIT"
                      ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
                      : "bg-rose-500/20 text-rose-300 border border-rose-500/40"
                  }`}
                >
                  {currentResult.policies.LRU.lastActionStatus}
                </span>
              )}
            </div>

            <p className="text-[11px] text-slate-400 mb-3">
              Promotes hits to HEAD. Evicts the least recently accessed item at TAIL.
            </p>

            {/* Metrics */}
            <div className="grid grid-cols-3 gap-2 bg-slate-950 p-2.5 rounded-lg border border-slate-800 text-center font-mono mb-3">
              <div>
                <span className="text-[9px] text-slate-500 uppercase block">Hit Rate</span>
                <span className="text-sm font-bold text-sky-400">
                  {currentResult ? currentResult.policies.LRU.hitRate : 0}%
                </span>
              </div>
              <div>
                <span className="text-[9px] text-slate-500 uppercase block">Hits / Miss</span>
                <span className="text-xs font-semibold text-slate-300">
                  {currentResult ? currentResult.policies.LRU.hits : 0} / {currentResult ? currentResult.policies.LRU.misses : 0}
                </span>
              </div>
              <div>
                <span className="text-[9px] text-slate-500 uppercase block">Evictions</span>
                <span className="text-xs font-semibold text-amber-400">
                  {currentResult ? currentResult.policies.LRU.evictions : 0}
                </span>
              </div>
            </div>

            {/* Cached Slots */}
            <div className="space-y-1">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Cache Slots (MRU ➔ LRU):
              </span>
              <div className="flex flex-wrap gap-1.5 min-h-[32px] p-1 bg-slate-950 rounded-lg border border-slate-800/80">
                {currentResult && currentResult.policies.LRU.cache.length > 0 ? (
                  currentResult.policies.LRU.cache.map((key, i) => (
                    <span
                      key={i}
                      className={`px-2 py-0.5 rounded text-[11px] font-mono font-bold ${
                        i === 0 ? "bg-sky-500/20 text-sky-300 border border-sky-500/40" : "bg-slate-800 text-slate-300"
                      }`}
                    >
                      {key} {i === 0 ? "(MRU)" : i === currentResult.policies.LRU.cache.length - 1 ? "(LRU)" : ""}
                    </span>
                  ))
                ) : (
                  <span className="text-[11px] text-slate-600 italic px-2">Empty cache</span>
                )}
              </div>
            </div>
          </div>

          {currentResult?.policies.LRU.lastEvicted && (
            <div className="mt-3 text-[10px] text-amber-400/90 font-mono border-t border-slate-800/80 pt-2 flex items-center space-x-1">
              <Flame className="w-3 h-3 text-amber-400 shrink-0" />
              <span>Evicted victim: {currentResult.policies.LRU.lastEvicted}</span>
            </div>
          )}
        </div>

        {/* FIFO Policy Card */}
        <div className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl p-4 flex flex-col justify-between shadow-lg">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-purple-400 uppercase tracking-wider flex items-center space-x-1.5">
                <Layers className="w-4 h-4" />
                <span>FIFO (First-In First-Out)</span>
              </span>
              {currentResult && (
                <span
                  className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                    currentResult.policies.FIFO.lastActionStatus === "HIT"
                      ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
                      : "bg-rose-500/20 text-rose-300 border border-rose-500/40"
                  }`}
                >
                  {currentResult.policies.FIFO.lastActionStatus}
                </span>
              )}
            </div>

            <p className="text-[11px] text-slate-400 mb-3">
              Standard strict queue. Evicts the oldest loaded item regardless of recent hits.
            </p>

            {/* Metrics */}
            <div className="grid grid-cols-3 gap-2 bg-slate-950 p-2.5 rounded-lg border border-slate-800 text-center font-mono mb-3">
              <div>
                <span className="text-[9px] text-slate-500 uppercase block">Hit Rate</span>
                <span className="text-sm font-bold text-purple-400">
                  {currentResult ? currentResult.policies.FIFO.hitRate : 0}%
                </span>
              </div>
              <div>
                <span className="text-[9px] text-slate-500 uppercase block">Hits / Miss</span>
                <span className="text-xs font-semibold text-slate-300">
                  {currentResult ? currentResult.policies.FIFO.hits : 0} / {currentResult ? currentResult.policies.FIFO.misses : 0}
                </span>
              </div>
              <div>
                <span className="text-[9px] text-slate-500 uppercase block">Evictions</span>
                <span className="text-xs font-semibold text-amber-400">
                  {currentResult ? currentResult.policies.FIFO.evictions : 0}
                </span>
              </div>
            </div>

            {/* Cached Slots */}
            <div className="space-y-1">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Queue Order (Oldest ➔ Newest):
              </span>
              <div className="flex flex-wrap gap-1.5 min-h-[32px] p-1 bg-slate-950 rounded-lg border border-slate-800/80">
                {currentResult && currentResult.policies.FIFO.cache.length > 0 ? (
                  currentResult.policies.FIFO.cache.map((key, i) => (
                    <span
                      key={i}
                      className={`px-2 py-0.5 rounded text-[11px] font-mono font-bold ${
                        i === 0 ? "bg-amber-500/20 text-amber-300 border border-amber-500/40" : "bg-slate-800 text-slate-300"
                      }`}
                    >
                      {key} {i === 0 ? "(Oldest)" : ""}
                    </span>
                  ))
                ) : (
                  <span className="text-[11px] text-slate-600 italic px-2">Empty cache</span>
                )}
              </div>
            </div>
          </div>

          {currentResult?.policies.FIFO.lastEvicted && (
            <div className="mt-3 text-[10px] text-amber-400/90 font-mono border-t border-slate-800/80 pt-2 flex items-center space-x-1">
              <Flame className="w-3 h-3 text-amber-400 shrink-0" />
              <span>Evicted victim: {currentResult.policies.FIFO.lastEvicted}</span>
            </div>
          )}
        </div>

        {/* LFU Policy Card */}
        <div className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl p-4 flex flex-col justify-between shadow-lg">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center space-x-1.5">
                <BarChart2 className="w-4 h-4" />
                <span>LFU (Least Frequently Used)</span>
              </span>
              {currentResult && (
                <span
                  className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                    currentResult.policies.LFU.lastActionStatus === "HIT"
                      ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
                      : "bg-rose-500/20 text-rose-300 border border-rose-500/40"
                  }`}
                >
                  {currentResult.policies.LFU.lastActionStatus}
                </span>
              )}
            </div>

            <p className="text-[11px] text-slate-400 mb-3">
              Tracks access frequency counts. Evicts the file with the lowest count.
            </p>

            {/* Metrics */}
            <div className="grid grid-cols-3 gap-2 bg-slate-950 p-2.5 rounded-lg border border-slate-800 text-center font-mono mb-3">
              <div>
                <span className="text-[9px] text-slate-500 uppercase block">Hit Rate</span>
                <span className="text-sm font-bold text-emerald-400">
                  {currentResult ? currentResult.policies.LFU.hitRate : 0}%
                </span>
              </div>
              <div>
                <span className="text-[9px] text-slate-500 uppercase block">Hits / Miss</span>
                <span className="text-xs font-semibold text-slate-300">
                  {currentResult ? currentResult.policies.LFU.hits : 0} / {currentResult ? currentResult.policies.LFU.misses : 0}
                </span>
              </div>
              <div>
                <span className="text-[9px] text-slate-500 uppercase block">Evictions</span>
                <span className="text-xs font-semibold text-amber-400">
                  {currentResult ? currentResult.policies.LFU.evictions : 0}
                </span>
              </div>
            </div>

            {/* Cached Slots */}
            <div className="space-y-1">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Cache Slots with Frequency:
              </span>
              <div className="flex flex-wrap gap-1.5 min-h-[32px] p-1 bg-slate-950 rounded-lg border border-slate-800/80">
                {currentResult && currentResult.policies.LFU.cache.length > 0 ? (
                  currentResult.policies.LFU.cache.map((key, i) => (
                    <span
                      key={i}
                      className="px-2 py-0.5 rounded text-[11px] font-mono font-bold bg-slate-800 text-slate-300 flex items-center space-x-1"
                    >
                      <span>{key}</span>
                      <span className="text-[9px] text-emerald-400 font-normal">
                        ({currentResult.policies.LFU.frequencies?.[key] || 1}x)
                      </span>
                    </span>
                  ))
                ) : (
                  <span className="text-[11px] text-slate-600 italic px-2">Empty cache</span>
                )}
              </div>
            </div>
          </div>

          {currentResult?.policies.LFU.lastEvicted && (
            <div className="mt-3 text-[10px] text-amber-400/90 font-mono border-t border-slate-800/80 pt-2 flex items-center space-x-1">
              <Flame className="w-3 h-3 text-amber-400 shrink-0" />
              <span>Evicted victim: {currentResult.policies.LFU.lastEvicted}</span>
            </div>
          )}
        </div>

        {/* Random Policy Card */}
        <div className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl p-4 flex flex-col justify-between shadow-lg">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-rose-400 uppercase tracking-wider flex items-center space-x-1.5">
                <HelpCircle className="w-4 h-4" />
                <span>Random Replacement</span>
              </span>
              {currentResult && (
                <span
                  className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                    currentResult.policies.Random.lastActionStatus === "HIT"
                      ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
                      : "bg-rose-500/20 text-rose-300 border border-rose-500/40"
                  }`}
                >
                  {currentResult.policies.Random.lastActionStatus}
                </span>
              )}
            </div>

            <p className="text-[11px] text-slate-400 mb-3">
              Zero overhead replacement. Selects a uniform stochastic victim on miss.
            </p>

            {/* Metrics */}
            <div className="grid grid-cols-3 gap-2 bg-slate-950 p-2.5 rounded-lg border border-slate-800 text-center font-mono mb-3">
              <div>
                <span className="text-[9px] text-slate-500 uppercase block">Hit Rate</span>
                <span className="text-sm font-bold text-rose-400">
                  {currentResult ? currentResult.policies.Random.hitRate : 0}%
                </span>
              </div>
              <div>
                <span className="text-[9px] text-slate-500 uppercase block">Hits / Miss</span>
                <span className="text-xs font-semibold text-slate-300">
                  {currentResult ? currentResult.policies.Random.hits : 0} / {currentResult ? currentResult.policies.Random.misses : 0}
                </span>
              </div>
              <div>
                <span className="text-[9px] text-slate-500 uppercase block">Evictions</span>
                <span className="text-xs font-semibold text-amber-400">
                  {currentResult ? currentResult.policies.Random.evictions : 0}
                </span>
              </div>
            </div>

            {/* Cached Slots */}
            <div className="space-y-1">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Active Cached Slots:
              </span>
              <div className="flex flex-wrap gap-1.5 min-h-[32px] p-1 bg-slate-950 rounded-lg border border-slate-800/80">
                {currentResult && currentResult.policies.Random.cache.length > 0 ? (
                  currentResult.policies.Random.cache.map((key, i) => (
                    <span key={i} className="px-2 py-0.5 rounded text-[11px] font-mono font-bold bg-slate-800 text-slate-300">
                      {key}
                    </span>
                  ))
                ) : (
                  <span className="text-[11px] text-slate-600 italic px-2">Empty cache</span>
                )}
              </div>
            </div>
          </div>

          {currentResult?.policies.Random.lastEvicted && (
            <div className="mt-3 text-[10px] text-amber-400/90 font-mono border-t border-slate-800/80 pt-2 flex items-center space-x-1">
              <Flame className="w-3 h-3 text-amber-400 shrink-0" />
              <span>Evicted victim: {currentResult.policies.Random.lastEvicted}</span>
            </div>
          )}
        </div>
      </div>

      {/* Comparative Bar Visualization & Verdict */}
      {currentResult && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300">
            Comparative Efficiency Analysis (Step {currentResult.stepIndex} of {activeSequence.length})
          </h3>

          <div className="space-y-3">
            {[
              { name: "LRU", color: "bg-sky-500", rate: currentResult.policies.LRU.hitRate },
              { name: "FIFO", color: "bg-purple-500", rate: currentResult.policies.FIFO.hitRate },
              { name: "LFU", color: "bg-emerald-500", rate: currentResult.policies.LFU.hitRate },
              { name: "Random", color: "bg-rose-500", rate: currentResult.policies.Random.hitRate }
            ].map((item) => (
              <div key={item.name} className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="font-bold text-slate-200">{item.name}</span>
                  <span className="font-mono text-slate-400">{item.rate}% Hit Rate</span>
                </div>
                <div className="w-full bg-slate-950 h-2.5 rounded-full overflow-hidden border border-slate-800">
                  <div
                    className={`${item.color} h-full rounded-full transition-all duration-300`}
                    style={{ width: `${item.rate}%` }}
                  />
                </div>
              </div>
            ))}
          </div>

          <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800/80 text-xs text-slate-300 leading-relaxed">
            <span className="font-bold text-sky-400">DSA Academic Insight: </span>
            {selectedPresetIdx === 0 && !isCustom && (
              <span>
                Under <strong>Zipfian (80/20) temporal locality</strong>, LRU excels because repeatedly accessed items stay anchored at HEAD (MRU). FIFO performs worse because it discards high-frequency items simply due to insertion age.
              </span>
            )}
            {selectedPresetIdx === 1 && !isCustom && (
              <span>
                Under <strong>Cyclic Thrashing</strong> (accessing N+1 files cyclically with capacity N), LRU suffers an eviction on every single request, yielding a 0% hit rate! FIFO and LRU both degrade here, while frequency-based or randomized policies offer slightly better hit opportunities.
              </span>
            )}
            {selectedPresetIdx === 2 && !isCustom && (
              <span>
                Under <strong>Frequency Skew</strong>, LFU retains keys with accumulated hit counts (e.g. F001 and F002) even during bursts of transient items, protecting them from eviction.
              </span>
            )}
            {isCustom && (
              <span>
                Observe how the hit rates evolve across your custom access trace. Notice the relationship between cache capacity, temporal clustering, and eviction choice.
              </span>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
