import React, { useState } from "react";
import { CacheStatistics, ActivityLogItem, FileNodeItem } from "../types";
import { Zap, ArrowUpRight, ArrowDownRight, Layers, Database, Activity, CheckCircle2, Clock, Cpu, BarChart3 } from "lucide-react";
import { ArchitecturePipelineHUD } from "./ArchitecturePipelineHUD";
import { PhysicalRAMMap } from "./PhysicalRAMMap";

interface DashboardTabProps {
  stats: CacheStatistics;
  files: FileNodeItem[];
  recentLogs: ActivityLogItem[];
  cachedNodes: FileNodeItem[];
  onAccessFile: (fileId: string) => void;
  onApplyCapacity: (newCap: number) => void;
  onPolicyChange: (policy: "max_files" | "max_memory") => void;
  currentPolicy: "max_files" | "max_memory";
  onBurstAccess: (type: "zipf" | "thrash" | "random") => void;
  onPromoteNode?: (fileId: string) => void;
  onInspectNode?: (file: FileNodeItem) => void;
}

export const DashboardTab: React.FC<DashboardTabProps> = ({
  stats,
  files,
  recentLogs,
  cachedNodes,
  onAccessFile,
  onApplyCapacity,
  onPolicyChange,
  currentPolicy,
  onBurstAccess,
  onPromoteNode,
  onInspectNode
}) => {
  const [selectedFileId, setSelectedFileId] = useState<string>(files[0]?.fileId || "");
  const [capacityInput, setCapacityInput] = useState<number>(stats.capacity);

  const memoryPct = stats.maxMemoryMb > 0 ? Math.min(100, (stats.currentMemoryMb / stats.maxMemoryMb) * 100) : 0;
  const lastLog = recentLogs[recentLogs.length - 1];

  return (
    <div className="space-y-6 p-6 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <h2 className="text-xl font-bold text-slate-100">
              Cache Telemetry & Hardware Control Center
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-sky-950 text-sky-400 border border-sky-800">
              REAL-TIME MONITOR
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Microsecond telemetry, polynomial hashing pipeline, and physical RAM memory allocation
          </p>
        </div>

        {/* Quick Access bar */}
        <div className="flex items-center space-x-2 bg-slate-900 border border-slate-800 p-1.5 rounded-lg shadow-lg">
          <span className="text-xs text-slate-400 pl-2">Direct Query:</span>
          <select
            id="quick-access-select"
            value={selectedFileId}
            onChange={(e) => setSelectedFileId(e.target.value)}
            className="bg-slate-800 text-xs text-slate-200 border border-slate-700 rounded px-2.5 py-1 outline-none focus:border-sky-500 cursor-pointer"
          >
            {files.map((f) => (
              <option key={f.fileId} value={f.fileId}>
                {f.fileName} ({f.fileType}, {f.fileSize}MB)
              </option>
            ))}
          </select>
          <button
            id="btn-quick-access-submit"
            onClick={() => onAccessFile(selectedFileId)}
            className="flex items-center space-x-1 px-3 py-1 bg-sky-500 hover:bg-sky-400 text-slate-950 font-semibold rounded text-xs transition cursor-pointer"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Access File</span>
          </button>
        </div>
      </div>

      {/* Advanced Hardware Memory Pipeline HUD */}
      <ArchitecturePipelineHUD
        lastOperation={
          lastLog
            ? {
                fileName: lastLog.fileName,
                status: lastLog.status,
                latencyMs: lastLog.latencyMs
              }
            : undefined
        }
        onBurstAccess={onBurstAccess}
      />

      {/* Telemetry Metric Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
            Cache Capacity
          </span>
          <div className="flex items-baseline space-x-1.5 mt-1.5">
            <span className="text-xl font-bold text-sky-400 font-mono">
              {stats.currentSize}
            </span>
            <span className="text-xs text-slate-400 font-mono">/ {stats.capacity} files</span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full mt-2 overflow-hidden">
            <div
              className="bg-sky-500 h-full rounded-full transition-all"
              style={{ width: `${(stats.currentSize / Math.max(stats.capacity, 1)) * 100}%` }}
            />
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
            Cache Hits
          </span>
          <div className="flex items-center justify-between mt-1.5">
            <span className="text-xl font-bold text-emerald-400 font-mono">
              {stats.cacheHits}
            </span>
            <span className="p-1 rounded bg-emerald-500/10 text-emerald-400">
              <ArrowUpRight className="w-3.5 h-3.5" />
            </span>
          </div>
          <span className="text-[11px] text-slate-400 mt-2 block">O(1) memory retrievals</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
            Cache Misses
          </span>
          <div className="flex items-center justify-between mt-1.5">
            <span className="text-xl font-bold text-rose-400 font-mono">
              {stats.cacheMisses}
            </span>
            <span className="p-1 rounded bg-rose-500/10 text-rose-400">
              <ArrowDownRight className="w-3.5 h-3.5" />
            </span>
          </div>
          <span className="text-[11px] text-slate-400 mt-2 block">Loaded from disk</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
            Hit Rate Ratio
          </span>
          <div className="flex items-baseline space-x-1 mt-1.5">
            <span className="text-xl font-bold text-sky-400 font-mono">
              {stats.hitRatePct}%
            </span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full mt-2 overflow-hidden">
            <div
              className={`h-full rounded-full transition-all ${
                stats.hitRatePct > 70 ? "bg-emerald-500" : stats.hitRatePct > 40 ? "bg-amber-500" : "bg-sky-500"
              }`}
              style={{ width: `${Math.min(stats.hitRatePct, 100)}%` }}
            />
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
            LRU Evictions
          </span>
          <div className="flex items-center justify-between mt-1.5">
            <span className="text-xl font-bold text-amber-400 font-mono">
              {stats.evictions}
            </span>
            <span className="p-1 rounded bg-amber-500/10 text-amber-400 text-[10px] font-mono font-bold">
              LRU
            </span>
          </div>
          <span className="text-[11px] text-slate-400 mt-2 block">Tail victims dropped</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
            Total Requests
          </span>
          <div className="flex items-baseline space-x-1 mt-1.5">
            <span className="text-xl font-bold text-purple-400 font-mono">
              {stats.totalRequests}
            </span>
          </div>
          <span className="text-[11px] text-slate-400 mt-2 block">Total lookup calls</span>
        </div>
      </div>

      {/* Hexadecimal Physical RAM Allocation Map Component */}
      <PhysicalRAMMap
        cachedNodes={cachedNodes}
        capacity={stats.capacity}
        onInspectNode={onInspectNode}
        onPromoteNode={onPromoteNode}
      />

      {/* Control & Configuration Panel */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Capacity Slider & Input */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center space-x-2 text-sky-400 mb-2">
              <Layers className="w-4 h-4" />
              <h3 className="text-xs font-bold uppercase tracking-wider">Capacity Control</h3>
            </div>
            <p className="text-xs text-slate-400">
              Set max allowed files (1 - 20). Downsizing automatically evicts nodes from the LRU tail.
            </p>
          </div>

          <div className="mt-4 flex items-center space-x-3">
            <input
              type="range"
              min="1"
              max="20"
              value={capacityInput}
              onChange={(e) => setCapacityInput(Number(e.target.value))}
              className="w-full accent-sky-500 cursor-pointer"
            />
            <span className="font-mono text-sm font-bold text-sky-300 w-6 text-center">
              {capacityInput}
            </span>
            <button
              id="btn-apply-capacity"
              onClick={() => onApplyCapacity(capacityInput)}
              className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 border border-slate-700 rounded transition cursor-pointer shrink-0"
            >
              Apply
            </button>
          </div>
        </div>

        {/* Eviction Policy Radio */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center space-x-2 text-sky-400 mb-2">
              <Activity className="w-4 h-4" />
              <h3 className="text-xs font-bold uppercase tracking-wider">Eviction Policy</h3>
            </div>
            <p className="text-xs text-slate-400">
              Choose constraint threshold for triggering LRU tail eviction.
            </p>
          </div>

          <div className="mt-4 space-y-2">
            <label className="flex items-center space-x-2.5 text-xs text-slate-300 cursor-pointer">
              <input
                type="radio"
                name="eviction_policy"
                checked={currentPolicy === "max_files"}
                onChange={() => onPolicyChange("max_files")}
                className="accent-sky-500"
              />
              <span>Maximum Files Limit ({stats.capacity} files max)</span>
            </label>
            <label className="flex items-center space-x-2.5 text-xs text-slate-300 cursor-pointer">
              <input
                type="radio"
                name="eviction_policy"
                checked={currentPolicy === "max_memory"}
                onChange={() => onPolicyChange("max_memory")}
                className="accent-sky-500"
              />
              <span>Maximum Memory Limit ({stats.maxMemoryMb} MB max)</span>
            </label>
          </div>
        </div>

        {/* Memory Meter */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center space-x-2 text-sky-400 mb-2">
              <Database className="w-4 h-4" />
              <h3 className="text-xs font-bold uppercase tracking-wider">Memory Occupancy</h3>
            </div>
            <p className="text-xs text-slate-400">
              Simulated RAM usage of all active cached file payloads.
            </p>
          </div>

          <div className="mt-4">
            <div className="flex justify-between text-xs font-mono mb-1.5">
              <span className="text-slate-200 font-semibold">{stats.currentMemoryMb.toFixed(1)} MB</span>
              <span className="text-slate-400">{stats.maxMemoryMb.toFixed(1)} MB ({memoryPct.toFixed(1)}%)</span>
            </div>
            <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full transition-all ${
                  memoryPct > 85 ? "bg-rose-500" : memoryPct > 60 ? "bg-amber-500" : "bg-sky-500"
                }`}
                style={{ width: `${memoryPct}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activity Snapshot */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center space-x-2">
            <Clock className="w-4 h-4 text-sky-400" />
            <span>Recent Cache Operations</span>
          </h3>
          <span className="text-[11px] text-slate-400 font-mono">Last 5 events</span>
        </div>

        {recentLogs.length === 0 ? (
          <div className="py-6 text-center text-xs text-slate-400 italic">
            No cache operations recorded yet. Access a file above to begin.
          </div>
        ) : (
          <div className="space-y-1.5">
            {recentLogs.slice(-5).reverse().map((log) => {
              const isHit = log.status === "HIT";
              const isMiss = log.status === "MISS";
              return (
                <div
                  key={log.id}
                  className="flex items-center justify-between px-3 py-2 bg-slate-950/60 border border-slate-800/80 rounded-lg text-xs"
                >
                  <div className="flex items-center space-x-3">
                    <span className="font-mono text-slate-400 text-[11px]">{log.timestamp}</span>
                    <span className="font-semibold text-slate-200">{log.fileName}</span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        isHit
                          ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
                          : isMiss
                          ? "bg-rose-500/10 text-rose-400 border border-rose-500/30"
                          : "bg-amber-500/10 text-amber-400 border border-amber-500/30"
                      }`}
                    >
                      {log.status}
                    </span>
                  </div>
                  <div className="flex items-center space-x-4">
                    <span className="text-slate-400 text-[11px] hidden sm:inline">{log.details}</span>
                    <span className="font-mono text-sky-400 text-[11px]">{log.latencyMs} ms</span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
