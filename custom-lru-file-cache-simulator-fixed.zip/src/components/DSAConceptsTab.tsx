import React from "react";
import { BookOpen, Check, Layers, GitFork, ArrowLeftRight, Terminal } from "lucide-react";

export const DSAConceptsTab: React.FC = () => {
  const concepts = [
    {
      title: "1. Custom Hashing & Rolling Hash",
      color: "border-sky-500/40 text-sky-400",
      icon: <Layers className="w-5 h-5" />,
      desc: "A custom hash function maps arbitrary file ID strings (e.g. 'report.pdf') into integer bucket indices. We use the prime polynomial base 31 algorithm: hash = (hash * 31 + charCode) % capacity. Using prime 31 ensures avalanche properties, scattering sequential keys and avoiding clustering without relying on built-in hash tables."
    },
    {
      title: "2. Collision Resolution: Separate Chaining",
      color: "border-purple-500/40 text-purple-400",
      icon: <GitFork className="w-5 h-5" />,
      desc: "By the Pigeonhole Principle, infinite strings map to a finite bucket array. In Separate Chaining, every bucket slot holds the head of a linked chain of entries. If two keys hash to bucket [3], the new entry is prepended to bucket [3]'s linked chain. Average lookup remains O(1 + α) where α is the load factor."
    },
    {
      title: "3. Doubly Linked List for O(1) Reordering",
      color: "border-emerald-500/40 text-emerald-400",
      icon: <ArrowLeftRight className="w-5 h-5" />,
      desc: "Standard arrays require shifting all trailing elements left when an item is deleted or moved, taking O(N) time. In a Doubly Linked List, each node holds explicit pointers to both its predecessor (prev) and successor (next). Once a node is located, unlinking it and attaching it to the HEAD (MRU) requires only 4 pointer rewirings in strictly O(1) time."
    },
    {
      title: "4. Synergistic LRU Architecture",
      color: "border-amber-500/40 text-amber-400",
      icon: <BookOpen className="w-5 h-5" />,
      desc: "The HashMap provides constant-time O(1) node lookup by file ID. The Doubly Linked List provides constant-time O(1) priority maintenance and tail eviction. Working together, GET and PUT operations execute in constant O(1) time without compromise."
    }
  ];

  const tableData = [
    { op: "HashMap GET (Search)", avg: "O(1)", worst: "O(N)", space: "O(1)", note: "Navigates bucket chain" },
    { op: "HashMap PUT (Insert)", avg: "O(1)", worst: "O(N)", space: "O(1)", note: "Inserts at head of chain" },
    { op: "LRU Cache GET", avg: "O(1)", worst: "O(N)", space: "O(1)", note: "Lookup + DLL move to front" },
    { op: "LRU Cache PUT", avg: "O(1)", worst: "O(N)", space: "O(1)", note: "Evict tail (if full) + insert head" },
    { op: "Move Node to MRU", avg: "O(1)", worst: "O(1)", space: "O(1)", note: "Pointer rewiring in DLL" },
    { op: "Remove LRU Tail", avg: "O(1)", worst: "O(1)", space: "O(1)", note: "Unlink tail node in DLL" },
    { op: "Total Cache Space", avg: "O(C)", worst: "O(C)", space: "O(C)", note: "Stores C nodes in DLL & Hash Buckets" },
  ];

  return (
    <div className="space-y-6 p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold text-slate-100 flex items-center space-x-2">
          <span>Data Structures & Algorithms: The LRU Architecture</span>
        </h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Academic breakdown of HashMaps, Doubly Linked Lists, and Asymptotic Complexity
        </p>
      </div>

      {/* Conceptual Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {concepts.map((c, i) => (
          <div
            key={i}
            className={`bg-slate-900 border ${c.color.split(" ")[0]} rounded-xl p-5 space-y-2.5 shadow-sm`}
          >
            <div className="flex items-center space-x-2.5">
              <span className={c.color.split(" ")[1]}>{c.icon}</span>
              <h3 className="text-sm font-bold text-slate-100">{c.title}</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              {c.desc}
            </p>
          </div>
        ))}
      </div>

      {/* Complexity Reference Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
          Asymptotic Complexity Analysis Reference
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 font-mono text-[11px] uppercase border-b border-slate-800">
              <tr>
                <th className="p-3">Operation</th>
                <th className="p-3">Average Time</th>
                <th className="p-3">Worst Time</th>
                <th className="p-3">Auxiliary Space</th>
                <th className="p-3">Algorithm Mechanics</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {tableData.map((row, idx) => (
                <tr key={idx} className="hover:bg-slate-800/40 transition-colors">
                  <td className="p-3 font-semibold text-slate-100 font-sans">{row.op}</td>
                  <td className="p-3 text-emerald-400 font-bold">{row.avg}</td>
                  <td className="p-3 text-rose-400">{row.worst}</td>
                  <td className="p-3 text-sky-400">{row.space}</td>
                  <td className="p-3 text-slate-400 font-sans text-[11px]">{row.note}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
