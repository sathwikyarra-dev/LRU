import React, { useState, useMemo, useRef, useEffect } from "react";
import { BucketItem, FileNodeItem } from "../types";
import {
  Hash,
  AlertTriangle,
  CheckCircle2,
  ArrowRight,
  Sliders,
  Sparkles,
  RefreshCw,
  Plus,
  Flame,
  ShieldAlert,
  HelpCircle,
  Eye,
  Layers,
  Cpu
} from "lucide-react";
import { soundFx } from "../audioSynth";
import { HashAlgorithmId, HASH_ALGORITHMS, ALGORITHM_LIST } from "../hashAlgorithms";

interface DynamicHashMappingVisualizerProps {
  realCapacity: number;
  realBuckets: BucketItem[];
  allFiles?: FileNodeItem[];
  algorithm?: HashAlgorithmId;
  onAlgorithmChange?: (algo: HashAlgorithmId) => void;
}

interface SimulatedKey {
  id: string;
  name: string;
  type: string;
}

const PRESET_KEYS: SimulatedKey[] = [
  { id: "F001", name: "report.pdf", type: "PDF" },
  { id: "F002", name: "presentation.pptx", type: "PPTX" },
  { id: "F003", name: "dataset.csv", type: "CSV" },
  { id: "F004", name: "video.mp4", type: "MP4" },
  { id: "F005", name: "archive.zip", type: "ZIP" },
  { id: "F006", name: "audio.wav", type: "WAV" },
  { id: "F007", name: "kernel.sys", type: "SYS" },
  { id: "F008", name: "styles.css", type: "CSS" },
  { id: "F009", name: "app.ts", type: "TS" },
  { id: "F010", name: "config.json", type: "JSON" },
  { id: "F011", name: "schema.sql", type: "SQL" },
  { id: "F012", name: "vector.svg", type: "SVG" },
  { id: "F013", name: "backup.tar", type: "TAR" },
  { id: "F014", name: "index.html", type: "HTML" },
  { id: "F015", name: "readme.md", type: "MD" },
  { id: "F016", name: "texture.png", type: "PNG" }
];

export const DynamicHashMappingVisualizer: React.FC<DynamicHashMappingVisualizerProps> = ({
  realCapacity,
  realBuckets,
  allFiles = [],
  algorithm = "polynomial",
  onAlgorithmChange
}) => {
  // Mode: "live" (tracks active LRU cache) or "stress" (allows load factor scaling)
  const [mode, setMode] = useState<"live" | "stress">("live");

  // Selected hash algorithm
  const [selectedAlgo, setSelectedAlgo] = useState<HashAlgorithmId>(algorithm);

  useEffect(() => {
    if (algorithm && algorithm !== selectedAlgo) {
      setSelectedAlgo(algorithm);
    }
  }, [algorithm]);

  const handleAlgoSelect = (id: HashAlgorithmId) => {
    setSelectedAlgo(id);
    onAlgorithmChange?.(id);
    soundFx.playClick();
  };

  // Stress simulator settings
  const [simCapacity, setSimCapacity] = useState<number>(8);
  const [keyCount, setKeyCount] = useState<number>(6);
  const [customKeyInput, setCustomKeyInput] = useState<string>("");
  const [hoveredKey, setHoveredKey] = useState<string | null>(null);
  const [hoveredBucket, setHoveredBucket] = useState<number | null>(null);

  // Dynamic SVG connection coordinates
  const containerRef = useRef<HTMLDivElement>(null);
  const [lineCoords, setLineCoords] = useState<
    {
      keyId: string;
      bucketIdx: number;
      x1: number;
      y1: number;
      x2: number;
      y2: number;
      isCollision: boolean;
    }[]
  >([]);

  // Hash helper using selected algorithm
  const hashKey = (key: string, cap: number): number => {
    const algoDef = HASH_ALGORITHMS[selectedAlgo] || HASH_ALGORITHMS.polynomial;
    return algoDef.computeIndex(key, cap);
  };

  // Determine active keys based on mode
  const activeKeys: { key: string; label: string; type: string }[] = useMemo(() => {
    if (mode === "live") {
      // Collect all keys present across real buckets
      const items: { key: string; label: string; type: string }[] = [];
      realBuckets.forEach((b) => {
        b.entries.forEach((e) => {
          items.push({ key: e.fileId, label: e.fileName, type: e.fileType });
        });
      });
      // Fallback to sample if empty
      if (items.length === 0) {
        return PRESET_KEYS.slice(0, 4).map((k) => ({
          key: k.id,
          label: k.name,
          type: k.type
        }));
      }
      return items;
    } else {
      return PRESET_KEYS.slice(0, keyCount).map((k) => ({
        key: k.id,
        label: k.name,
        type: k.type
      }));
    }
  }, [mode, realBuckets, keyCount]);

  const activeCapacity = mode === "live" ? realCapacity : simCapacity;

  // Compute bucket distribution & collisions
  const { bucketMappings, collisionCount, loadFactor, collidingBucketIndices } = useMemo(() => {
    const buckets: {
      index: number;
      items: { key: string; label: string; type: string }[];
    }[] = Array.from({ length: activeCapacity }, (_, i) => ({
      index: i,
      items: []
    }));

    activeKeys.forEach((item) => {
      const idx = hashKey(item.key, activeCapacity);
      if (buckets[idx]) {
        buckets[idx].items.push(item);
      }
    });

    let collisions = 0;
    const collidingSet = new Set<number>();

    buckets.forEach((b) => {
      if (b.items.length > 1) {
        collisions += b.items.length - 1;
        collidingSet.add(b.index);
      }
    });

    const lf = Number((activeKeys.length / activeCapacity).toFixed(2));

    return {
      bucketMappings: buckets,
      collisionCount: collisions,
      loadFactor: lf,
      collidingBucketIndices: collidingSet
    };
  }, [activeKeys, activeCapacity, selectedAlgo]);

  // Benchmark comparison across all algorithms on the current active keys and capacity
  const algoComparison = useMemo(() => {
    const result: Record<
      HashAlgorithmId,
      { collisions: number; occupiedBuckets: number; maxChain: number }
    > = {} as any;
    ALGORITHM_LIST.forEach((algo) => {
      const counts = new Array(activeCapacity).fill(0);
      activeKeys.forEach((item) => {
        const idx = algo.computeIndex(item.key, activeCapacity);
        counts[idx] = (counts[idx] || 0) + 1;
      });
      let col = 0;
      let occupied = 0;
      let maxChain = 0;
      counts.forEach((c) => {
        if (c > 0) occupied++;
        if (c > 1) col += c - 1;
        if (c > maxChain) maxChain = c;
      });
      result[algo.id] = { collisions: col, occupiedBuckets: occupied, maxChain };
    });
    return result;
  }, [activeKeys, activeCapacity]);

  // Recalculate SVG connector positions whenever layout changes
  const updateConnectorCoords = () => {
    if (!containerRef.current) return;
    const containerRect = containerRef.current.getBoundingClientRect();

    const newCoords: {
      keyId: string;
      bucketIdx: number;
      x1: number;
      y1: number;
      x2: number;
      y2: number;
      isCollision: boolean;
    }[] = [];

    activeKeys.forEach((k) => {
      const keyElem = containerRef.current?.querySelector(`[data-key-id="${k.key}"]`);
      const targetBucketIdx = hashKey(k.key, activeCapacity);
      const bucketElem = containerRef.current?.querySelector(`[data-bucket-idx="${targetBucketIdx}"]`);

      if (keyElem && bucketElem) {
        const keyRect = keyElem.getBoundingClientRect();
        const bucketRect = bucketElem.getBoundingClientRect();

        const isCollision = collidingBucketIndices.has(targetBucketIdx);

        newCoords.push({
          keyId: k.key,
          bucketIdx: targetBucketIdx,
          x1: keyRect.right - containerRect.left,
          y1: keyRect.top + keyRect.height / 2 - containerRect.top,
          x2: bucketRect.left - containerRect.left,
          y2: bucketRect.top + bucketRect.height / 2 - containerRect.top,
          isCollision
        });
      }
    });

    setLineCoords(newCoords);
  };

  useEffect(() => {
    updateConnectorCoords();
    const handleResize = () => updateConnectorCoords();
    window.addEventListener("resize", handleResize);
    // Slight delay to allow DOM render to stabilize
    const t = setTimeout(updateConnectorCoords, 100);

    return () => {
      window.removeEventListener("resize", handleResize);
      clearTimeout(t);
    };
  }, [activeKeys, activeCapacity, collidingBucketIndices]);

  // Play audio alert when load factor crosses critical threshold
  useEffect(() => {
    if (loadFactor >= 0.75 && collisionCount > 0) {
      soundFx.playEviction();
    }
  }, [loadFactor, collisionCount]);

  // Handle Load Factor quick presets
  const handleApplyPreset = (keys: number, cap: number) => {
    setMode("stress");
    setKeyCount(keys);
    setSimCapacity(cap);
    soundFx.playClick();
  };

  // Rehash simulator: double capacity to alleviate collisions
  const handleRehash = () => {
    soundFx.playHit();
    setSimCapacity((prev) => Math.min(32, prev * 2));
  };

  // Load Factor status tier
  const getLoadFactorTier = (lf: number) => {
    if (lf < 0.5) {
      return {
        label: "OPTIMAL O(1)",
        color: "text-emerald-400 bg-emerald-500/10 border-emerald-500/30",
        description: "Low collision probability. Direct O(1) time complexity."
      };
    }
    if (lf < 0.75) {
      return {
        label: "BALANCED",
        color: "text-sky-400 bg-sky-500/10 border-sky-500/30",
        description: "Healthy memory utilization with minimal separate chaining."
      };
    }
    if (lf < 1.0) {
      return {
        label: "HIGH LOAD (THRESHOLD)",
        color: "text-amber-400 bg-amber-500/10 border-amber-500/30",
        description: "Collisions increasing! Rehash recommended before performance drops."
      };
    }
    return {
      label: "OVERLOADED (CRITICAL)",
      color: "text-rose-400 bg-rose-500/20 border-rose-500/50 animate-pulse",
      description: "Severe clustering! Lookup degrades toward O(N). Collisions highlighted in RED!"
    };
  };

  const statusTier = getLoadFactorTier(loadFactor);

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-5 shadow-xl">
      {/* Top Banner & Mode Switcher */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800/80 pb-4">
        <div>
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-lg bg-sky-500/10 border border-sky-500/30 flex items-center justify-center text-sky-400">
              <Hash className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-100 flex items-center space-x-2">
                <span>Dynamic Key &rarr; Bucket Mapping Flow</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-sky-950 text-sky-300 border border-sky-500/40">
                  {HASH_ALGORITHMS[selectedAlgo]?.shortName || "Custom"}
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Visualizes key hashing into bucket slots. When load factor (α) increases or algorithm is weak, colliding buckets light up in{" "}
                <span className="text-rose-400 font-semibold">RED</span>.
              </p>
            </div>
          </div>
        </div>

        {/* Mode Selector */}
        <div className="flex items-center space-x-2">
          <button
            onClick={() => {
              setMode("live");
              soundFx.playClick();
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer flex items-center space-x-1.5 ${
              mode === "live"
                ? "bg-sky-500 text-slate-950 font-bold shadow-sm"
                : "bg-slate-800/80 text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-700"
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Live Cache State</span>
          </button>

          <button
            onClick={() => {
              setMode("stress");
              soundFx.playClick();
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer flex items-center space-x-1.5 ${
              mode === "stress"
                ? "bg-rose-500 text-white font-bold shadow-sm shadow-rose-950"
                : "bg-slate-800/80 text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-700"
            }`}
          >
            <Flame className="w-3.5 h-3.5" />
            <span>Load Factor Stress Lab</span>
          </button>
        </div>
      </div>

      {/* Algorithm Selector & Live Collision Rate Comparison Bar */}
      <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3.5 space-y-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-2.5">
          <div className="flex items-center space-x-2">
            <Cpu className="w-4 h-4 text-sky-400" />
            <span className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Hash Function Algorithm:
            </span>
            <span className="text-[11px] text-slate-400 hidden sm:inline">
              (Observe collision rate variations in real-time)
            </span>
          </div>

          <div className="flex items-center space-x-2 text-xs">
            <span className="text-slate-400">Current Collision Rate:</span>
            <span
              className={`font-mono font-bold px-2 py-0.5 rounded border ${
                collisionCount > 0
                  ? "bg-rose-950/60 text-rose-400 border-rose-500/50"
                  : "bg-emerald-950/40 text-emerald-400 border-emerald-500/30"
              }`}
            >
              {collisionCount} collision{collisionCount === 1 ? "" : "s"} (
              {((collisionCount / Math.max(1, activeKeys.length)) * 100).toFixed(0)}%)
            </span>
          </div>
        </div>

        {/* Algorithm Selection Buttons */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
          {ALGORITHM_LIST.map((algo) => {
            const isSelected = algo.id === selectedAlgo;
            const stats = algoComparison[algo.id] || { collisions: 0, occupiedBuckets: 0 };
            const hasCollisions = stats.collisions > 0;

            return (
              <button
                key={algo.id}
                onClick={() => handleAlgoSelect(algo.id)}
                className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? "bg-sky-950/50 border-sky-500 ring-2 ring-sky-500/50 shadow-md"
                    : "bg-slate-900/90 border-slate-800 hover:border-slate-700 hover:bg-slate-850"
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span
                    className={`text-xs font-bold font-mono ${
                      isSelected ? "text-sky-300" : "text-slate-200"
                    }`}
                  >
                    {algo.shortName}
                  </span>
                  <span
                    className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold border ${
                      hasCollisions
                        ? "bg-rose-950/80 text-rose-400 border-rose-500/60"
                        : "bg-emerald-950/60 text-emerald-400 border-emerald-500/40"
                    }`}
                  >
                    {stats.collisions} {stats.collisions === 1 ? "col" : "cols"}
                  </span>
                </div>

                <div className="text-[10px] font-mono text-slate-400 truncate mb-1">
                  {algo.formula}
                </div>

                <div className="flex items-center justify-between pt-1 border-t border-slate-800/60 text-[9px]">
                  <span className={algo.qualityColor}>{algo.quality}</span>
                  <span className="text-slate-500 font-mono">
                    {stats.occupiedBuckets}/{activeCapacity} slots
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Stress Test & Load Factor Controller Controls (if in Stress Mode or preview) */}
      {mode === "stress" && (
        <div className="bg-slate-950 border border-slate-800/90 rounded-xl p-4 space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <span className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center space-x-1.5">
              <Sliders className="w-3.5 h-3.5 text-sky-400" />
              <span>Interactive Load Factor Tuning</span>
            </span>

            {/* Quick Presets */}
            <div className="flex items-center space-x-1.5 text-[11px] font-mono">
              <span className="text-slate-500 mr-1 hidden sm:inline">Presets:</span>
              <button
                onClick={() => handleApplyPreset(4, 12)}
                className="px-2 py-0.5 rounded bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 transition cursor-pointer"
              >
                Low (α=0.33)
              </button>
              <button
                onClick={() => handleApplyPreset(6, 8)}
                className="px-2 py-0.5 rounded bg-sky-500/10 hover:bg-sky-500/20 text-sky-400 border border-sky-500/30 transition cursor-pointer"
              >
                Normal (α=0.75)
              </button>
              <button
                onClick={() => handleApplyPreset(10, 8)}
                className="px-2 py-0.5 rounded bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 transition cursor-pointer"
              >
                High (α=1.25)
              </button>
              <button
                onClick={() => handleApplyPreset(16, 6)}
                className="px-2 py-0.5 rounded bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 font-bold transition cursor-pointer"
              >
                Critical (α=2.67)
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
            {/* Keys Slider */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-slate-400">Total Inserted Keys (N):</span>
                <span className="text-sky-300 font-bold">{keyCount} keys</span>
              </div>
              <input
                type="range"
                min={2}
                max={16}
                value={keyCount}
                onChange={(e) => {
                  setKeyCount(Number(e.target.value));
                  soundFx.playClick();
                }}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-sky-400"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>2 (Sparse)</span>
                <span>8 (Medium)</span>
                <span>16 (Dense)</span>
              </div>
            </div>

            {/* Capacity Selector */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-slate-400">Bucket Array Slots (M):</span>
                <span className="text-sky-300 font-bold">{simCapacity} slots</span>
              </div>
              <div className="flex items-center space-x-2">
                {[4, 6, 8, 12, 16].map((cap) => (
                  <button
                    key={cap}
                    onClick={() => {
                      setSimCapacity(cap);
                      soundFx.playClick();
                    }}
                    className={`flex-1 py-1 rounded text-xs font-mono font-semibold transition cursor-pointer ${
                      simCapacity === cap
                        ? "bg-sky-500 text-slate-950 font-bold"
                        : "bg-slate-800 hover:bg-slate-700 text-slate-300"
                    }`}
                  >
                    {cap}
                  </button>
                ))}
              </div>
              <div className="flex items-center justify-between text-[10px] text-slate-500">
                <span>Lower capacity = more collisions</span>
                {simCapacity < 16 && (
                  <button
                    onClick={handleRehash}
                    className="text-sky-400 hover:text-sky-300 font-mono flex items-center space-x-1 cursor-pointer"
                  >
                    <RefreshCw className="w-2.5 h-2.5" />
                    <span>Rehash (2x M)</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Load Factor & Collision Status Cockpit */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {/* Load Factor Card */}
        <div
          className={`p-3.5 rounded-xl border transition-all ${
            loadFactor >= 0.75
              ? "bg-rose-950/30 border-rose-500/60 shadow-lg shadow-rose-950/40"
              : "bg-slate-950 border-slate-800"
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono text-slate-400 uppercase">Load Factor (α)</span>
            <span className={`text-[10px] font-bold font-mono px-1.5 py-0.5 rounded border ${statusTier.color}`}>
              {statusTier.label}
            </span>
          </div>
          <div className="flex items-baseline space-x-2 mt-1">
            <span
              className={`text-2xl font-bold font-mono ${
                loadFactor >= 0.75 ? "text-rose-400 animate-pulse" : "text-sky-400"
              }`}
            >
              {loadFactor}
            </span>
            <span className="text-xs text-slate-400 font-mono">
              ({activeKeys.length} / {activeCapacity})
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1 line-clamp-1">{statusTier.description}</p>
        </div>

        {/* Collisions Card */}
        <div
          className={`p-3.5 rounded-xl border transition-all ${
            collisionCount > 0
              ? "bg-rose-950/30 border-rose-500/60 shadow-lg shadow-rose-950/40"
              : "bg-slate-950 border-slate-800"
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono text-slate-400 uppercase">Collisions</span>
            {collisionCount > 0 ? (
              <span className="text-[10px] font-bold font-mono px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/40 flex items-center space-x-1">
                <AlertTriangle className="w-2.5 h-2.5" />
                <span>RED ALERT</span>
              </span>
            ) : (
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                ZERO
              </span>
            )}
          </div>
          <div className="flex items-baseline space-x-2 mt-1">
            <span
              className={`text-2xl font-bold font-mono ${
                collisionCount > 0 ? "text-rose-400 font-extrabold" : "text-emerald-400"
              }`}
            >
              {collisionCount}
            </span>
            <span className="text-xs text-slate-400 font-mono">
              in {collidingBucketIndices.size} {collidingBucketIndices.size === 1 ? "bucket" : "buckets"}
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            {collisionCount > 0
              ? "Multiple keys resolved via linked chain"
              : "Every key maps to an exclusive slot"}
          </p>
        </div>

        {/* Clustered Slots Card */}
        <div className="bg-slate-950 border border-slate-800 p-3.5 rounded-xl">
          <span className="text-[10px] font-mono text-slate-400 uppercase block">Chained Slots</span>
          <div className="text-2xl font-bold font-mono text-slate-100 mt-1">
            {collidingBucketIndices.size}{" "}
            <span className="text-xs text-slate-400 font-normal">/ {activeCapacity}</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            {collidingBucketIndices.size > 0
              ? `Slots: [${Array.from(collidingBucketIndices).sort((a, b) => a - b).join(", ")}]`
              : "No chain lists required"}
          </p>
        </div>

        {/* Rehashing Advice Card */}
        <div className="bg-slate-950 border border-slate-800 p-3.5 rounded-xl">
          <span className="text-[10px] font-mono text-slate-400 uppercase block">Rehash Threshold</span>
          <div className="text-base font-bold font-mono mt-1 text-slate-200 flex items-center space-x-1.5">
            {loadFactor >= 0.75 ? (
              <span className="text-rose-400 font-bold flex items-center space-x-1">
                <ShieldAlert className="w-4 h-4 text-rose-500" />
                <span>Trigger Rehash!</span>
              </span>
            ) : (
              <span className="text-emerald-400 flex items-center space-x-1">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Capacity OK</span>
              </span>
            )}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            Java/C++ standard rehashing threshold: α = 0.75
          </p>
        </div>
      </div>

      {/* DYNAMIC VISUAL MAPPING STAGE (Keys -> SVG Connectors -> Bucket Array) */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs text-slate-400 px-1">
          <span className="font-semibold text-slate-300">
            Hover over any Key or Bucket to inspect its mapping path
          </span>
          <div className="flex items-center space-x-3 text-[11px] font-mono">
            <span className="flex items-center space-x-1 text-sky-400">
              <span className="w-2.5 h-2.5 rounded-full bg-sky-400" />
              <span>Direct Slot O(1)</span>
            </span>
            <span className="flex items-center space-x-1 text-rose-400 font-semibold">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
              <span>Collision Chain (Red)</span>
            </span>
          </div>
        </div>

        <div
          ref={containerRef}
          className="relative bg-slate-950 border border-slate-800 rounded-2xl p-4 sm:p-6 overflow-hidden min-h-[420px]"
        >
          {/* Background SVG Canvas with Dynamic Curved Bezier Connectors */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none z-10">
            <defs>
              <linearGradient id="grad-sky" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.8" />
                <stop offset="100%" stopColor="#0284c7" stopOpacity="0.8" />
              </linearGradient>
              <linearGradient id="grad-rose" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#f43f5e" stopOpacity="0.9" />
                <stop offset="100%" stopColor="#e11d48" stopOpacity="0.9" />
              </linearGradient>
            </defs>

            {lineCoords.map((line, idx) => {
              const isHovered =
                hoveredKey === line.keyId ||
                hoveredBucket === line.bucketIdx;
              const hasAnyHover = hoveredKey !== null || hoveredBucket !== null;

              // Calculate control points for smooth horizontal S-curve
              const dx = line.x2 - line.x1;
              const cp1x = line.x1 + dx * 0.45;
              const cp1y = line.y1;
              const cp2x = line.x1 + dx * 0.55;
              const cp2y = line.y2;
              const pathD = `M ${line.x1} ${line.y1} C ${cp1x} ${cp1y}, ${cp2x} ${cp2y}, ${line.x2} ${line.y2}`;

              let strokeColor = line.isCollision ? "#f43f5e" : "#38bdf8";
              let strokeWidth = isHovered ? 3.5 : line.isCollision ? 2.5 : 1.5;
              let opacity = hasAnyHover ? (isHovered ? 1.0 : 0.15) : line.isCollision ? 0.9 : 0.55;

              return (
                <g key={`${line.keyId}-${line.bucketIdx}-${idx}`}>
                  {/* Subtle glow filter under the line */}
                  {(isHovered || line.isCollision) && (
                    <path
                      d={pathD}
                      fill="none"
                      stroke={line.isCollision ? "#fb7185" : "#7dd3fc"}
                      strokeWidth={strokeWidth + 4}
                      strokeOpacity={opacity * 0.3}
                      strokeLinecap="round"
                    />
                  )}
                  {/* Main Bezier Connector */}
                  <path
                    d={pathD}
                    fill="none"
                    stroke={strokeColor}
                    strokeWidth={strokeWidth}
                    strokeOpacity={opacity}
                    strokeDasharray={line.isCollision ? "6, 4" : undefined}
                    strokeLinecap="round"
                    className="transition-all duration-300"
                  />
                  {/* Animated directional pulse dot */}
                  {(isHovered || line.isCollision) && (
                    <circle
                      cx={(line.x1 + line.x2) / 2}
                      cy={(line.y1 + line.y2) / 2}
                      r={line.isCollision ? 3.5 : 2.5}
                      fill={line.isCollision ? "#ffe4e6" : "#e0f2fe"}
                      className={line.isCollision ? "animate-pulse" : ""}
                    />
                  )}
                </g>
              );
            })}
          </svg>

          {/* Foreground Grid: Keys on Left, Buckets on Right */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-24 relative z-20">
            {/* LEFT COLUMN: Input String Keys */}
            <div className="space-y-2.5">
              <div className="flex items-center justify-between pb-1 border-b border-slate-800">
                <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center space-x-1.5">
                  <span>Input Keys (N = {activeKeys.length})</span>
                </span>
                <span className="text-[10px] font-mono text-slate-400">
                  {HASH_ALGORITHMS[selectedAlgo]?.shortName || "Hash"}(Key) &rarr; Bucket
                </span>
              </div>

              <div className="space-y-2 max-h-[520px] overflow-y-auto pr-1">
                {activeKeys.map((item) => {
                  const targetSlot = hashKey(item.key, activeCapacity);
                  const isCollision = collidingBucketIndices.has(targetSlot);
                  const isHovered = hoveredKey === item.key || hoveredBucket === targetSlot;

                  return (
                    <div
                      key={item.key}
                      data-key-id={item.key}
                      onMouseEnter={() => setHoveredKey(item.key)}
                      onMouseLeave={() => setHoveredKey(null)}
                      className={`p-2.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between shadow-sm ${
                        isHovered
                          ? isCollision
                            ? "bg-rose-950/60 border-rose-500 ring-2 ring-rose-500/80 scale-[1.02]"
                            : "bg-sky-950/60 border-sky-400 ring-2 ring-sky-400/80 scale-[1.02]"
                          : isCollision
                          ? "bg-rose-950/20 border-rose-500/50 hover:border-rose-400 text-rose-200"
                          : "bg-slate-900/90 border-slate-800 hover:border-slate-700"
                      }`}
                    >
                      <div className="flex items-center space-x-2.5 min-w-0">
                        <span
                          className={`font-mono text-xs font-bold px-1.5 py-0.5 rounded ${
                            isCollision
                              ? "bg-rose-500/20 text-rose-300 border border-rose-500/40"
                              : "bg-sky-500/10 text-sky-400 border border-sky-500/30"
                          }`}
                        >
                          {item.key}
                        </span>
                        <div className="truncate">
                          <div className="text-xs font-medium text-slate-200 truncate">{item.label}</div>
                          <div className="text-[10px] text-slate-500 font-mono">Type: {item.type}</div>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2 shrink-0 pl-2">
                        <div className="text-right">
                          <div className="text-[10px] text-slate-400 font-mono">maps to</div>
                          <div
                            className={`text-xs font-bold font-mono ${
                              isCollision ? "text-rose-400" : "text-sky-300"
                            }`}
                          >
                            Bucket [{targetSlot}]
                          </div>
                        </div>
                        <ArrowRight
                          className={`w-3.5 h-3.5 ${
                            isCollision ? "text-rose-500" : "text-sky-400"
                          }`}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* RIGHT COLUMN: Bucket Slots with Collision Highlights */}
            <div className="space-y-2.5">
              <div className="flex items-center justify-between pb-1 border-b border-slate-800">
                <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                  Hash Buckets Array (M = {activeCapacity})
                </span>
                <span className="text-[10px] font-mono text-slate-500">Chained Nodes</span>
              </div>

              <div className="space-y-2 max-h-[520px] overflow-y-auto pr-1">
                {bucketMappings.map((bucket) => {
                  const isCollision = bucket.items.length > 1;
                  const isEmpty = bucket.items.length === 0;
                  const isHovered =
                    hoveredBucket === bucket.index ||
                    (hoveredKey !== null && hashKey(hoveredKey, activeCapacity) === bucket.index);

                  return (
                    <div
                      key={bucket.index}
                      data-bucket-idx={bucket.index}
                      onMouseEnter={() => setHoveredBucket(bucket.index)}
                      onMouseLeave={() => setHoveredBucket(null)}
                      className={`p-3 rounded-xl border transition-all cursor-pointer ${
                        isHovered
                          ? isCollision
                            ? "bg-rose-950/70 border-rose-500 ring-2 ring-rose-500/90 scale-[1.02]"
                            : "bg-sky-950/60 border-sky-400 ring-2 ring-sky-400/80 scale-[1.02]"
                          : isCollision
                          ? "bg-rose-950/30 border-rose-500 shadow-md shadow-rose-950/40 ring-1 ring-rose-500/50"
                          : !isEmpty
                          ? "bg-slate-900/90 border-slate-800 hover:border-slate-700"
                          : "bg-slate-950 border-slate-800/40 opacity-50 hover:opacity-75"
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <div className="flex items-center space-x-2">
                          <span
                            className={`font-mono text-xs font-bold px-2 py-0.5 rounded border ${
                              isCollision
                                ? "bg-rose-500/20 text-rose-300 border-rose-500/50"
                                : !isEmpty
                                ? "bg-sky-500/10 text-sky-400 border-sky-500/30"
                                : "bg-slate-900 text-slate-600 border-slate-800"
                            }`}
                          >
                            Slot [{bucket.index}]
                          </span>
                          <span className="text-[11px] font-mono text-slate-400">
                            {bucket.items.length}{" "}
                            {bucket.items.length === 1 ? "node" : "nodes"}
                          </span>
                        </div>

                        {/* Collision Badge in Red */}
                        {isCollision ? (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40 flex items-center space-x-1 animate-pulse">
                            <AlertTriangle className="w-3 h-3 text-rose-400" />
                            <span>COLLISION CHAIN ({bucket.items.length})</span>
                          </span>
                        ) : !isEmpty ? (
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                            Direct O(1)
                          </span>
                        ) : (
                          <span className="text-[10px] font-mono text-slate-600 uppercase">
                            Empty
                          </span>
                        )}
                      </div>

                      {/* Chained Nodes Preview */}
                      {isEmpty ? (
                        <div className="text-[11px] font-mono text-slate-600 italic">
                          (null)
                        </div>
                      ) : (
                        <div className="flex flex-wrap items-center gap-1.5 pt-1">
                          {bucket.items.map((item, idx) => (
                            <React.Fragment key={item.key}>
                              <div
                                className={`px-2 py-1 rounded-md text-xs font-mono flex items-center space-x-1.5 border ${
                                  isCollision
                                    ? "bg-rose-950/60 border-rose-500/40 text-rose-200"
                                    : "bg-slate-950 border-slate-800 text-slate-300"
                                }`}
                              >
                                <span className="font-bold text-sky-400">{item.key}</span>
                                <span className="text-slate-400 text-[10px] truncate max-w-[100px]">
                                  {item.label}
                                </span>
                              </div>
                              {idx < bucket.items.length - 1 && (
                                <span
                                  className={`text-xs font-mono font-bold ${
                                    isCollision ? "text-rose-400" : "text-amber-400"
                                  }`}
                                >
                                  &rarr;
                                </span>
                              )}
                            </React.Fragment>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
