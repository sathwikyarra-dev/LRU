import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { Cpu, Zap, ArrowRight, Layers, ShieldCheck } from "lucide-react";
import logoImage from "../assets/images/lru_cache_logo_1790061320141.jpg";
import { soundFx } from "../audioSynth";

interface SplashScreenProps {
  durationMs?: number;
  onComplete: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({
  durationMs = 3000,
  onComplete
}) => {
  const [progress, setProgress] = useState(0);
  const [imgError, setImgError] = useState(false);

  useEffect(() => {
    // Play subtle soft boot audio chime
    soundFx.playHit();

    const intervalStep = 30; // ms
    const increment = (intervalStep / durationMs) * 100;

    const timer = setInterval(() => {
      setProgress((prev) => {
        const next = prev + increment;
        if (next >= 100) {
          clearInterval(timer);
          setTimeout(onComplete, 100);
          return 100;
        }
        return next;
      });
    }, intervalStep);

    // Allow user to dismiss with Escape or Space
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" || e.key === " ") {
        clearInterval(timer);
        onComplete();
      }
    };
    window.addEventListener("keydown", handleKeyDown);

    return () => {
      clearInterval(timer);
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [durationMs, onComplete]);

  // Stage message based on current progress
  const getBootStatus = () => {
    if (progress < 25) return "Initializing L1/L2 Cache Hierarchy...";
    if (progress < 55) return "Allocating Doubly Linked List & Hash Map...";
    if (progress < 85) return "Binding O(1) Memory Pointers & Cache Slots...";
    return "LRU Cache Memory Engine Ready";
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/95 backdrop-blur-xl select-none"
    >
      {/* Background ambient lighting effects */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-sky-500/10 via-transparent to-transparent pointer-events-none" />
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Main Logo Card */}
      <motion.div
        initial={{ scale: 0.9, opacity: 0, y: 15 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: "easeOut" }}
        className="relative flex flex-col items-center max-w-md w-full mx-4 p-8 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-2xl shadow-sky-950/50 text-center"
      >
        {/* Glow Ring behind the logo */}
        <div className="relative mb-6">
          <div className="absolute -inset-2 bg-gradient-to-r from-cyan-500 to-sky-600 rounded-2xl blur-md opacity-40 animate-pulse" />
          
          <div className="relative w-28 h-28 rounded-2xl overflow-hidden border-2 border-cyan-400/40 bg-slate-950 flex items-center justify-center shadow-inner">
            {!imgError ? (
              <img
                src={logoImage}
                alt="LRU Cache Engine Logo"
                referrerPolicy="no-referrer"
                onError={() => setImgError(true)}
                className="w-full h-full object-cover transform scale-105"
              />
            ) : (
              <div className="w-full h-full flex flex-col items-center justify-center bg-slate-950 text-cyan-400">
                <Cpu className="w-12 h-12 animate-pulse" />
                <span className="text-[10px] font-mono mt-1 text-slate-400">LRU ENGINE</span>
              </div>
            )}
          </div>

          <div className="absolute -bottom-2 -right-2 px-2 py-0.5 rounded-full bg-cyan-500 text-slate-950 text-[10px] font-mono font-bold shadow">
            3.0s
          </div>
        </div>

        {/* Title and Specs */}
        <h1 className="text-xl font-bold tracking-tight text-white mb-1 flex items-center justify-center space-x-2">
          <span>LRU Cache Simulator</span>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-sky-500/10 text-sky-400 border border-sky-500/30 font-semibold">
            v2.4
          </span>
        </h1>

        <p className="text-xs text-slate-400 max-w-xs mb-6 font-medium">
          Interactive Doubly Linked List & Hash Map Virtual Architecture
        </p>

        {/* Status indicator badge */}
        <div className="w-full flex items-center justify-between text-[11px] font-mono text-slate-400 mb-2 px-1">
          <span className="flex items-center space-x-1.5 text-sky-300">
            <Zap className="w-3.5 h-3.5 text-cyan-400 animate-spin" />
            <span>{getBootStatus()}</span>
          </span>
          <span className="text-slate-300 font-semibold">{Math.min(100, Math.round(progress))}%</span>
        </div>

        {/* Progress Bar */}
        <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden mb-6 border border-slate-700/50">
          <div
            className="h-full bg-gradient-to-r from-cyan-500 via-sky-400 to-emerald-400 transition-all duration-75 ease-linear rounded-full"
            style={{ width: `${progress}%` }}
          />
        </div>

        {/* Architecture Specs Pill */}
        <div className="flex items-center justify-center space-x-3 text-[10px] font-mono text-slate-400 mb-4 pb-4 border-b border-slate-800/80 w-full">
          <span className="flex items-center space-x-1">
            <Layers className="w-3 h-3 text-cyan-400" />
            <span>O(1) Time</span>
          </span>
          <span>•</span>
          <span className="flex items-center space-x-1">
            <ShieldCheck className="w-3 h-3 text-emerald-400" />
            <span>Memory Safe</span>
          </span>
          <span>•</span>
          <span className="text-slate-400">64-Bit Bus</span>
        </div>

        {/* Skip button */}
        <button
          onClick={() => {
            soundFx.playClick();
            onComplete();
          }}
          className="group flex items-center space-x-1 text-xs font-mono text-slate-400 hover:text-cyan-300 transition-colors cursor-pointer py-1 px-3 rounded hover:bg-slate-800/60"
        >
          <span>Skip initialization</span>
          <ArrowRight className="w-3 h-3 transform group-hover:translate-x-0.5 transition-transform" />
        </button>
      </motion.div>
    </motion.div>
  );
};
