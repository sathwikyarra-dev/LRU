import React, { useState } from "react";
import { Cpu, Database, HardDrive, ArrowRight, Zap, RefreshCw, Layers, ShieldCheck, Activity } from "lucide-react";
import { soundFx } from "../audioSynth";

interface ArchitecturePipelineHUDProps {
  lastOperation?: {
    fileId?: string;
    fileName: string;
    status: "HIT" | "MISS" | "EVICTED" | "OK" | "PURGED";
    latencyMs: number;
  };
  onBurstAccess: (type: "zipf" | "thrash" | "random") => void;
}

export const ArchitecturePipelineHUD: React.FC<ArchitecturePipelineHUDProps> = ({
  lastOperation,
  onBurstAccess
}) => {
  const [activeComponent, setActiveComponent] = useState<string | null>(null);

  const isHit = lastOperation?.status === "HIT";
  const isMiss = lastOperation?.status === "MISS" || lastOperation?.status === "EVICTED";

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 shadow-xl relative overflow-hidden backdrop-blur-md">
      {/* Subtle background circuit styling */}
      <div className="absolute top-0 right-0 w-96 h-full bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-sky-500/5 via-transparent to-transparent pointer-events-none" />

      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4 pb-3 border-b border-slate-800/80">
        <div className="flex items-center space-x-2">
          <div className="p-1.5 rounded-lg bg-sky-500/10 border border-sky-500/30 text-sky-400">
            <Activity className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
                Hardware Memory Pipeline & Execution Flow
              </h3>
              <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                LIVE BUS 64-BIT
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              Trace request path through Hash Computation, Bucket Pointer, and Doubly Linked List
            </p>
          </div>
        </div>

        {/* Quick Burst Triggers */}
        <div className="flex items-center space-x-1.5">
          <span className="text-[10px] font-mono text-slate-400 hidden md:inline">Stress Testing:</span>
          <button
            onClick={() => {
              soundFx.playClick();
              onBurstAccess("zipf");
            }}
            title="Access high-frequency hot files (Zipfian 80/20 distribution)"
            className="flex items-center space-x-1 px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded text-[11px] font-medium transition cursor-pointer"
          >
            <Zap className="w-3 h-3 text-sky-400" />
            <span>Zipfian Burst</span>
          </button>
          <button
            onClick={() => {
              soundFx.playClick();
              onBurstAccess("thrash");
            }}
            title="Sequential access of 6 files exceeding cache capacity to force tail evictions"
            className="flex items-center space-x-1 px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded text-[11px] font-medium transition cursor-pointer"
          >
            <RefreshCw className="w-3 h-3 text-amber-400" />
            <span>Thrash Evict</span>
          </button>
          <button
            onClick={() => {
              soundFx.playClick();
              onBurstAccess("random");
            }}
            title="Random probe into storage catalog"
            className="flex items-center space-x-1 px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded text-[11px] font-medium transition cursor-pointer"
          >
            <Layers className="w-3 h-3 text-indigo-400" />
            <span>Random Probe</span>
          </button>
        </div>
      </div>

      {/* Interactive Pipeline Diagram */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-2 relative items-center py-2">
        {/* Step 1: CPU / Client Query */}
        <div
          onClick={() => setActiveComponent("cpu")}
          className={`p-3 rounded-lg border transition-all cursor-pointer relative ${
            activeComponent === "cpu"
              ? "bg-sky-950/60 border-sky-400 shadow-md shadow-sky-950"
              : "bg-slate-950/80 border-slate-800 hover:border-slate-700"
          }`}
        >
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[10px] font-mono font-bold text-sky-400">STAGE 01</span>
            <Cpu className="w-3.5 h-3.5 text-sky-400" />
          </div>
          <h4 className="text-xs font-bold text-slate-100">CPU Core Query</h4>
          <p className="text-[10px] text-slate-400 mt-1 font-mono">
            {lastOperation ? `GET "${lastOperation.fileName}"` : "IDLE (Listening)"}
          </p>
          <div className="mt-2 text-[9px] font-mono text-slate-500">Latency: ~0.01ms</div>
        </div>

        {/* Step 2: Polynomial Hash Engine */}
        <div
          onClick={() => setActiveComponent("hash")}
          className={`p-3 rounded-lg border transition-all cursor-pointer relative ${
            activeComponent === "hash"
              ? "bg-indigo-950/60 border-indigo-400 shadow-md shadow-indigo-950"
              : "bg-slate-950/80 border-slate-800 hover:border-slate-700"
          }`}
        >
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[10px] font-mono font-bold text-indigo-400">STAGE 02</span>
            <span className="text-[10px] font-mono text-indigo-300">#31</span>
          </div>
          <h4 className="text-xs font-bold text-slate-100">Polynomial Hash</h4>
          <p className="text-[10px] text-indigo-300 mt-1 font-mono">
            (H × 31 + c) % 16
          </p>
          <div className="mt-2 text-[9px] font-mono text-slate-500">Compute: O(1) ops</div>
        </div>

        {/* Step 3: Hash Table Buckets */}
        <div
          onClick={() => setActiveComponent("buckets")}
          className={`p-3 rounded-lg border transition-all cursor-pointer relative ${
            activeComponent === "buckets"
              ? "bg-purple-950/60 border-purple-400 shadow-md shadow-purple-950"
              : "bg-slate-950/80 border-slate-800 hover:border-slate-700"
          }`}
        >
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[10px] font-mono font-bold text-purple-400">STAGE 03</span>
            <Database className="w-3.5 h-3.5 text-purple-400" />
          </div>
          <h4 className="text-xs font-bold text-slate-100">RAM Buckets</h4>
          <p className="text-[10px] text-slate-400 mt-1 font-mono">
            Chaining: Array[16]
          </p>
          <div className="mt-2 text-[9px] font-mono text-slate-500">
            {lastOperation ? (isHit ? "MATCH FOUND" : "NULL BUCKET") : "16 Slots"}
          </div>
        </div>

        {/* Step 4: Branch Resolution (Hit vs Miss) */}
        <div
          onClick={() => setActiveComponent("decision")}
          className={`p-3 rounded-lg border transition-all cursor-pointer relative ${
            isHit
              ? "bg-emerald-950/50 border-emerald-500/50 shadow-md shadow-emerald-950"
              : isMiss
              ? "bg-rose-950/50 border-rose-500/50 shadow-md shadow-rose-950"
              : "bg-slate-950/80 border-slate-800"
          }`}
        >
          <div className="flex items-center justify-between mb-1.5">
            <span className={`text-[10px] font-mono font-bold ${isHit ? "text-emerald-400" : isMiss ? "text-rose-400" : "text-slate-400"}`}>
              BRANCH
            </span>
            <span className="text-[10px] font-mono font-bold">
              {isHit ? "HIT" : isMiss ? "MISS" : "READY"}
            </span>
          </div>
          <h4 className="text-xs font-bold text-slate-100">
            {isHit ? "RAM Hit O(1)" : isMiss ? "Disk Load Penalty" : "Cache Decision"}
          </h4>
          <p className="text-[10px] text-slate-400 mt-1 font-mono">
            {isHit ? "Promote to Head" : isMiss ? "Fetch Disk & Evict" : "Evaluating"}
          </p>
          <div className="mt-2 text-[9px] font-mono text-slate-400">
            {lastOperation ? `${lastOperation.latencyMs}ms latency` : "Awaiting Query"}
          </div>
        </div>

        {/* Step 5: Doubly Linked List & Storage */}
        <div
          onClick={() => setActiveComponent("dll")}
          className={`p-3 rounded-lg border transition-all cursor-pointer relative ${
            activeComponent === "dll"
              ? "bg-sky-950/60 border-sky-400 shadow-md shadow-sky-950"
              : "bg-slate-950/80 border-slate-800 hover:border-slate-700"
          }`}
        >
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[10px] font-mono font-bold text-sky-400">STAGE 05</span>
            <HardDrive className="w-3.5 h-3.5 text-sky-400" />
          </div>
          <h4 className="text-xs font-bold text-slate-100">DLL Pointers</h4>
          <p className="text-[10px] text-slate-400 mt-1 font-mono">
            HEAD (MRU) ⇄ TAIL (LRU)
          </p>
          <div className="mt-2 text-[9px] font-mono text-slate-500">Pointers: prev / next</div>
        </div>
      </div>

      {/* Component Deep-Dive Explanation Drawer */}
      {activeComponent && (
        <div className="mt-3 p-3 bg-slate-950 border border-slate-800 rounded-lg text-xs animate-in fade-in duration-200">
          <div className="flex items-center justify-between mb-1">
            <span className="font-bold text-sky-400 uppercase tracking-wider text-[11px]">
              {activeComponent === "cpu" && "Stage 1: CPU Query Dispatcher"}
              {activeComponent === "hash" && "Stage 2: Polynomial Rolling Hash Arithmetic"}
              {activeComponent === "buckets" && "Stage 3: Separate Chaining RAM Hash Buckets"}
              {activeComponent === "decision" && "Stage 4: Cache Branch Predictor & Latency Delta"}
              {activeComponent === "dll" && "Stage 5: Doubly Linked List MRU/LRU Pointer Splicing"}
            </span>
            <button
              onClick={() => setActiveComponent(null)}
              className="text-[10px] text-slate-500 hover:text-slate-300 cursor-pointer font-mono"
            >
              [Close Info]
            </button>
          </div>
          <p className="text-slate-300 leading-relaxed text-[11px]">
            {activeComponent === "cpu" &&
              "When an application layer requests a file key (e.g. 'F001'), the memory management unit first queries the fast RAM L1/L2 cache dictionary before initiating expensive rotational disk or NVMe block reads."}
            {activeComponent === "hash" &&
              "To prevent key clustering, the hash function multiplies each ASCII character code by 31 (a prime multiplier chosen by Gosling & Knuth) and computes modulo 16. This evenly distributes keys across slots in O(K) time where K is key length."}
            {activeComponent === "buckets" &&
              "Hash collisions are resolved gracefully via Separate Chaining linked lists inside each bucket. When load factor remains under 0.75, average search length is virtually 1 step."}
            {activeComponent === "decision" &&
              "Cache Hits bypass secondary storage completely, returning in ~0.1ms directly from RAM. Cache Misses incur a ~1.8ms to 3.0ms disk fetch penalty and trigger eviction of the tail item when capacity is saturated."}
            {activeComponent === "dll" &&
              "By maintaining both `prev` and `next` object references on each cache node along with sentinel `head` and `tail` pointers, unlinking a node and re-attaching it to the head requires exactly 4 pointer rewires in O(1) constant time."}
          </p>
        </div>
      )}
    </div>
  );
};
