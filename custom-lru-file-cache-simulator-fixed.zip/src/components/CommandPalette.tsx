import React, { useState, useEffect, useRef } from "react";
import { FileNodeItem } from "../types";
import { Search, Zap, LayoutDashboard, Cpu, HardDrive, Hash, BarChart3, RotateCcw, X, Play, Layers } from "lucide-react";
import { TabKey } from "./Sidebar";

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  files: FileNodeItem[];
  cachedFileIds: Set<string>;
  onAccessFile: (fileId: string) => void;
  onSelectTab: (tab: TabKey) => void;
  onRunDemo: () => void;
  onOpenReport: () => void;
  onReset: () => void;
  onShowSplash?: () => void;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({
  isOpen,
  onClose,
  files,
  cachedFileIds,
  onAccessFile,
  onSelectTab,
  onRunDemo,
  onOpenReport,
  onReset,
  onShowSplash
}) => {
  const [query, setQuery] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setQuery("");
    }
  }, [isOpen]);

  // Global keydown listener for ESC
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isOpen) {
        onClose();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const filteredFiles = files.filter(
    (f) =>
      f.fileName.toLowerCase().includes(query.toLowerCase()) ||
      f.fileId.toLowerCase().includes(query.toLowerCase()) ||
      f.fileType.toLowerCase().includes(query.toLowerCase())
  );

  const navigationActions = [
    { label: "Dashboard", tab: "dashboard" as TabKey, icon: <LayoutDashboard className="w-3.5 h-3.5" /> },
    { label: "Cache Memory (DLL)", tab: "cache" as TabKey, icon: <Cpu className="w-3.5 h-3.5" /> },
    { label: "Multi-Policy Comparison Suite", tab: "comparison" as TabKey, icon: <Layers className="w-3.5 h-3.5" /> },
    { label: "File Storage Disk", tab: "storage" as TabKey, icon: <HardDrive className="w-3.5 h-3.5" /> },
    { label: "Custom HashMap & Buckets", tab: "hashmap" as TabKey, icon: <Hash className="w-3.5 h-3.5" /> },
    { label: "Performance Lab & Analytics", tab: "statistics" as TabKey, icon: <BarChart3 className="w-3.5 h-3.5" /> },
  ].filter((a) => a.label.toLowerCase().includes(query.toLowerCase()));

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-start justify-center pt-24 p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-xl w-full shadow-2xl overflow-hidden flex flex-col">
        {/* Search Input Bar */}
        <div className="flex items-center px-4 py-3 border-b border-slate-800 bg-slate-950">
          <Search className="w-4 h-4 text-sky-400 mr-2.5 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Type a command or search files (e.g. 'report', 'F001', 'demo')..."
            className="bg-transparent text-sm text-slate-100 placeholder-slate-500 outline-none w-full font-sans"
          />
          <button onClick={onClose} className="text-slate-400 hover:text-slate-200 p-1">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Results List */}
        <div className="max-h-80 overflow-y-auto p-2 divide-y divide-slate-800/50 text-xs">
          {/* Files */}
          <div className="py-1">
            <span className="text-[10px] font-bold text-slate-500 uppercase px-3 py-1 block">
              Repository Files (Click to Access in LRU)
            </span>
            {filteredFiles.length === 0 ? (
              <span className="text-slate-500 text-xs px-3 py-1 block italic">No matching files found</span>
            ) : (
              filteredFiles.slice(0, 5).map((file) => {
                const isCached = cachedFileIds.has(file.fileId);
                return (
                  <button
                    key={file.fileId}
                    onClick={() => {
                      onAccessFile(file.fileId);
                      onClose();
                    }}
                    className="w-full flex items-center justify-between px-3 py-2 rounded-lg hover:bg-slate-800/80 text-left transition cursor-pointer"
                  >
                    <div className="flex items-center space-x-2.5">
                      <span className="font-mono text-sky-400 font-bold">{file.fileId}</span>
                      <span className="text-slate-200 font-semibold">{file.fileName}</span>
                      <span className="text-slate-500 font-mono text-[10px]">({file.fileSize}MB)</span>
                    </div>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        isCached
                          ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
                          : "bg-slate-800 text-slate-400"
                      }`}
                    >
                      {isCached ? "IN CACHE" : "DISK"}
                    </span>
                  </button>
                );
              })
            )}
          </div>

          {/* Quick Actions & Navigation */}
          <div className="py-1">
            <span className="text-[10px] font-bold text-slate-500 uppercase px-3 py-1 block">
              Navigation & Operations
            </span>
            {navigationActions.map((act) => (
              <button
                key={act.label}
                onClick={() => {
                  onSelectTab(act.tab);
                  onClose();
                }}
                className="w-full flex items-center space-x-2 px-3 py-2 rounded-lg hover:bg-slate-800/80 text-slate-300 hover:text-slate-100 text-left transition cursor-pointer"
              >
                <span className="text-sky-400">{act.icon}</span>
                <span>Go to {act.label}</span>
              </button>
            ))}

            <button
              onClick={() => {
                onRunDemo();
                onClose();
              }}
              className="w-full flex items-center space-x-2 px-3 py-2 rounded-lg hover:bg-slate-800/80 text-slate-300 hover:text-slate-100 text-left transition cursor-pointer"
            >
              <Play className="w-3.5 h-3.5 text-emerald-400" />
              <span>Run Automated LRU Demonstration</span>
            </button>

            <button
              onClick={() => {
                onOpenReport();
                onClose();
              }}
              className="w-full flex items-center space-x-2 px-3 py-2 rounded-lg hover:bg-slate-800/80 text-slate-300 hover:text-slate-100 text-left transition cursor-pointer"
            >
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span>Generate Academic Lab Report</span>
            </button>

            {onShowSplash && (
              <button
                onClick={() => {
                  onClose();
                  onShowSplash();
                }}
                className="w-full flex items-center space-x-2 px-3 py-2 rounded-lg hover:bg-slate-800/80 text-slate-300 hover:text-slate-100 text-left transition cursor-pointer"
              >
                <Cpu className="w-3.5 h-3.5 text-cyan-400" />
                <span>Replay 3-Second Startup Logo</span>
              </button>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-4 py-2 border-t border-slate-800 bg-slate-950 text-[11px] text-slate-500 flex justify-between">
          <span>Navigate with mouse or search query</span>
          <span>Press ESC to exit</span>
        </div>
      </div>
    </div>
  );
};
