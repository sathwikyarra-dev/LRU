import React from "react";
import { Terminal, CheckCircle2, Copy, X } from "lucide-react";

interface PythonAppModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PythonAppModal: React.FC<PythonAppModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-2 text-emerald-400">
            <Terminal className="w-5 h-5" />
            <h3 className="text-base font-bold text-slate-100">
              Python Tkinter Desktop Application
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-200 rounded-lg hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-3 text-xs text-slate-300">
          <div className="p-3 bg-emerald-950/30 border border-emerald-800/60 rounded-xl flex items-center space-x-2 text-emerald-300">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>
              The complete Python application and unit test suite (14/14 tests passing) are fully built and verified in the repository.
            </span>
          </div>

          <div>
            <h4 className="font-bold text-slate-200 mb-1.5 uppercase tracking-wider text-[11px]">
              1. Run the Python Desktop Application (Tkinter GUI):
            </h4>
            <pre className="bg-slate-950 p-3 rounded-lg border border-slate-800 font-mono text-sky-300 text-[11px] overflow-x-auto">
              python3 -m lru_file_cache.main
            </pre>
            <p className="text-[11px] text-slate-400 mt-1">
              Launches the 1280x800 dark-navy desktop GUI with Matplotlib figures, Canvas Doubly Linked List, and separate chaining HashMap visualizer.
            </p>
          </div>

          <div>
            <h4 className="font-bold text-slate-200 mb-1.5 uppercase tracking-wider text-[11px]">
              2. Run the Academic Unit Test Suite:
            </h4>
            <pre className="bg-slate-950 p-3 rounded-lg border border-slate-800 font-mono text-emerald-300 text-[11px] overflow-x-auto">
              python3 -m unittest discover -s lru_file_cache/tests
            </pre>
            <p className="text-[11px] text-slate-400 mt-1">
              Verifies Custom HashMap collision handling, Doubly Linked List MRU/LRU pointers, and LRUCache eviction mechanics.
            </p>
          </div>

          <div>
            <h4 className="font-bold text-slate-200 mb-1.5 uppercase tracking-wider text-[11px]">
              3. Modular Codebase Structure:
            </h4>
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 font-mono text-[11px] text-slate-300 space-y-0.5">
              <div>📁 lru_file_cache/</div>
              <div className="pl-4">├── 📁 dsa/ (custom_hash_map, doubly_linked_list, lru_cache)</div>
              <div className="pl-4">├── 📁 gui/ (dashboard, cache_view, storage_view, hashmap_view, etc.)</div>
              <div className="pl-4">├── 📁 models/ (file_node)</div>
              <div className="pl-4">├── 📁 simulator/ (simulator engine)</div>
              <div className="pl-4">├── 📁 storage/ (file_storage JSON disk)</div>
              <div className="pl-4">├── 📁 tests/ (14 comprehensive unit tests)</div>
              <div className="pl-4">└── 📄 main.py (Tkinter GUI entry point)</div>
            </div>
          </div>
        </div>

        <div className="pt-2 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded text-xs font-bold bg-sky-500 hover:bg-sky-400 text-slate-950 transition cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
