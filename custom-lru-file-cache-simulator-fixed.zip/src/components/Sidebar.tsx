import React from "react";
import {
  LayoutDashboard,
  Cpu,
  HardDrive,
  Hash,
  BarChart3,
  ListOrdered,
  BookOpen,
  GraduationCap,
  Sparkles,
  Layers,
  Activity
} from "lucide-react";
import { soundFx } from "../audioSynth";

export type TabKey =
  | "dashboard"
  | "cache"
  | "comparison"
  | "storage"
  | "hashmap"
  | "statistics"
  | "activity"
  | "dsa"
  | "viva";

interface SidebarProps {
  activeTab: TabKey;
  onSelectTab: (tab: TabKey) => void;
  onOpenPatternModal: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  onOpenPatternModal
}) => {
  const navItems: { key: TabKey; label: string; icon: React.ReactNode; isNew?: boolean }[] = [
    { key: "dashboard", label: "Dashboard", icon: <LayoutDashboard className="w-4 h-4" /> },
    { key: "cache", label: "Cache Memory", icon: <Cpu className="w-4 h-4" /> },
    { key: "comparison", label: "Policy Compare", icon: <Layers className="w-4 h-4" />, isNew: true },
    { key: "storage", label: "File Storage", icon: <HardDrive className="w-4 h-4" /> },
    { key: "hashmap", label: "Custom HashMap", icon: <Hash className="w-4 h-4" /> },
    { key: "statistics", label: "Statistics & Lab", icon: <BarChart3 className="w-4 h-4" /> },
    { key: "activity", label: "Activity Log", icon: <ListOrdered className="w-4 h-4" /> },
    { key: "dsa", label: "DSA Concepts", icon: <BookOpen className="w-4 h-4" /> },
    { key: "viva", label: "Viva Mode", icon: <GraduationCap className="w-4 h-4" /> },
  ];

  return (
    <aside className="w-56 border-r border-slate-800 bg-slate-900/95 flex flex-col justify-between p-3 shrink-0 select-none backdrop-blur-sm">
      <div>
        <div className="px-3 pt-2 pb-3 flex items-center justify-between">
          <span className="text-[10px] font-bold tracking-wider text-slate-400 uppercase">
            Navigation
          </span>
          <span className="flex items-center space-x-1 text-[9px] font-mono text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span>SYNCED</span>
          </span>
        </div>

        <nav className="space-y-1">
          {navItems.map((item) => {
            const isActive = activeTab === item.key;
            return (
              <button
                key={item.key}
                id={`nav-${item.key}`}
                onClick={() => {
                  soundFx.playClick();
                  onSelectTab(item.key);
                }}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition cursor-pointer ${
                  isActive
                    ? "bg-slate-800 text-sky-400 border border-sky-500/40 shadow-sm"
                    : "text-slate-300 hover:bg-slate-800/60 hover:text-slate-100"
                }`}
              >
                <div className="flex items-center space-x-2.5">
                  <span className={isActive ? "text-sky-400" : "text-slate-400"}>{item.icon}</span>
                  <span>{item.label}</span>
                </div>
                {item.isNew && (
                  <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-sky-500/20 text-sky-300 border border-sky-500/40">
                    NEW
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      <div className="pt-4 border-t border-slate-800 space-y-2">
        <button
          id="btn-sidebar-pattern"
          onClick={() => {
            soundFx.playClick();
            onOpenPatternModal();
          }}
          className="w-full flex items-center justify-center space-x-2 px-3 py-2 rounded-lg text-xs font-semibold bg-sky-500 hover:bg-sky-400 text-slate-950 shadow-md shadow-sky-500/20 transition cursor-pointer"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Workload Generator</span>
        </button>

        <div className="px-2 py-1.5 rounded bg-slate-950/60 border border-slate-800/80 text-[10px] font-mono text-slate-500 flex justify-between items-center">
          <span>COMPLEXITY</span>
          <span className="text-sky-400 font-bold">O(1) GET / PUT</span>
        </div>
      </div>
    </aside>
  );
};
