import React from "react";
import { CheckCircle2, AlertCircle, ArrowUpRight, ArrowDownRight, Layers, X } from "lucide-react";
import { FileNodeItem } from "../types";

interface AccessResultModalProps {
  result: {
    file: FileNodeItem;
    isHit: boolean;
    evicted: FileNodeItem[];
    latencyMs: number;
  } | null;
  onClose: () => void;
}

export const AccessResultModal: React.FC<AccessResultModalProps> = ({ result, onClose }) => {
  if (!result) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-5 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-2">
            {result.isHit ? (
              <span className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                <CheckCircle2 className="w-4 h-4" />
              </span>
            ) : (
              <span className="p-1.5 rounded-lg bg-rose-500/10 text-rose-400 border border-rose-500/30">
                <AlertCircle className="w-4 h-4" />
              </span>
            )}
            <h3 className="text-sm font-bold text-slate-100">
              {result.isHit ? "Cache HIT — Instant Retrieval" : "Cache MISS — Disk Read & Eviction"}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-200 rounded-lg hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-xs font-mono font-bold text-sky-400">{result.file.fileId}</span>
            <span className="text-[11px] font-mono text-slate-400">{result.latencyMs} ms latency</span>
          </div>
          <div className="text-sm font-bold text-slate-100">{result.file.fileName}</div>
          <div className="text-xs text-slate-400">
            {result.file.fileType} • {result.file.fileSize} MB • Access #{result.file.accessCount}
          </div>
        </div>

        <div className="text-xs text-slate-300 leading-relaxed">
          {result.isHit ? (
            <p>
              ✔ Found node in <span className="text-sky-400 font-mono">CustomHashMap</span> in O(1) time. Node unlinked and moved to Doubly Linked List <span className="text-emerald-400 font-bold">HEAD (MRU)</span> position.
            </p>
          ) : (
            <p>
              ✖ Key was not in cache. Retrieved from simulated disk storage. Allocated new node at Doubly Linked List <span className="text-sky-400 font-bold">HEAD (MRU)</span> and registered in CustomHashMap.
            </p>
          )}
        </div>

        {result.evicted.length > 0 && (
          <div className="bg-amber-950/20 border border-amber-800/40 p-3 rounded-xl space-y-1 text-xs">
            <span className="font-bold text-amber-400 flex items-center space-x-1">
              <Layers className="w-3.5 h-3.5" />
              <span>LRU Eviction Occurred:</span>
            </span>
            {result.evicted.map((e) => (
              <div key={e.fileId} className="text-amber-200/80 pl-4 font-mono text-[11px]">
                • Evicted {e.fileName} ({e.fileId}) from TAIL to free cache capacity.
              </div>
            ))}
          </div>
        )}

        <div className="flex justify-end pt-1">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded text-xs font-bold bg-sky-500 hover:bg-sky-400 text-slate-950 transition cursor-pointer"
          >
            OK
          </button>
        </div>
      </div>
    </div>
  );
};
