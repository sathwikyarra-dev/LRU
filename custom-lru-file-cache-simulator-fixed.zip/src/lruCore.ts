import { FileNodeItem, BucketItem, CacheStatistics, ActivityLogItem } from "./types";

/**
 * Node for Custom Doubly Linked List
 */
export class DLLNode {
  public key: string;
  public data: FileNodeItem;
  public prev: DLLNode | null = null;
  public next: DLLNode | null = null;

  constructor(key: string, data: FileNodeItem) {
    this.key = key;
    this.data = data;
  }
}

/**
 * Node for Separate Chaining HashMap
 */
class HashEntry {
  public key: string;
  public value: DLLNode;
  public next: HashEntry | null = null;

  constructor(key: string, value: DLLNode) {
    this.key = key;
    this.value = value;
  }
}

/**
 * Custom Hash Map using polynomial rolling hash and Separate Chaining
 */
export class CustomHashMap {
  private capacity: number;
  private buckets: (HashEntry | null)[];
  private size: number = 0;
  private collisionCount: number = 0;

  constructor(capacity: number = 16) {
    this.capacity = capacity;
    this.buckets = new Array(capacity).fill(null);
  }

  public hash(key: string): number {
    let hashVal = 0;
    for (let i = 0; i < key.length; i++) {
      hashVal = (hashVal * 31 + key.charCodeAt(i)) % this.capacity;
    }
    return Math.abs(hashVal);
  }

  public get(key: string): DLLNode | null {
    const idx = this.hash(key);
    let curr = this.buckets[idx];
    while (curr) {
      if (curr.key === key) {
        return curr.value;
      }
      curr = curr.next;
    }
    return null;
  }

  public put(key: string, value: DLLNode): void {
    const idx = this.hash(key);
    let curr = this.buckets[idx];

    // Check if key already exists
    while (curr) {
      if (curr.key === key) {
        curr.value = value;
        return;
      }
      curr = curr.next;
    }

    // Insert at front of bucket chain
    const newEntry = new HashEntry(key, value);
    if (this.buckets[idx] !== null) {
      this.collisionCount++;
    }
    newEntry.next = this.buckets[idx];
    this.buckets[idx] = newEntry;
    this.size++;
  }

  public remove(key: string): boolean {
    const idx = this.hash(key);
    let curr = this.buckets[idx];
    let prev: HashEntry | null = null;

    while (curr) {
      if (curr.key === key) {
        if (prev) {
          prev.next = curr.next;
        } else {
          this.buckets[idx] = curr.next;
        }
        this.size--;
        return true;
      }
      prev = curr;
      curr = curr.next;
    }
    return false;
  }

  public clear(): void {
    this.buckets = new Array(this.capacity).fill(null);
    this.size = 0;
    this.collisionCount = 0;
  }

  public getDiagnostics(): {
    capacity: number;
    entries: number;
    collisions: number;
    loadFactor: number;
    bucketUtilizationPct: number;
    buckets: BucketItem[];
  } {
    let occupied = 0;
    const bucketList: BucketItem[] = [];

    for (let i = 0; i < this.capacity; i++) {
      const keys: string[] = [];
      const entries: FileNodeItem[] = [];
      let curr = this.buckets[i];
      let chainLen = 0;

      while (curr) {
        keys.push(curr.key);
        entries.push(curr.value.data);
        chainLen++;
        curr = curr.next;
      }

      if (chainLen > 0) occupied++;

      bucketList.push({
        index: i,
        keys,
        isCollision: chainLen > 1,
        entries
      });
    }

    const loadFactor = this.capacity > 0 ? this.size / this.capacity : 0;
    const bucketUtilizationPct = this.capacity > 0 ? (occupied / this.capacity) * 100 : 0;

    return {
      capacity: this.capacity,
      entries: this.size,
      collisions: this.collisionCount,
      loadFactor: Number(loadFactor.toFixed(2)),
      bucketUtilizationPct: Number(bucketUtilizationPct.toFixed(1)),
      buckets: bucketList
    };
  }
}

/**
 * Custom Doubly Linked List for MRU (Head) to LRU (Tail)
 */
export class DoublyLinkedList {
  public head: DLLNode | null = null;
  public tail: DLLNode | null = null;
  public size: number = 0;

  public addFirst(node: DLLNode): void {
    node.prev = null;
    node.next = this.head;

    if (this.head) {
      this.head.prev = node;
    } else {
      this.tail = node;
    }

    this.head = node;
    this.size++;
  }

  public removeNode(node: DLLNode): void {
    if (node.prev) {
      node.prev.next = node.next;
    } else {
      this.head = node.next;
    }

    if (node.next) {
      node.next.prev = node.prev;
    } else {
      this.tail = node.prev;
    }

    node.prev = null;
    node.next = null;
    this.size--;
  }

  public removeLast(): DLLNode | null {
    if (!this.tail) return null;
    const removed = this.tail;
    this.removeNode(removed);
    return removed;
  }

  public moveToHead(node: DLLNode): void {
    if (node === this.head) return;
    this.removeNode(node);
    this.addFirst(node);
  }

  public toArray(): FileNodeItem[] {
    const list: FileNodeItem[] = [];
    let curr = this.head;
    while (curr) {
      list.push(curr.data);
      curr = curr.next;
    }
    return list;
  }

  public clear(): void {
    this.head = null;
    this.tail = null;
    this.size = 0;
  }
}

/**
 * LRU Cache combining CustomHashMap + DoublyLinkedList
 */
export class LRUCacheEngine {
  public capacity: number;
  public policy: "max_files" | "max_memory";
  public maxMemoryMb: number;
  public currentMemoryMb: number = 0;

  public hashMap: CustomHashMap;
  public dll: DoublyLinkedList;

  public cacheHits: number = 0;
  public cacheMisses: number = 0;
  public evictions: number = 0;
  public totalRequests: number = 0;

  constructor(capacity: number = 5, policy: "max_files" | "max_memory" = "max_files", maxMemoryMb: number = 50.0) {
    this.capacity = capacity;
    this.policy = policy;
    this.maxMemoryMb = maxMemoryMb;
    this.hashMap = new CustomHashMap(16);
    this.dll = new DoublyLinkedList();
  }

  public get(key: string): { node: FileNodeItem | null; isHit: boolean } {
    this.totalRequests++;
    const dllNode = this.hashMap.get(key);

    if (dllNode) {
      this.cacheHits++;
      dllNode.data.accessCount++;
      const now = new Date().toLocaleTimeString();
      dllNode.data.lastAccessed = now;
      this.dll.moveToHead(dllNode);
      return { node: dllNode.data, isHit: true };
    }

    this.cacheMisses++;
    return { node: null, isHit: false };
  }

  public put(key: string, fileData: FileNodeItem): FileNodeItem[] {
    const evicted: FileNodeItem[] = [];
    let existingNode = this.hashMap.get(key);

    if (existingNode) {
      // Update data
      this.currentMemoryMb -= existingNode.data.fileSize;
      existingNode.data = { ...fileData, accessCount: existingNode.data.accessCount + 1, lastAccessed: new Date().toLocaleTimeString() };
      this.currentMemoryMb += existingNode.data.fileSize;
      this.dll.moveToHead(existingNode);
      return evicted;
    }

    // New insertion: check capacity limits
    if (this.policy === "max_files") {
      while (this.dll.size >= this.capacity) {
        const tail = this.dll.removeLast();
        if (tail) {
          this.hashMap.remove(tail.key);
          this.currentMemoryMb = Math.max(0, this.currentMemoryMb - tail.data.fileSize);
          this.evictions++;
          evicted.push(tail.data);
        }
      }
    } else {
      while (this.currentMemoryMb + fileData.fileSize > this.maxMemoryMb && this.dll.size > 0) {
        const tail = this.dll.removeLast();
        if (tail) {
          this.hashMap.remove(tail.key);
          this.currentMemoryMb = Math.max(0, this.currentMemoryMb - tail.data.fileSize);
          this.evictions++;
          evicted.push(tail.data);
        }
      }
    }

    const newNode = new DLLNode(key, { ...fileData, accessCount: 1, lastAccessed: new Date().toLocaleTimeString() });
    this.dll.addFirst(newNode);
    this.hashMap.put(key, newNode);
    this.currentMemoryMb += fileData.fileSize;

    return evicted;
  }

  public remove(key: string): boolean {
    const node = this.hashMap.get(key);
    if (!node) return false;
    this.currentMemoryMb = Math.max(0, this.currentMemoryMb - node.data.fileSize);
    this.dll.removeNode(node);
    this.hashMap.remove(key);
    return true;
  }

  public setCapacity(newCapacity: number): FileNodeItem[] {
    this.capacity = newCapacity;
    const evicted: FileNodeItem[] = [];
    if (this.policy === "max_files") {
      while (this.dll.size > this.capacity) {
        const tail = this.dll.removeLast();
        if (tail) {
          this.hashMap.remove(tail.key);
          this.currentMemoryMb = Math.max(0, this.currentMemoryMb - tail.data.fileSize);
          this.evictions++;
          evicted.push(tail.data);
        }
      }
    }
    return evicted;
  }

  public getStatistics(): CacheStatistics {
    const hitRate = this.totalRequests > 0 ? (this.cacheHits / this.totalRequests) * 100 : 0;
    return {
      capacity: this.capacity,
      currentSize: this.dll.size,
      cacheHits: this.cacheHits,
      cacheMisses: this.cacheMisses,
      hitRatePct: Number(hitRate.toFixed(1)),
      evictions: this.evictions,
      totalRequests: this.totalRequests,
      currentMemoryMb: Number(this.currentMemoryMb.toFixed(2)),
      maxMemoryMb: this.maxMemoryMb
    };
  }

  public clear(): void {
    this.hashMap.clear();
    this.dll.clear();
    this.cacheHits = 0;
    this.cacheMisses = 0;
    this.evictions = 0;
    this.totalRequests = 0;
    this.currentMemoryMb = 0;
  }
}
