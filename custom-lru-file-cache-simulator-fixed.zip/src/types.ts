export interface FileNodeItem {
  fileId: string;
  fileName: string;
  fileType: string;
  fileSize: number; // MB
  createdAt: string;
  lastAccessed: string | null;
  accessCount: number;
}

export interface BucketItem {
  index: number;
  keys: string[];
  isCollision: boolean;
  entries: FileNodeItem[];
}

export interface ActivityLogItem {
  id: number;
  timestamp: string;
  operation: "GET" | "PUT" | "EVICT" | "DELETE" | "RESIZE";
  fileName: string;
  fileId?: string;
  status: "HIT" | "MISS" | "EVICTED" | "OK" | "PURGED";
  details: string;
  latencyMs: number;
}

export interface CacheStatistics {
  capacity: number;
  currentSize: number;
  cacheHits: number;
  cacheMisses: number;
  hitRatePct: number;
  evictions: number;
  totalRequests: number;
  currentMemoryMb: number;
  maxMemoryMb: number;
}

export interface StepTrace {
  step: number;
  title: string;
  description: string;
  targetFile: string;
  actionType: "lookup" | "hit_promote" | "miss_storage" | "evict_tail" | "insert_head";
}

export interface ToastItem {
  id: string;
  type: "success" | "info" | "warning" | "error" | "evict";
  title: string;
  message: string;
  timestamp: number;
}

export interface PolicyState {
  name: "LRU" | "FIFO" | "LFU" | "Random";
  cache: string[]; // fileIds in order
  hits: number;
  misses: number;
  evictions: number;
  hitRate: number;
  frequencies?: Record<string, number>;
  lastEvicted?: string | null;
  lastActionStatus?: "HIT" | "MISS";
}

export interface PolicyComparisonResult {
  stepIndex: number;
  currentKey: string;
  policies: {
    LRU: PolicyState;
    FIFO: PolicyState;
    LFU: PolicyState;
    Random: PolicyState;
  };
}

export interface HashStepCalculation {
  step: number;
  char: string;
  charCode: number;
  prevHash: number;
  times31: number;
  plusCode: number;
  newHash: number;
}

export interface VivaQuestionItem {
  id: number;
  question: string;
  answer: string;
  category: "Architecture" | "Hashing" | "Complexity" | "Linked List";
}
