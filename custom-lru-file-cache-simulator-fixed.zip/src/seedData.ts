import { FileNodeItem, VivaQuestionItem } from "./types";

export const INITIAL_FILES: FileNodeItem[] = [
  {
    fileId: "F001",
    fileName: "report.pdf",
    fileType: "PDF",
    fileSize: 2.4,
    createdAt: "2026-09-20 09:15",
    lastAccessed: null,
    accessCount: 0
  },
  {
    fileId: "F002",
    fileName: "assignment.docx",
    fileType: "DOCX",
    fileSize: 1.2,
    createdAt: "2026-09-20 10:20",
    lastAccessed: null,
    accessCount: 0
  },
  {
    fileId: "F003",
    fileName: "photo.jpg",
    fileType: "JPG",
    fileSize: 4.1,
    createdAt: "2026-09-20 11:05",
    lastAccessed: null,
    accessCount: 0
  },
  {
    fileId: "F004",
    fileName: "video.mp4",
    fileType: "MP4",
    fileSize: 28.5,
    createdAt: "2026-09-20 12:30",
    lastAccessed: null,
    accessCount: 0
  },
  {
    fileId: "F005",
    fileName: "notes.txt",
    fileType: "TXT",
    fileSize: 0.05,
    createdAt: "2026-09-20 13:00",
    lastAccessed: null,
    accessCount: 0
  },
  {
    fileId: "F006",
    fileName: "database.sql",
    fileType: "SQL",
    fileSize: 6.8,
    createdAt: "2026-09-20 14:10",
    lastAccessed: null,
    accessCount: 0
  },
  {
    fileId: "F007",
    fileName: "dataset.csv",
    fileType: "CSV",
    fileSize: 12.3,
    createdAt: "2026-09-20 15:45",
    lastAccessed: null,
    accessCount: 0
  },
  {
    fileId: "F008",
    fileName: "presentation.pptx",
    fileType: "PPTX",
    fileSize: 8.7,
    createdAt: "2026-09-20 16:20",
    lastAccessed: null,
    accessCount: 0
  },
  {
    fileId: "F009",
    fileName: "music.mp3",
    fileType: "MP3",
    fileSize: 5.4,
    createdAt: "2026-09-20 17:10",
    lastAccessed: null,
    accessCount: 0
  },
  {
    fileId: "F010",
    fileName: "project.zip",
    fileType: "ZIP",
    fileSize: 19.8,
    createdAt: "2026-09-20 18:00",
    lastAccessed: null,
    accessCount: 0
  }
];

export const VIVA_QUESTIONS: VivaQuestionItem[] = [
  {
    id: 1,
    category: "Hashing",
    question: "Why is a HashMap used in an LRU cache?",
    answer: "A HashMap provides average O(1) time complexity for looking up cache entries by key (file ID). Without a HashMap, searching for an item in a cache would require scanning a list sequentially in O(N) time."
  },
  {
    id: 2,
    category: "Linked List",
    question: "Why is a Doubly Linked List used instead of a Singly Linked List?",
    answer: "In a Doubly Linked List, each node maintains pointers to both its predecessor (previous) and successor (next). When the HashMap locates a node, we can detach it and splice it to the front in O(1) time without traversing from the head to find the predecessor."
  },
  {
    id: 3,
    category: "Architecture",
    question: "Why can't a dynamic array or Python list efficiently implement an LRU cache?",
    answer: "Removing an arbitrary element from an array requires shifting all subsequent elements left, which takes O(N) time. Inserting or moving an item to index 0 also shifts all items in O(N) time. A Doubly Linked List achieves O(1) removal and insertion."
  },
  {
    id: 4,
    category: "Architecture",
    question: "What is a cache hit?",
    answer: "A cache hit occurs when a requested item is already stored in the fast-access cache memory. The item is returned immediately without accessing slow secondary storage."
  },
  {
    id: 5,
    category: "Architecture",
    question: "What is a cache miss?",
    answer: "A cache miss occurs when a requested item is not found in the cache. The system must retrieve the data from secondary storage (simulated disk), load it into memory, and insert it into the cache."
  },
  {
    id: 6,
    category: "Architecture",
    question: "What is cache eviction?",
    answer: "Eviction is the process of removing an existing item from the cache to create space for a newly loaded item when the cache reaches its maximum capacity or memory limit."
  },
  {
    id: 7,
    category: "Linked List",
    question: "Why is the tail of the linked list considered LRU (Least Recently Used)?",
    answer: "Every time an item is accessed or newly inserted, it is moved to or added at the head (MRU). Therefore, items that have not been accessed for the longest period naturally drift toward the tail."
  },
  {
    id: 8,
    category: "Linked List",
    question: "Why is the head of the linked list considered MRU (Most Recently Used)?",
    answer: "By definition, the most recent operation (either GET hit or PUT insert) promotes the target node to the head of the list. Thus, the head always holds the most recently accessed node."
  },
  {
    id: 9,
    category: "Hashing",
    question: "What is a hash collision?",
    answer: "A hash collision occurs when two different keys compute to the exact same bucket index: hash(key1) % capacity == hash(key2) % capacity. Because hash tables have finite buckets, collisions are inevitable according to the Pigeonhole Principle."
  },
  {
    id: 10,
    category: "Hashing",
    question: "How does separate chaining resolve hash collisions?",
    answer: "Separate chaining stores multiple entries mapping to the same bucket index as a linked list (or chain) of nodes. During lookup, the algorithm navigates directly to the bucket and iterates through the chain until the matching key is found."
  },
  {
    id: 11,
    category: "Complexity",
    question: "What is the average and worst-case time complexity of LRU GET?",
    answer: "Average time is O(1) because good hash distribution yields constant bucket chain length, and pointer manipulation in the linked list takes O(1). Worst case is O(N) if all keys collide into a single bucket, degrading the hash map to a linear search."
  },
  {
    id: 12,
    category: "Architecture",
    question: "What happens when the cache is full and a new file is accessed (cache miss)?",
    answer: "The cache identifies the tail node (LRU), unlinks it from the Doubly Linked List, removes its key from the Custom HashMap, increments eviction count, and then adds the new file node at the head (MRU) while registering it in the HashMap."
  },
  {
    id: 13,
    category: "Architecture",
    question: "What happens when an existing cached file is accessed (cache hit)?",
    answer: "The HashMap retrieves the node in O(1) time. The node's access count is incremented, its last-accessed timestamp is updated, and the node is unlinked and moved to the head (MRU) position of the Doubly Linked List."
  },
  {
    id: 14,
    category: "Architecture",
    question: "What happens when a nonexistent file (not even in storage) is requested?",
    answer: "The simulator queries the storage repository. When the file ID is not found in secondary storage, it reports a lookup error without altering cache contents or statistics."
  },
  {
    id: 15,
    category: "Architecture",
    question: "Why is Python's functools.lru_cache or dict avoided in this project?",
    answer: "This is an academic DSA project. Using built-in or third-party wrappers hides the underlying mechanics. Writing our own Custom HashMap and Doubly Linked List demonstrates how hash functions, bucket chains, and pointer linking operate at the memory level."
  },
  {
    id: 16,
    category: "Complexity",
    question: "What is the difference between Temporal Locality and Spatial Locality?",
    answer: "Temporal Locality states that memory accessed recently is likely to be accessed again soon (the foundation of LRU). Spatial Locality states that memory near currently accessed locations is likely to be accessed soon (e.g. cache lines, page prefetching)."
  },
  {
    id: 17,
    category: "Linked List",
    question: "What is the time complexity of deleting a node given only its pointer in Singly vs Doubly Linked Lists?",
    answer: "In a Singly Linked List, deleting a node requires finding its predecessor, which takes O(N) traversal. In a Doubly Linked List, node.previous provides immediate O(1) access to the predecessor, enabling O(1) unlinking."
  },
  {
    id: 18,
    category: "Hashing",
    question: "What is load factor and how does it affect hash table performance?",
    answer: "Load factor is the ratio of stored entries to total bucket capacity (n / k). A low load factor minimizes collisions but wastes memory. A high load factor (> 0.75) increases bucket collisions, lengthening chains and degrading lookup time toward O(N)."
  },
  {
    id: 19,
    category: "Architecture",
    question: "What are common alternative cache replacement policies to LRU?",
    answer: "Common policies include LFU (Least Frequently Used, tracks frequency count), FIFO (First-In First-Out, evicts oldest entry regardless of recent use), and Clock/Second-Chance (circular buffer approximation of LRU with lower synchronization overhead)."
  },
  {
    id: 20,
    category: "Hashing",
    question: "Why is the polynomial rolling hash with base 31 effective for string keys?",
    answer: "Base 31 is prime, which reduces common divisors with power-of-two table capacities, dispersing hash values uniformly across buckets. Furthermore, (x * 31) can be optimized by compilers as (x << 5) - x using fast bit shifts."
  }
];
